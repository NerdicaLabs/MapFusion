<?php
/**
 * Plugin Settings Management for MapFusion.
 *
 * This file defines the `Settings` class, responsible for registering
 * and managing the plugin settings in the WordPress dashboard for MapFusion.
 *
 * @package MapFusion
 */

namespace MapFusion;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly. //
}

/**
 * Handles plugin settings registration and management in WordPress.
 *
 * This class is responsible for creating, updating, and retrieving
 * plugin settings, as well as managing options in the WordPress admin.
 */
class Settings {


	/**
	 * Initialize hooks for settings management.
	 */
	public static function init() {
		Debug::initializing( '[Settings] Initializing settings hooks.' );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
	}

	/**
	 * Register settings in WordPress.
	 */
	public static function register_settings() {
		Debug::initializing( '[Settings] Registering settings.' );

		// Register API key setting securely. //
		register_setting(
			'mapfusion_settings_group',
			'mapfusion_api_key',
			array(
				'type'              => 'string',
				'description'       => __( 'API key for authenticating external requests.', 'mapfusion' ),
				'sanitize_callback' => array( self::class, 'sanitize_mapfusion_api_key' ),
				'show_in_rest'      => true, // Allow access via REST API. //
				'default'           => '',
			)
		);

		Debug::initializing( '[Settings] API key registered in wp_options.' );
	}

	/**
	 * Custom sanitization callback for the API key.
	 *
	 * @param mixed $input The raw API key input to be sanitized.
	 * @return string The sanitized API key if valid, otherwise an empty string.
	 */
	public static function sanitize_mapfusion_api_key( $input ) {
		// Ensure input is a string before validation. //
		if ( ! is_string( $input ) ) {
			return '';
		}

		// Allow only alphanumeric characters, dashes, and underscores. //
		$sanitized_key = preg_match( '/^[a-zA-Z0-9-_]+$/', $input ) ? sanitize_text_field( $input ) : '';

		// Log any invalid attempts. //
		if ( empty( $sanitized_key ) ) {
			Debug::warning( '[Sanitization] Invalid API key format detected.' );
		}

		return $sanitized_key;
	}
}

// Initialize the settings class. //
Debug::initializing( '[Settings] Initializing Settings class.' );
Settings::init();
