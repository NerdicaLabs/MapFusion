<?php
/**
 * WP Go Maps Integration for MapFusion.
 *
 * This file defines the `WPGM_Integration` class, responsible for integrating
 * the MapFusion plugin with WP Go Maps, providing enhanced map functionalities.
 *
 * @package MapFusion
 */

namespace MapFusion;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly. //
}

/**
 * Handles integration with WP Go Maps.
 *
 * This class is responsible for managing the interaction between MapFusion
 * and WP Go Maps, including map creation, marker management, and data syncing.
 */
class WPGM_Integration {


	/**
	 * Adds a marker to a specific map.
	 *
	 * @param int   $map_id The ID of the map to add the marker to.
	 * @param array $marker_data The data for the new marker (title, description, lat, lng, etc.).
	 * @return bool True on success, false on failure.
	 */
	public static function add_marker( $map_id, $marker_data ) {
		global $wpdb;

		// Ensure map ID is an integer. //
		$map_id = intval( $map_id );

		// Table for storing markers. //
		$table_name = $wpdb->prefix . 'wpgmza';

		// Prepare data for insertion. //
		$data = array(
			'map_id'      => $map_id,
			'title'       => sanitize_text_field( $marker_data['title'] ?? '' ),
			'description' => sanitize_textarea_field( $marker_data['description'] ?? '' ),
			'lat'         => is_numeric( $marker_data['lat'] ?? '' ) ? floatval( $marker_data['lat'] ) : '',
			'lng'         => is_numeric( $marker_data['lng'] ?? '' ) ? floatval( $marker_data['lng'] ) : '',
			'address'     => sanitize_text_field( $marker_data['address'] ?? '' ),
			'icon'        => sanitize_text_field( $marker_data['icon'] ?? '' ),
			'pic'         => esc_url_raw( $marker_data['pic'] ?? '' ),
		);

		Debug::info( "Adding marker to map ID: {$map_id}" );
		Debug::info( 'Marker data: ', $data );

		// Insert marker data into the database. //
		$inserted = $wpdb->insert(
			$table_name,
			$data,
			array(
				'%d', // map_id. //
				'%s', // title. //
				'%s', // description. //
				'%f', // lat. //
				'%f', // lng. //
				'%s', // address. //
				'%s', // icon. //
				'%s',  // pic. //
			)
		);

		if ( false !== $inserted ) {
			// Invalidate cache to ensure updated markers list. //
			wp_cache_delete( "mapfusion_markers_{$map_id}", 'mapfusion' );
			wp_cache_delete( 'mapfusion_total_markers_count', 'mapfusion' );

			Debug::info( 'Marker added successfully.' );
		} else {
			Debug::error( 'Failed to add marker.' );
		}

		return false !== $inserted;
	}

	/**
	 * Deletes a marker from a specific map.
	 *
	 * @param int $marker_id The ID of the marker to delete.
	 * @return bool True on success, false on failure.
	 */
	public static function delete_marker( $marker_id ) {
		global $wpdb;

		// Ensure marker ID is an integer. //
		$marker_id = intval( $marker_id );

		// Table for storing markers. //
		$table_name = $wpdb->prefix . 'wpgmza';

		Debug::info( "Deleting marker ID: {$marker_id}" );

		// Delete the marker from the database. //
		$deleted = $wpdb->delete( $table_name, array( 'id' => $marker_id ), array( '%d' ) );

		if ( false !== $deleted ) {
			// Invalidate cache to ensure updated results. //
			wp_cache_delete( "mapfusion_marker_{$marker_id}", 'mapfusion' );
			wp_cache_delete( 'mapfusion_total_markers_count', 'mapfusion' );

			Debug::info( 'Marker deleted successfully.' );
		} else {
			Debug::error( 'Failed to delete marker.' );
		}

		return false !== $deleted;
	}

	/**
	 * Updates an existing marker.
	 *
	 * @param int   $marker_id The ID of the marker to update.
	 * @param array $marker_data The updated data for the marker.
	 * @return bool True on success, false on failure.
	 */
	public static function update_marker( $marker_id, $marker_data ) {
		global $wpdb;

		// Ensure marker ID is an integer.
		$marker_id = intval( $marker_id );

		// Table for storing markers.
		$table_name = $wpdb->prefix . 'wpgmza';

		// Prepare data for updating.
		$data           = array();
		$allowed_fields = array( 'title', 'description', 'lat', 'lng', 'address', 'icon', 'pic' );

		foreach ( $allowed_fields as $field ) {
			if ( isset( $marker_data[ $field ] ) ) {
				$data[ $field ] = is_numeric( $marker_data[ $field ] )
				? floatval( $marker_data[ $field ] )
				: sanitize_text_field( $marker_data[ $field ] );
			}
		}

		Debug::info( "Updating marker ID: {$marker_id}" );
		Debug::info( 'Updated marker data: ', $data );

		// Update the marker in the database. //
		$updated = $wpdb->update(
			$table_name,
			$data,
			array( 'id' => $marker_id ),
			array_fill( 0, count( $data ), '%s' ),
			array( '%d' )
		);

		if ( false !== $updated ) {
			// Invalidate cache to reflect updated data. //
			wp_cache_delete( "mapfusion_marker_{$marker_id}", 'mapfusion' );
			wp_cache_delete( 'mapfusion_total_markers_count', 'mapfusion' );

			Debug::info( 'Marker updated successfully.' );
		} else {
			Debug::error( 'Failed to update marker.' );
		}

		return false !== $updated;
	}

	/**
	 * Retrieves all markers for a specific map.
	 *
	 * @param int $map_id The ID of the map.
	 * @return array List of markers, or an empty array if none are found.
	 */
	public static function get_markers_by_map( $map_id ) {
		global $wpdb;

		// Ensure map ID is an integer. //
		$map_id = intval( $map_id );

		// Table for storing markers. //
		$table_name = $wpdb->prefix . 'wpgmza';

		// Generate a cache key based on the map ID. //
		$cache_key = 'mapfusion_markers_' . $map_id;

		// Attempt to retrieve cached markers. //
		$markers = wp_cache_get( $cache_key, 'mapfusion' );

		if ( false === $markers ) {
			Debug::info( "Fetching markers for map ID: {$map_id}" );

			// Ensure the table name is properly escaped. //
			$table_name_safe = esc_sql( $table_name );

			// Construct SQL query correctly. //
			$sql = "SELECT * FROM {$table_name_safe} WHERE map_id = %d";

			// Use prepare() only for the user-provided value. //
			$query   = $wpdb->prepare( $sql, $map_id );
			$markers = $wpdb->get_results( $query, ARRAY_A );

			// Cache the result (e.g., 10-minute expiration). //
			if ( ! empty( $markers ) ) {
				wp_cache_set( $cache_key, $markers, 'mapfusion', 600 );
				Debug::info( "Markers cached for map ID: {$map_id}", $markers );
			} else {
				Debug::warning( "No markers found for map ID: {$map_id}" );
			}
		} else {
			Debug::info( "Markers loaded from cache for map ID: {$map_id}" );
		}

		// Ensure a valid return value. //
		return ! empty( $markers ) ? $markers : array();
	}
}
