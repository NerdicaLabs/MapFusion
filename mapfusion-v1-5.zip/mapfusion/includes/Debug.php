<?php
/**
 * Debug Logging for MapFusion.
 *
 * This file defines the `Debug` class, responsible for handling
 * logging, error tracking, and debugging features within the
 * MapFusion plugin.
 *
 * @package MapFusion
 */

namespace MapFusion;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly. //
}

/**
 * Handles logging and debugging for the MapFusion plugin.
 *
 * This class provides utility functions for structured logging,
 * debugging API requests, and tracking errors during execution.
 */
class Debug {

	/**
	 * Holds the wp-content directory path.
	 * Initialized via get_content_dir().
	 *
	 * @var string
	 */
	public static $content_dir;

	/**
	 * Retrieves the wp-content directory dynamically.
	 *
	 * @return string The absolute path to the wp-content directory.
	 */
	public static function get_content_dir() {
		if ( ! isset( self::$content_dir ) ) {
			global $wp_filesystem;

			// Ensure WordPress filesystem is initialized.
			if ( ! $wp_filesystem ) {
				require_once ABSPATH . 'wp-admin/includes/file.php';
				WP_Filesystem();
			}

			// Retrieve the wp-content directory dynamically.
			self::$content_dir = trailingslashit( $wp_filesystem->wp_content_dir() );
		}

		return self::$content_dir;
	}

	/**
	 * Logs a message with a specified log level to the custom debug log.
	 *
	 * @param string     $level The log level (e.g., 'error', 'info', 'warning', 'api').
	 * @param string     $message The log message.
	 * @param array|null $context Additional context for the log message.
	 */
	public static function log( $level, $message, $context = null ) {
		global $wpdb, $wp_filesystem;

		// Define table name and fields dynamically. //
		$table_name = $wpdb->prefix . 'mapfusion_settings';
		$debug      = 'debug_logging';
		$levels     = 'debug_levels';

		// Retrieve debug logging status from cache to reduce database queries. //
		$cache_key     = 'mapfusion_debug_logging';
		$debug_enabled = wp_cache_get( $cache_key );

		if ( false === $debug_enabled ) {
			// Fetch the debug logging setting safely. //
			$debug_enabled = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT setting_value FROM {$table_name} WHERE setting_key = %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
					$debug
				)
			);

			if ( null !== $debug_enabled ) {
				wp_cache_set( $cache_key, $debug_enabled, '', 3600 );
			}
		}

		if ( ! $debug_enabled ) {
			return;
		}

		// Retrieve allowed debug levels from cache. //
		$cache_key_levels = 'mapfusion_debug_levels';
		$allowed_levels   = wp_cache_get( $cache_key_levels );

		if ( false === $allowed_levels ) {
			// Fetch the allowed debug levels safely. //
			$allowed_levels_json = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT setting_value FROM {$table_name} WHERE setting_key = %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
					$levels
				)
			);

			// Decode JSON if a valid result was found, else use default levels. //
			$allowed_levels = $allowed_levels_json ? json_decode( $allowed_levels_json, true ) : array( 'error', 'warning', 'critical', 'info', 'initializing', 'api' );

			// Normalize all levels to lowercase. //
			$allowed_levels = array_map( 'strtolower', (array) $allowed_levels );

			// Store result in cache to prevent excessive database queries. //
			wp_cache_set( $cache_key_levels, $allowed_levels, '', 3600 );
		}

		// Convert log level to lowercase and check if it's allowed. //
		$level = strtolower( $level );
		if ( ! in_array( $level, $allowed_levels, true ) ) {
			return; // Skip logging if level is not in the allowed list. //
		}

		// Format the log message. //
		$timestamp   = gmdate( 'Y-m-d H:i:s' );
		$log_message = sprintf( '[%s] [%s] %s', $timestamp, strtoupper( $level ), $message );

		// Add context if provided. //
		if ( $context ) {
			$log_message .= ' Context: ' . wp_json_encode( $context, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		}
		$log_message .= PHP_EOL;

		// Define the log file path. //
		$log_file = self::get_content_dir() . 'mapfusion-debug.log';

		// Ensure WP_Filesystem is initialized properly. //
		if ( ! $wp_filesystem ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			WP_Filesystem();
		}

		// Use WP_Filesystem to append log message. //
		if ( $wp_filesystem->exists( $log_file ) ) {
			$existing_logs = $wp_filesystem->get_contents( $log_file );
			$log_message   = $existing_logs . $log_message;
		}

		// Write log message to the log file (stored in wp-content/) //
		if ( $wp_filesystem->put_contents( $log_file, $log_message, FS_CHMOD_FILE ) ) {
			return;
		}

		// Fallback: Write to log file using standard PHP if WP_Filesystem fails. //
		$file_handle = fopen( $log_file, 'a' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
		if ( $file_handle ) {
			fwrite( $file_handle, $log_message ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
			fclose( $file_handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		} else {
			error_log( "MapFusion Debug: Failed to append log entry to $log_file using both WP_Filesystem and fopen()." ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		}
	}

	/**
	 * Convenience methods for specific log levels.
	 *
	 * Logs an informational message.
	 *
	 * @param string     $message The log message.
	 * @param array|null $context Additional context for the log message.
	 *
	 * @return void
	 */
	public static function info( $message, $context = null ) {
		self::log( 'info', $message, $context );
	}

	/**
	 * Logs an error message.
	 *
	 * @param string     $message The log message.
	 * @param array|null $context Additional context for the log message.
	 *
	 * @return void
	 */
	public static function error( $message, $context = null ) {
		self::log( 'error', $message, $context );
	}

	/**
	 * Logs a warning message.
	 *
	 * @param string     $message The log message.
	 * @param array|null $context Additional context for the log message.
	 *
	 * @return void
	 */
	public static function warning( $message, $context = null ) {
		self::log( 'warning', $message, $context );
	}

	/**
	 * Logs a critical error message.
	 *
	 * @param string     $message The log message.
	 * @param array|null $context Additional context for the log message.
	 *
	 * @return void
	 */
	public static function critical( $message, $context = null ) {
		self::log( 'critical', $message, $context );
	}

	/**
	 * Logs an initialization message.
	 *
	 * @param string     $message The log message.
	 * @param array|null $context Additional context for the log message.
	 *
	 * @return void
	 */
	public static function initializing( $message, $context = null ) {
		self::log( 'initializing', $message, $context );
	}

	/**
	 * Logs an API request message.
	 *
	 * @param string     $message The log message.
	 * @param array|null $context Additional context for the log message.
	 *
	 * @return void
	 */
	public static function api( $message, $context = null ) {
		self::log( 'api', $message, $context );
	}


	/**
	 * Ensures the custom log file exists and is writable.
	 *
	 * @param string $log_file Path to the log file.
	 * @return bool True if the file exists and is writable, false otherwise.
	 */
	public static function ensure_log_file_exists( $log_file ) {
		global $wp_filesystem;

		// Ensure WordPress filesystem is initialized
		if ( ! $wp_filesystem ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			WP_Filesystem();
		}

		// Validate log file path
		if ( empty( $log_file ) || ! is_string( $log_file ) ) {
			self::error( 'Invalid log file path provided.' );
			return false;
		}

		$max_log_size = 10 * 1024 * 1024;

		if ( $wp_filesystem->exists( $log_file ) ) {
			$log_size = $wp_filesystem->size( $log_file );

			// Ensure size check does not fail
			if ( false === $log_size ) {
				self::error( "Failed to retrieve log file size: $log_file" );
				return false;
			}

			if ( $log_size > $max_log_size ) {
				$backup_file = self::get_content_dir() . 'mapfusion-debug-' . time() . '.log';

				if ( $wp_filesystem->move( $log_file, $backup_file ) ) {
					self::info( "Log file rotated. Old log saved as: $backup_file" );
					return true;
				} else {
					self::error( "Failed to rotate log file: $log_file" );
					return false;
				}
			}

			return $wp_filesystem->is_writable( $log_file );
		}

		// Ensure file creation does not fail silently
		if ( ! $wp_filesystem->put_contents( $log_file, '', FS_CHMOD_FILE ) ) {
			self::error( "Failed to create log file: $log_file" );
			return false;
		}

		return true;
	}

	/**
	 * Logs the status of the custom log file during initialization.
	 */
	public static function verify_log_file_status() {
		$log_file = self::get_content_dir() . 'mapfusion-debug.log';

		if ( self::ensure_log_file_exists( $log_file ) ) {
			self::initializing( 'Log file is ready.', array( 'log_file' => $log_file ) );
		} else {
			self::error( 'Failed to verify log file.', array( 'log_file' => $log_file ) );
		}
	}

	/**
	 * Handles plugin activation and ensures the log file exists.
	 *
	 * @return void
	 */
	public static function activate_plugin() {
		$log_file = self::get_content_dir() . 'mapfusion-debug.log';

		if ( self::ensure_log_file_exists( $log_file ) ) {
			self::initializing( 'Log file created during plugin activation.', array( 'log_file' => $log_file ) );
		} else {
			self::error( 'Failed to create log file during plugin activation.', array( 'log_file' => $log_file ) );
		}
	}
}

// Hook to verify log file status during initialization. //
add_action( 'init', array( Debug::class, 'verify_log_file_status' ) );

// Register activation hook using the class method instead of a standalone function. //
register_activation_hook( __FILE__, array( 'Debug', 'activate_plugin' ) );
