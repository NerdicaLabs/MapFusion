<?php
/**
 * Privacy Policy Notice Handler for MapFusion.
 *
 * This file defines the `Privacy_Policy_Notice` class, responsible for
 * displaying and managing the dismissal of the privacy policy notice
 * within the MapFusion plugin.
 *
 * @package MapFusion
 */

namespace MapFusion;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly. //
}

/**
 * Handles the display and dismissal of the privacy policy notice.
 *
 * This class ensures that users are informed about the plugin's
 * privacy policy and provides functionality to dismiss the notice.
 */
class Privacy_Policy_Notice {


	/**
	 * Initialize hooks for privacy policy notice.
	 */
	public static function init() {
		Debug::initializing( '[Privacy_Policy_Notice] Initializing hooks for privacy policy notice.' );
		add_action( 'admin_notices', array( __CLASS__, 'show_privacy_policy_notice' ) );
		add_action( 'wp_ajax_mapfusion_dismiss_notice', array( __CLASS__, 'dismiss_privacy_notice' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_dismiss_script' ) );
	}

	/**
	 * Show the privacy policy notice.
	 */
	public static function show_privacy_policy_notice() {
		$user_id = get_current_user_id();

		try {
			// Check if the user has already dismissed the message. //
			$notice_dismissed = get_user_meta( $user_id, 'mapfusion_privacy_notice_dismissed', true );

			if ( ! $notice_dismissed ) {
				Debug::initializing( '[Privacy_Policy_Notice] Displaying privacy policy notice.' );

				echo '<div class="notice notice-info is-dismissible" data-notice="mapfusion-privacy-notice">';
				echo '<p>';

				printf(
				// Translators: %s is the HTML link to the privacy policy.
					esc_html__(
						'MapFusion collects telemetry data with your consent to improve the plugin. Read our %s.',
						'mapfusion'
					),
					sprintf(
						'<a href="%s" target="_blank">%s</a>',
						esc_url( 'https://www.mapfusion.site/privacy-policy/' ),
						esc_html__( 'Privacy Policy', 'mapfusion' )
					)
				);

				echo '</p>';
				echo '</div>';

				// Logging if the message appears. //
				Debug::initializing( '[Privacy_Policy_Notice] Privacy policy notice displayed for user ID: ' . $user_id );
			} else {
				Debug::initializing( '[Privacy_Policy_Notice] Privacy policy notice already dismissed for user ID: ' . $user_id );
			}
		} catch ( \Exception $e ) {
			// Handle any errors when checking metadata. //
			Debug::error(
				'[Privacy_Policy_Notice] Error while checking or displaying notice.',
				array(
					'error'   => $e->getMessage(),
					'user_id' => $user_id,
				)
			);
		}
	}

	/**
	 * Handle AJAX request to dismiss the privacy notice.
	 */
	public static function dismiss_privacy_notice() {
		try {
			// Check if the user has the necessary rights. //
			if ( ! current_user_can( 'manage_options' ) ) {
				Debug::warning(
					'[Privacy_Policy_Notice] Unauthorized user tried to dismiss the notice.',
					array(
						'user_id' => get_current_user_id(),
					)
				);
				wp_send_json_error( array( 'message' => __( 'You are not authorized to perform this action.', 'mapfusion' ) ) );
				return;
			}

			// Verify nonce for security. //
			if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'mapfusion_nonce' ) ) {
				Debug::warning(
					'[Privacy_Policy_Notice] Invalid nonce for dismissing privacy policy notice.',
					array(
						'user_id' => get_current_user_id(),
					)
				);
				wp_send_json_error( array( 'message' => __( 'Invalid request.', 'mapfusion' ) ) );
				return;
			}

			// Update the user's metadata to indicate that the message was dismissed. //
			$user_id = get_current_user_id();
			update_user_meta( $user_id, 'mapfusion_privacy_notice_dismissed', true );

			Debug::initializing(
				'[Privacy_Policy_Notice] Privacy policy notice dismissed successfully.',
				array(
					'user_id' => $user_id,
				)
			);

			wp_send_json_success( array( 'message' => __( 'Notice dismissed.', 'mapfusion' ) ) );
		} catch ( \Exception $e ) {
			// Log any errors. //
			Debug::error(
				'[Privacy_Policy_Notice] Error dismissing privacy policy notice.',
				array(
					'user_id' => get_current_user_id(),
					'error'   => $e->getMessage(),
				)
			);

			wp_send_json_error( array( 'message' => __( 'An error occurred. Please try again later.', 'mapfusion' ) ) );
		}
	}

	/**
	 * Enqueue script for dismissing the privacy notice.
	 *
	 * @param string $hook The current admin page hook.
	 */
	public static function enqueue_dismiss_script( $hook ) {
		if ( 'plugins.php' === $hook ) {
			Debug::initializing( '[Privacy_Policy_Notice] Enqueuing dismiss notice script for plugins.php.' );
			wp_enqueue_script(
				'mapfusion-dismiss-notice',
				plugin_dir_url( __FILE__ ) . '../js/dismiss-notice.js',
				array( 'jquery' ),
				MAPFUSION_VERSION,
				true
			);

			wp_localize_script(
				'mapfusion-dismiss-notice',
				'mapfusionDismiss',
				array(
					'ajax_url' => admin_url( 'admin-ajax.php' ),
					'nonce'    => wp_create_nonce( 'mapfusion_nonce' ),
				)
			);
		} else {
			Debug::initializing( '[Privacy_Policy_Notice] No enqueue needed for hook: ' . $hook );
		}
	}
}
