<?php
/**
 * Admin scripts and styles handler for MapFusion.
 *
 * This file defines the `Admin_Scripts` class, responsible for
 * enqueuing admin-related scripts and styles in the WordPress dashboard.
 *
 * @package MapFusion
 */

namespace MapFusion;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly. //
}

/**
 * Handles the enqueueing of admin scripts and styles for MapFusion.
 *
 * This class ensures that all necessary JavaScript and CSS files
 * required for the admin interface are properly loaded.
 */
class Admin_Scripts {

	/**
	 * Initialize hooks for admin scripts and styles.
	 */
	public static function init() {
		Debug::initializing( 'Initializing admin scripts and styles.' );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_scripts_and_styles' ) );
		self::initialize_privacy_policy_notice();
	}

	/**
	 * Enqueue admin scripts and styles.
	 *
	 * @param string $hook The current admin page hook.
	 */
	public static function enqueue_scripts_and_styles( $hook ) {
		Debug::initializing( 'Current hook: ' . esc_html( $hook ) );

		// Generate nonce for reuse. //
		$nonce = wp_create_nonce( 'mapfusion_nonce' );

		// API Key Management Page. //
		if ( 'mapfusion_page_api-key-management' === $hook ) {
			Debug::initializing( 'Enqueueing scripts for API Key Management page.' );
			self::enqueue_script(
				'mapfusion-api-key-management-js',
				'js/api-key-management.js',
				'mapfusion_api_key_settings',
				array(
					'ajax_url' => admin_url( 'admin-ajax.php' ),
					'nonce'    => $nonce,
				),
				true
			);
		}

		// License Key Management Page. //
		if ( 'mapfusion_page_license-key-management' === $hook ) {
			Debug::initializing( 'Enqueueing scripts for License Key Management page.' );
			self::enqueue_script(
				'mapfusion-license-key-management-js',
				'js/license-key-management.js',
				'mapfusion_license_key_settings',
				array(
					'ajax_url' => admin_url( 'admin-ajax.php' ),
					'nonce'    => $nonce,
				),
				true
			);
		}

		// Maps Overview Page (no scripts needed). //
		if ( 'mapfusion_page_maps-overview' === $hook ) {
			Debug::info( 'No scripts enqueued for Maps Overview page.' );
		}

		// Settings Page. //
		if ( 'mapfusion_page_settings' === $hook ) {
			Debug::info( 'Enqueueing scripts for Settings page.' );
			self::enqueue_script(
				'debug-settings-js',
				'js/debug-settings.js',
				'mapfusion_debug_settings',
				array(
					'ajax_url' => admin_url( 'admin-ajax.php' ),
					'nonce'    => $nonce,
				),
				true
			);
		}

		// Make Management Page. //
		if ( 'mapfusion_page_make-management' === $hook ) {
			Debug::info( 'Enqueueing scripts for Make Management page.' );
			self::enqueue_script(
				'make-api-management-js',
				'js/make-api-management.js',
				'mapfusion_make_settings',
				array(
					'ajax_url' => admin_url( 'admin-ajax.php' ),
					'nonce'    => $nonce,
				),
				true
			);
		}

		// Database Management Page. //
		if ( 'mapfusion_page_database' === $hook ) {
			Debug::initializing( 'Enqueueing scripts for Database Management page.' );
			self::enqueue_script(
				'database-tools-js',
				'js/database-tools.js',
				'mapfusion_database',
				array(
					'ajax_url' => admin_url( 'admin-ajax.php' ),
					'nonce'    => $nonce,
				),
				true
			);
		}

		// Support Page (no scripts needed). //
		if ( 'mapfusion_page_support' === $hook ) {
			Debug::initializing( 'No scripts enqueued for Support page.' );
		}

		// Shared scripts and styles for all MapFusion pages. //
		if ( strpos( $hook, 'mapfusion' ) === 0 ) {
			Debug::initializing( 'Enqueueing shared styles for MapFusion pages.' );
			self::enqueue_styles(
				array(
					'mapfusion-button-css' => 'css/button.css',
					'mapfusion-text-css'   => 'css/text.css',
					'mapfusion-input-css'  => 'css/input.css',
					'mapfusion-layout-css' => 'css/layout.css',
					'mapfusion-table-css'  => 'css/table.css',
					'mapfusion-debug-css'  => 'css/debug.css',
				)
			);
		}

		// Dismiss Notice Script. //
		Debug::initializing( 'Enqueueing Dismiss Notice script.' );
		self::enqueue_script(
			'mapfusion-dismiss-notice-js',
			'js/dismiss-notice.js',
			null,
			array(),
			true
		);
	}

	/**
	 * Helper function to enqueue a script with optional localization.
	 *
	 * @param string      $handle The script handle.
	 * @param string      $path The script path relative to the plugin directory.
	 * @param string|null $localize_var Optional: The name of the localized variable.
	 * @param array|null  $localize_data Optional: The data to localize.
	 */
	private static function enqueue_script( $handle, $path, $localize_var = null, $localize_data = null ) {
		Debug::initializing( "Attempting to enqueue script: {$handle} at path: {$path}" );

		if ( ! wp_script_is( $handle, 'enqueued' ) ) {
			wp_register_script(
				$handle,
				plugins_url( $path, __DIR__ ),
				array( 'jquery' ),
				MAPFUSION_VERSION,
				true
			);

			if ( $localize_var && $localize_data ) {
				Debug::initializing( "Localizing script {$handle} with variable {$localize_var}." );
				wp_localize_script( $handle, $localize_var, $localize_data );
			}

			wp_enqueue_script( $handle );
			Debug::initializing( "Script {$handle} enqueued successfully." );
		} else {
			Debug::initializing( "Script {$handle} is already enqueued." );
		}
	}

	/**
	 * Helper function to enqueue multiple styles.
	 *
	 * @param array $styles Array of style handles and their paths.
	 */
	private static function enqueue_styles( $styles ) {
		foreach ( $styles as $handle => $path ) {
			Debug::initializing( "Attempting to enqueue style: {$handle} at path: {$path}" );

			if ( ! wp_style_is( $handle, 'enqueued' ) ) {
				wp_enqueue_style(
					$handle,
					plugins_url( $path, __DIR__ ),
					array(),
					MAPFUSION_VERSION
				);
				Debug::initializing( "Style {$handle} enqueued successfully." );
			} else {
				Debug::initializing( "Style {$handle} is already enqueued." );
			}
		}
	}

	/**
	 * Initialize Privacy Policy Notice.
	 */
	public static function initialize_privacy_policy_notice() {
		Debug::initializing( 'Initializing Privacy Policy Notice.' );

		if ( class_exists( 'MapFusion\Privacy_Policy_Notice' ) ) {
			Privacy_Policy_Notice::init();
			Debug::initializing( 'Privacy Policy Notice initialized successfully.' );
		} else {
			Debug::error( 'Privacy Policy Notice class not found!' );
		}
	}
}

// Initialize the class hooks.
Admin_Scripts::init();
