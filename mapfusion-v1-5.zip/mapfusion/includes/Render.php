<?php
/**
 * Admin Page Rendering for MapFusion.
 *
 * This file defines the `Render` class, responsible for rendering
 * the admin pages and interface elements for the MapFusion plugin.
 *
 * @package MapFusion
 */

namespace MapFusion;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly. //
}

/**
 * Handles rendering of admin pages for MapFusion.
 *
 * This class is responsible for displaying and rendering the admin
 * pages in the WordPress dashboard, including settings and management
 * pages for the MapFusion plugin.
 */
class Render {


	/**
	 * Initializes the Render class.
	 */
	public static function init() {
		Debug::initializing( '[Render] Initializing Render class.' );
		$instance = new self();
		add_action( 'admin_menu', array( $instance, 'register_admin_menu' ) );
	}

	/**
	 * Registers the admin menu and submenus for MapFusion.
	 */
	public function register_admin_menu() {
		Debug::initializing( '[Render] Registering admin menu and submenus.' );

		// Add main menu. //
		add_menu_page(
			__( 'MapFusion', 'mapfusion' ),
			__( 'MapFusion', 'mapfusion' ),
			'manage_options',
			'mapfusion',
			array( $this, 'render_welcome_page' ),
			'dashicons-admin-site',
			20
		);

		// Add submenus in the desired order. //
		$this->add_submenu( __( 'API Key Management', 'mapfusion' ), 'api-key-management', array( $this, 'render_api_key_management_page' ) );
		$this->add_submenu( __( 'Maps Overview', 'mapfusion' ), 'maps-overview', array( $this, 'render_maps_markers_page' ) );
		$this->add_submenu( __( 'Settings', 'mapfusion' ), 'settings', array( $this, 'render_settings_page' ) );
		$this->add_submenu( __( 'Make Management', 'mapfusion' ), 'make-management', array( $this, 'render_make_management_page' ) );
		$this->add_submenu( __( 'Database', 'mapfusion' ), 'database', array( $this, 'render_database_page' ) );
		$this->add_submenu( __( 'Support', 'mapfusion' ), 'support', array( $this, 'render_support_page' ) );
	}

	/**
	 * Adds a submenu for rendering pages.
	 *
	 * @param string   $page_title The title of the page.
	 * @param string   $menu_slug The slug for the submenu.
	 * @param callable $callback The callback function for rendering the page.
	 */
	private function add_submenu( $page_title, $menu_slug, $callback ) {
		Debug::initializing( "[Render] Adding submenu: {$page_title}" );
		add_submenu_page(
			'mapfusion',
			$page_title,
			$page_title,
			'manage_options',
			$menu_slug,
			$callback
		);
	}

	/**
	 * Renders the Welcome page.
	 */
	public function render_welcome_page() {
		$this->render_page( 'welcome', __( 'Welcome page file not found.', 'mapfusion' ) );
	}

	/**
	 * Renders the API Key Management page.
	 */
	public function render_api_key_management_page() {
		$this->render_page( 'api-key-management', __( 'API Key Management page file not found.', 'mapfusion' ) );
	}

	/**
	 * Renders the Maps Overview page.
	 */
	public function render_maps_markers_page() {
		global $wpdb;

		// Fetch debug status from settings. //
		$debug_status = get_option( 'mapfusion_debug_logging', false );

		// Cache keys for maps and markers. //
		$maps_cache_key    = 'mapfusion_maps_list';
		$markers_cache_key = 'mapfusion_markers_list';

		// Attempt to retrieve cached maps and markers. //
		$maps    = wp_cache_get( $maps_cache_key, 'mapfusion' );
		$markers = wp_cache_get( $markers_cache_key, 'mapfusion' );

		if ( false === $maps ) {
			// Cache miss, fetch from database. //
			$maps = $wpdb->get_results(
				"SELECT id, map_title, map_start_lat, map_start_lng, map_width, map_height FROM {$wpdb->prefix}wpgmza_maps",
				ARRAY_A
			);

			// Store in cache (10-minute expiration). //
			wp_cache_set( $maps_cache_key, $maps, 'mapfusion', 600 );
		}

		if ( false === $markers ) {
			// Cache miss, fetch from database. //
			$markers = $wpdb->get_results(
				"SELECT id, map_id, title, lat, lng, address, description FROM {$wpdb->prefix}wpgmza",
				ARRAY_A
			);

			// Store in cache (10-minute expiration). //
			wp_cache_set( $markers_cache_key, $markers, 'mapfusion', 600 );
		}

		$html_file_path = plugin_dir_path( __FILE__ ) . '../html/maps-overview.html';

		if ( file_exists( $html_file_path ) ) {
			ob_start();
			include $html_file_path;
			$html_content = ob_get_clean();

			// Ensure output is properly escaped. //
			echo wp_kses_post( $html_content );
		} else {
			$this->render_error_message(
				__( 'Maps Overview page file not found.', 'mapfusion' )
			);
		}
	}

	/**
	 * Renders the Settings page.
	 */
	public static function render_settings_page() {
		Debug::initializing( '[Settings] Rendering settings page.' );

		$html_file_path = plugin_dir_path( __FILE__ ) . '../html/settings.html';

		if ( ! file_exists( $html_file_path ) ) {
			Debug::warning( '[Settings] Settings HTML file NOT found.' );
			echo '<div class="notice notice-error"><p>' . esc_html__( 'Settings page file not found.', 'mapfusion' ) . '</p></div>';
			return;
		}

		// Start output buffering.
		ob_start();
		include $html_file_path;
		$html_content = ob_get_clean();

		// Output the content without overly strict filtering.
		if ( ! empty( $html_content ) ) {
			echo $html_content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		} else {
			echo '<p>' . esc_html__( 'No content available.', 'mapfusion' ) . '</p>';
		}

		Debug::initializing( '[Settings] Settings page rendered successfully.' );
	}

	/**
	 * Renders the Make Management page.
	 */
	public function render_make_management_page() {
		$this->render_page( 'make-management', __( 'Make Management page file not found.', 'mapfusion' ) );
	}

	/**
	 * Renders the Database page.
	 */
	public function render_database_page() {
		$this->render_page( 'database', __( 'Database page file not found.', 'mapfusion' ) );
	}

	/**
	 * Renders the Support page.
	 */
	public function render_support_page() {
		$this->render_page( 'support-documentation', __( 'Support page file not found.', 'mapfusion' ) );
	}

	/**
	 * Generic method to render pages.
	 *
	 * @param string $file_slug The slug of the file to include.
	 * @param string $error_message The error message to display if the file is not found.
	 */
	private function render_page( $file_slug, $error_message ) {
		$html_file_path = plugin_dir_path( __FILE__ ) . "../html/{$file_slug}.html";

		if ( file_exists( $html_file_path ) ) {
			Debug::initializing( "[Render] {$file_slug} HTML file found." );
			include $html_file_path;
		} else {
			Debug::warning( "[Render] {$file_slug} HTML file NOT found." );
			$this->render_error_message( $error_message );
		}
	}

	/**
	 * Renders an error message.
	 *
	 * @param string $message The error message to display.
	 */
	private function render_error_message( $message ) {
		Debug::error( "[Render] Error: {$message}" );
		echo '<div class="notice notice-error"><p>' . esc_html( $message ) . '</p></div>';
	}
}

// Hook to initialize the menu. //
if ( class_exists( '\MapFusion\Render' ) ) {
	Debug::initializing( '[Render] Initializing Render class.' );
	add_action( 'plugins_loaded', array( '\MapFusion\Render', 'init' ) );
} else {
	Debug::critical( '[Render] Render class not found!' );
}
