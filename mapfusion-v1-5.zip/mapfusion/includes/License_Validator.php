<?php
/**
 * License Validation for MapFusion.
 *
 * This file defines the `License_Validator` class, responsible for
 * validating license keys using the Appsero service to ensure
 * authorized plugin usage.
 *
 * @package MapFusion
 */

namespace MapFusion;

use MapFusion\Debug;
use WP_REST_Request;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly. //
}

/**
 * Handles license validation for MapFusion.
 *
 * This class interacts with Appsero to verify license keys,
 * ensuring that only authorized users can access premium
 * features of the plugin.
 */
class License_Validator {

	/**
	 * Validates the license directly from a REST request.
	 *
	 * @param WP_REST_Request $request The request object.
	 * @return array An associative array containing validation results.
	 */
	public static function validate_license_from_request( WP_REST_Request $request ) {
		Debug::info( '[validate_license_from_request] Starting license validation.' );

		// Extract the license key. //
		$license_key = self::extract_license_key_from_request( $request );

		// Check if the license key is missing. //
		if ( empty( $license_key ) ) {
			Debug::warning( '[validate_license_from_request] License key is missing.' );
			return array(
				'success' => false,
				'message' => 'License key is missing.',
			);
		}

		// Validate the license key. //
		if ( self::validate_license_key( $license_key ) ) {
			Debug::info( '[validate_license_from_request] License key is valid.' );
			return array(
				'success' => true,
				'message' => 'License key is valid.',
			);
		}

		Debug::error( '[validate_license_from_request] Invalid license key.' );
		return array(
			'success' => false,
			'message' => 'Invalid license key.',
		);
	}

	/**
	 * Extracts the license key from the headers or request parameters.
	 *
	 * @param WP_REST_Request $request The request object.
	 * @return string|null The extracted license key.
	 */
	public static function extract_license_key_from_request( WP_REST_Request $request ) {
		$headers              = $request->get_headers();
		$authorization_header = isset( $headers['authorization'][0] ) ? $headers['authorization'][0] : '';

		Debug::info( '[extract_license_key_from_request] Authorization header: ' . ( ! empty( $authorization_header ) ? $authorization_header : 'Not provided' ) );

		if ( preg_match( '/License\s+(\S+)/', $authorization_header, $matches ) ) {
			Debug::info( '[extract_license_key_from_request] Extracted License Key from Authorization header.' );
			return $matches[1];
		}

		$license_key = $request->get_param( 'license_key' );
		Debug::info( '[extract_license_key_from_request] Extracted License Key from request parameter: ' . ( ! empty( $license_key ) ? $license_key : 'Not provided' ) );

		return $license_key;
	}

	/**
	 * Validates a license key using MapFusion's own license server.
	 *
	 * @param string $license_key The license key to validate.
	 * @return bool True if valid, false otherwise.
	 */
	public static function validate_license_key( $license_key ) {
		Debug::info( '[validate_license_key] Starting license key validation.' );

		if ( empty( $license_key ) ) {
			Debug::warning( '[validate_license_key] License key validation failed: Key is missing.' );
			return false;
		}

		Debug::info( '[validate_license_key] License key to validate: ' . $license_key );

		try {
			// Call the new license validation API
			$response = wp_remote_get(
				'https://www.mapfusion.site/wp-json/mapfusionpro/v1/validate-license',
				array(
					'headers' => array(
						'Authorization' => 'Bearer ' . $license_key,
						'Accept'        => 'application/json',
					),
					'timeout' => 10,
				)
			);

			// Check if the request failed
			if ( is_wp_error( $response ) ) {
				Debug::error( '[validate_license_key] Failed to connect to license server: ' . $response->get_error_message() );
				return false;
			}

			// Parse response
			$body = json_decode( wp_remote_retrieve_body( $response ), true );

			Debug::info( '[validate_license_key] Response from MapFusion License Server: ' . wp_json_encode( $body, JSON_PRETTY_PRINT ) );

			// Validate the response
			if ( isset( $body['status'] ) && 'valid' === $body['status'] ) {
				Debug::info( '[validate_license_key] License key validated successfully.' );
				return true;
			}

			$error_message = $body['message'] ?? 'Unknown error';
			Debug::error( '[validate_license_key] License validation failed: ' . $error_message );
			return false;

		} catch ( \Exception $e ) {
			Debug::critical( '[validate_license_key] Exception occurred during license validation: ' . $e->getMessage() );
			return false;
		}
	}
}
