<?php
/**
 * REST API initialization and authorization for MapFusion.
 *
 * This file defines the `Rest_API` class, responsible for initializing
 * and handling authentication for REST API endpoints in MapFusion.
 *
 * @package MapFusion
 */

namespace MapFusion;

use MapFusion\Debug;
use MapFusion\WPGM_Integration;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly. //
}

/**
 * Class for handling REST API initialization and authorization for MapFusion.
 *
 * This class is responsible for registering REST API routes,
 * managing authentication, and ensuring secure access control.
 */
class Rest_API {

	/**
	 * Load and initialize all required API classes and utilities for MapFusion.
	 */
	public static function load_api_classes() {
		try {
			Debug::initializing( '[load_api_classes] Starting to load all required API classes and utilities.' );

			$api_classes = array(
				\MapFusion\Api\Free\Maps_Free_API::class,
				\MapFusion\Api\Free\Markers_Free_API::class,
				\MapFusion\Api\Other_API::class,
			);

			foreach ( $api_classes as $api_class ) {
				if ( class_exists( $api_class ) ) {
					Debug::initializing( "[load_api_classes] Found class: {$api_class}" );
					$class_instance = new $api_class();
					if ( method_exists( $class_instance, 'register_routes' ) ) {
						$class_instance->register_routes();
						Debug::initializing( "[load_api_classes] Routes registered for class: {$api_class}" );
					} else {
						Debug::warning( "[load_api_classes] Class {$api_class} does not have a 'register_routes' method." );
					}
				} else {
					Debug::warning( "[load_api_classes] Class {$api_class} not found. Attempting to load fallback file..." );
					$relative_path = str_replace( array( '\\' ), DIRECTORY_SEPARATOR, $api_class );
					$relative_path = preg_replace( '/^MapFusion\\\\/', '', $relative_path );

					$class_file = __DIR__ . DIRECTORY_SEPARATOR . $relative_path . '.php';

					if ( file_exists( $class_file ) ) {
						require_once $class_file;
						if ( class_exists( $api_class ) ) {
							Debug::initializing( "[load_api_classes] Class {$api_class} loaded successfully from fallback file." );
							$class_instance = new $api_class();
							if ( method_exists( $class_instance, 'register_routes' ) ) {
								$class_instance->register_routes();
								Debug::initializing( "[load_api_classes] Routes registered for class: {$api_class}" );
							} else {
								Debug::warning( "[load_api_classes] Class {$api_class} does not have a 'register_routes' method." );
							}
						} else {
							Debug::error( "[load_api_classes] Class {$api_class} could not be found even after including fallback file." );
						}
					} else {
						Debug::error( "[load_api_classes] Fallback file for class {$api_class} not found: {$class_file}" );
					}
				}
			}

			Debug::initializing( '[load_api_classes] All classes have been loaded and initialized successfully.' );
		} catch ( \Exception $e ) {
			Debug::critical( '[load_api_classes] Error loading API classes: ' . $e->getMessage() );
		}
	}

	/**
	 * Verify the Bearer token for API key validation.
	 *
	 * @param \WP_REST_Request $request The incoming REST API request.
	 * @return true|\WP_Error True if valid, otherwise WP_Error.
	 */
	public static function verify_bearer_token( $request ) {
		$headers              = $request->get_headers();
		$authorization_header = $headers['authorization'][0] ?? null;

		if ( ! $authorization_header ) {
			Debug::warning( '[verify_bearer_token] Authorization header is missing.' );
			return new \WP_Error( 'unauthorized', __( 'Authorization header is missing.', 'mapfusion' ), array( 'status' => 401 ) );
		}

		if ( preg_match( '/Bearer\s+(\S+)/', $authorization_header, $matches ) ) {
			$bearer_token = $matches[1];
			$saved_token  = get_option( 'mapfusion_api_key', '' );

			if ( hash_equals( $saved_token, $bearer_token ) ) {
				Debug::api( '[verify_bearer_token] Bearer token validated successfully.' );
				return true;
			}

			Debug::warning( '[verify_bearer_token] Bearer token validation failed.' );
			return new \WP_Error( 'unauthorized', __( 'Invalid API Key.', 'mapfusion' ), array( 'status' => 401 ) );
		}

		Debug::error( '[verify_bearer_token] Bearer token is malformed or missing.' );
		return new \WP_Error( 'unauthorized', __( 'Bearer token is malformed or missing.', 'mapfusion' ), array( 'status' => 401 ) );
	}

	/**
	 * Fetches paginated results from the database.
	 *
	 * @param string $query The base SQL query without LIMIT and OFFSET.
	 * @param int    $limit The number of results to fetch.
	 * @param int    $offset The starting point for the results.
	 * @return array The paginated results.
	 */
	public static function fetch_paginated_results( $query, $limit = 100, $offset = 0 ) {
		global $wpdb;

		// Ensure pagination parameters are properly set and safe. //
		$limit  = intval( $limit );
		$offset = intval( $offset );

		// Limit maximum value for security. //
		$limit = min( $limit, 1000 );

		// Generate a cache key based on the query parameters. //
		$cache_key = 'mapfusion_paginated_results_' . md5( $query . '_' . $limit . '_' . $offset );
		$results   = wp_cache_get( $cache_key, 'mapfusion' );

		if ( false === $results ) {
			// Append pagination to the query safely. //
			$paginated_query = $query . ' LIMIT %d OFFSET %d';

			// Prepare the full query safely. //
			$prepared_query = $wpdb->prepare( $paginated_query, $limit, $offset );

			Debug::api( 'Executing paginated query.', array( 'query' => $prepared_query ) );

			// Fetch the results from the database. //
			$results = $wpdb->get_results( $prepared_query, ARRAY_A );

			// Store the results in cache (e.g., 10-minute expiration). //
			if ( ! empty( $results ) ) {
				wp_cache_set( $cache_key, $results, 'mapfusion', 600 );
			}
		}

		// If query fails, log it and return an empty array. //
		if ( null === $results ) {
			Debug::critical(
				'Database query failed.',
				array(
					'query'  => $query,
					'limit'  => $limit,
					'offset' => $offset,
				)
			);
						return array();
		}

		return $results;
	}

	/**
	 * Create necessary directories for import and export upon plugin activation
	 */
	public static function create_export_import_directories() {
		// Get the WordPress uploads directory.
		$upload_dir = trailingslashit( wp_upload_dir()['basedir'] ) . 'mapfusion';

		// Initialize WP Filesystem if it's not already done
		if ( empty( $GLOBALS['wp_filesystem'] ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			WP_Filesystem();
		}

		// Check if the 'mapfusion' main directory exists, create it if not
		if ( ! $GLOBALS['wp_filesystem']->exists( $upload_dir ) ) {
			if ( ! $GLOBALS['wp_filesystem']->mkdir( $upload_dir ) ) {
				// Log an error if the main 'mapfusion' directory could not be created
				Debug::critical( 'Failed to create mapfusion directory.', array( 'directory' => $upload_dir ) );
				return false;
			}
			// Log info if the 'mapfusion' directory was successfully created
			Debug::info( 'Mapfusion directory created successfully.', array( 'directory' => $upload_dir ) );
		}

		// Define the paths for export and import directories
		$export_dir = $upload_dir . '/export';
		$import_dir = $upload_dir . '/import';

		// Create the export directory if it does not exist
		if ( ! $GLOBALS['wp_filesystem']->exists( $export_dir ) ) {
			if ( ! $GLOBALS['wp_filesystem']->mkdir( $export_dir ) ) {
				Debug::critical( 'Failed to create export directory.', array( 'directory' => $export_dir ) );
				return false;
			}
			Debug::info( 'Export directory created successfully.', array( 'directory' => $export_dir ) );
		}

		// Create the import directory if it does not exist
		if ( ! $GLOBALS['wp_filesystem']->exists( $import_dir ) ) {
			if ( ! $GLOBALS['wp_filesystem']->mkdir( $import_dir ) ) {
				Debug::critical( 'Failed to create import directory.', array( 'directory' => $import_dir ) );
				return false;
			}
			Debug::info( 'Import directory created successfully.', array( 'directory' => $import_dir ) );
		}

		// Ensure the directories are writable using WP_Filesystem methods
		if ( ! $GLOBALS['wp_filesystem']->is_writable( $export_dir ) ) {
			Debug::warning( 'Export directory is not writable, permissions might need adjusting.', array( 'directory' => $export_dir ) );

			// Adjust permissions if needed
			if ( ! $GLOBALS['wp_filesystem']->chmod( $export_dir, FS_CHMOD_DIR ) ) {
				Debug::critical( 'Failed to set writable permissions on the export directory.', array( 'directory' => $export_dir ) );
				return false;
			}
		}

		if ( ! $GLOBALS['wp_filesystem']->is_writable( $import_dir ) ) {
			Debug::warning( 'Import directory is not writable, permissions might need adjusting.', array( 'directory' => $import_dir ) );

			// Adjust permissions if needed
			if ( ! $GLOBALS['wp_filesystem']->chmod( $import_dir, FS_CHMOD_DIR ) ) {
				Debug::critical( 'Failed to set writable permissions on the import directory.', array( 'directory' => $import_dir ) );
				return false;
			}
		}

		return true;
	}
}

// Hook into REST API initialization. //
add_action(
	'rest_api_init',
	function () {
		Debug::initializing( '[rest_api_init] Attempting to initialize MapFusion Rest_API class.' );

		// First, check if the class exists before proceeding with fallback. //
		if ( class_exists( '\\MapFusion\\Rest_API' ) ) {
			Debug::initializing( '[rest_api_init] MapFusion Rest_API class found. Initializing...' );
			\MapFusion\Rest_API::load_api_classes();
			return;
		}

		// If the class doesn't exist, check if the fallback file exists. //
		$fallback_file = __DIR__ . '/includes/class-mapfusion-rest-api.php';

		if ( file_exists( $fallback_file ) ) {
			require_once $fallback_file;
			Debug::info( '[rest_api_init] Fallback file included: ' . $fallback_file );
		} else {
			Debug::critical( '[rest_api_init] Fallback file not found: ' . $fallback_file );
			return;
		}

		// After including the fallback, verify if the class is now available. //
		if ( class_exists( '\\MapFusion\\Rest_API' ) ) {
			Debug::info( '[rest_api_init] Fallback succeeded. Initializing MapFusion Rest_API class...' );
			\MapFusion\Rest_API::load_api_classes();
		} else {
			Debug::critical( '[rest_api_init] Failed to initialize MapFusion Rest_API class even after including fallback.' );
		}
	}
);

// Hook to run when the plugin is activated
register_activation_hook( __FILE__, 'mapfusion_create_export_import_directories' );
