<?php
/**
 * Database Management for MapFusion.
 *
 * This file defines the `Database` class, responsible for
 * handling all database interactions, including queries,
 * data retrieval, and caching for the MapFusion plugin.
 *
 * @package MapFusion
 */

namespace MapFusion;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly. //
}

/**
 * Handles database interactions for the MapFusion plugin.
 *
 * This class provides methods for safely querying the database,
 * caching results, and managing stored data related to maps and markers.
 */
class Database {


	/**
	 * Database table name for storing settings.
	 *
	 * @var string
	 */
	private static $table_name;

	/**
	 * Initialize the database table name.
	 */
	public static function init() {
		global $wpdb;
		self::$table_name = $wpdb->prefix . 'mapfusion_settings';
	}

	/**
	 * Create the database table if it doesn't exist.
	 */
	public static function create_database_table() {
		global $wpdb;

		self::init();  // Ensure table name is set. //

		// SQL query to create the table. //
		$sql = 'CREATE TABLE IF NOT EXISTS ' . self::$table_name . ' (
            id BIGINT(20) NOT NULL AUTO_INCREMENT,
            setting_key VARCHAR(255) NOT NULL,
            setting_value LONGTEXT NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE (setting_key)
        );';

		// Require the necessary file to run dbDelta. //
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		// Run the query to create the table if it doesn't exist. //
		dbDelta( $sql );

		// Log success. //
		Debug::info( '[Database] Table created or already exists: ' . self::$table_name );
	}

	/**
	 * Get a setting value from the database.
	 *
	 * @param string $key The setting key.
	 * @param mixed  $default_value The default value if the setting is not found.
	 * @return mixed The setting value or default.
	 */
	public static function get_setting( $key, $default_value = null ) {
		global $wpdb;

		// Define the table name securely. //
		$table_name = $wpdb->prefix . 'mapfusion_settings';

		// Generate a cache key for this setting. //
		$cache_key    = "mapfusion_setting_{$key}";
		$cached_value = wp_cache_get( $cache_key, 'mapfusion' );

		if ( false !== $cached_value ) {
			return maybe_unserialize( $cached_value );
		}

		// Verify the table exists safely. //
		$table_exists = $wpdb->get_var(
			$wpdb->prepare(
				'SHOW TABLES LIKE %s',
				$wpdb->esc_like( $table_name )
			)
		);

		if ( null === $table_exists ) {
			Debug::critical( '[Database] Table does not exist: ' . esc_html( $table_name ) );
			return $default_value;
		}

		// Fetch the setting value from the database. //
		$value = $wpdb->get_var(
			$wpdb->prepare(
				'SELECT setting_value FROM ' . $table_name . ' WHERE setting_key = %s',
				$key
			)
		);

		// Cache the value to improve performance. //
		if ( null !== $value ) {
			wp_cache_set( $cache_key, $value, 'mapfusion', 600 );
			return maybe_unserialize( $value );
		}

		return $default_value;
	}

	/**
	 * Update a setting value in the database.
	 *
	 * @param string $key The setting key.
	 * @param mixed  $value The setting value.
	 * @return bool True on success, false on failure.
	 */
	public static function update_setting( $key, $value ) {
		global $wpdb;

		// Define the table name securely. //
		$table_name = $wpdb->prefix . 'mapfusion_settings';

		// Verify the table exists safely. //
		$table_exists = $wpdb->get_var(
			$wpdb->prepare(
				'SHOW TABLES LIKE %s',
				$wpdb->esc_like( $table_name )
			)
		);

		if ( null === $table_exists ) {
			Debug::critical( '[Database] Table does not exist: ' . esc_html( $table_name ) );
			return false;
		}

		// Sanitize input values. //
		$key        = sanitize_key( $key );
		$value      = maybe_serialize( $value );
		$updated_at = current_time( 'mysql' );

		// Use `$wpdb->prepare()` to ensure proper SQL escaping. //
		$result = $wpdb->query(
			$wpdb->prepare(
				'REPLACE INTO ' . $table_name . ' (setting_key, setting_value, updated_at) VALUES ( %s, %s, %s )',
				$key,
				$value,
				$updated_at
			)
		);

		if ( false !== $result ) {
			Debug::info( '[Database] Setting updated successfully: ' . esc_html( $key ), array( 'value' => $value ) );

			// Cache the updated setting. //
			wp_cache_set( "mapfusion_setting_{$key}", $value, 'mapfusion', 600 );
			return true;
		} else {
			Debug::error( '[Database] Failed to update setting: ' . esc_html( $key ), array( 'value' => $value ) );
			return false;
		}
	}

	/**
	 * Reset all settings in the custom database table.
	 */
	public static function reset_settings() {
		global $wpdb;

		// Define the table name securely. //
		$table_name = $wpdb->prefix . 'mapfusion_settings';

		// Verify the table exists securely. //
		$table_exists = $wpdb->get_var(
			$wpdb->prepare(
				'SHOW TABLES LIKE %s',
				$wpdb->esc_like( $table_name )
			)
		);

		if ( null === $table_exists ) {
			Debug::critical( '[Database] Table does not exist: ' . esc_html( $table_name ) );
			return;
		}

		// Securely delete all settings. //
		$result = $wpdb->query( "DELETE FROM {$table_name}" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		if ( false !== $result ) {
			Debug::info( '[Database] All settings have been reset.' );

			// Invalidate related cached settings. //
			wp_cache_delete( 'mapfusion_settings', 'mapfusion' );
			wp_cache_delete( 'mapfusion_zone_url', 'mapfusion' );
		} else {
			Debug::error( '[Database] Failed to reset settings.' );
		}
	}

	/**
	 * Get default values for settings.
	 *
	 * @return array An associative array of default values.
	 */
	public static function get_default_values() {
		return array(
			'debug_logging' => false,
			'debug_levels'  => array( 'error', 'warning', 'info' ),
			'zone'          => 'EU1',
		);
	}
}

// Hook the initialization to WordPress. //
add_action( 'init', array( Database::class, 'init' ) );
