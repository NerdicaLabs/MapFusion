<?php
/**
 * Make API Settings for MapFusion.
 *
 * This file defines the `MakeSettings` class, responsible for
 * handling settings and configurations related to Make API
 * zones, scopes, and integrations.
 *
 * @package MapFusion
 */

namespace MapFusion;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly. //
}

/**
 * Handles settings and configurations related to Make API zones and scopes.
 *
 * This class provides methods to manage API configurations, including
 * zone settings.
 */
class MakeSettings {

	/**
	 * List of valid zones with their corresponding base URLs.
	 * Zones are stored in lowercase for consistency.
	 */
	const VALID_ZONES = array(
		'eu1' => 'https://eu1.make.com',
		'eu2' => 'https://eu2.make.com',
		'us1' => 'https://us1.make.com',
		'us2' => 'https://us2.make.com',
	);

	/**
	 * Get the required scopes for the plugin.
	 *
	 * @return array The list of required scopes.
	 */
	public static function get_scopes() {
		return array(
			'user:read',
			'user:write',
			'organizations:read',
			'organizations:write',
			'teams:read',
			'teams:write',
			'connections:read',
			'connections:write',
		);
	}

	/**
	 * Convert a zone to its corresponding base URL.
	 *
	 * @param string $zone The zone identifier.
	 * @return string|null The base URL or null if the zone is invalid.
	 */
	public static function get_zone_baseurl( $zone ) {
		$zone_lower = strtolower( $zone );
		return self::VALID_ZONES[ $zone_lower ] ?? null;
	}

	/**
	 * Format a zone name to uppercase for display purposes.
	 *
	 * @param string $zone The zone identifier.
	 * @return string|null The formatted zone in uppercase or null if invalid.
	 */
	public static function format_zone( $zone ) {
		$zone_lower = strtolower( $zone );
		return array_key_exists( $zone_lower, self::VALID_ZONES ) ? strtoupper( $zone_lower ) : null;
	}

	/**
	 * Get a list of valid zones for a dropdown menu.
	 * Zones are returned in lowercase format for backend usage.
	 *
	 * @return array List of zones in lowercase format.
	 */
	public static function get_zones_for_dropdown() {
		return array_keys( self::VALID_ZONES );
	}

	/**
	 * Get the short URL format for a zone (e.g., "eu2.make.com").
	 *
	 * @param string $zone The zone identifier.
	 * @return string|null The short URL or null if invalid.
	 */
	public static function get_zone_shorturl( $zone ) {
		$zone_lower = strtolower( $zone );
		return array_key_exists( $zone_lower, self::VALID_ZONES ) ? "$zone_lower.make.com" : null;
	}
}
