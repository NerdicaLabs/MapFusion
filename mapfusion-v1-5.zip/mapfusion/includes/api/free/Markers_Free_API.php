<?php
/**
 * Free Markers API for MapFusion.
 *
 * This file defines the Free Markers API class, responsible for handling
 * REST API routes related to markers in the free version of MapFusion.
 *
 * @package MapFusion\Api\Free
 */

namespace MapFusion\Api\Free;

use WP_REST_Response;
use MapFusion\Rest_API;
use MapFusion\Debug;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly. //
}

/**
 * Handles Free Markers REST API routes for MapFusion.
 *
 * This class manages the REST API endpoints for basic marker-related
 * operations available in the free version of MapFusion, such as
 * creating, retrieving, updating, and deleting markers.
 */
class Markers_Free_API {

	/**
	 * Registers Free Markers REST API routes.
	 */
	public function register_routes() {
		Debug::Initializing( 'Registering routes for Markers_Free_API.' );

		register_rest_route(
			'mapfusion/v1',
			'/list-markers',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'list_markers_callback' ),
				'args'                => array(
					'map_id' => array(
						'required'          => false,
						'validate_callback' => function ( $param ) {
							return is_numeric( $param ) && $param > 0;
						},
						'description'       => 'Optional Map ID to filter markers.',
					),
					'limit'  => array(
						'required'          => false,
						'validate_callback' => function ( $param ) {
							return is_numeric( $param ) && $param > 0;
						},
						'default'           => 100,
						'description'       => 'Maximum number of markers to retrieve. Default is 100.',
					),
					'offset' => array(
						'required'          => false,
						'validate_callback' => function ( $param ) {
							return is_numeric( $param ) && $param >= 0;
						},
						'default'           => 0,
						'description'       => 'Offset for pagination. Default is 0.',
					),
				),
				'permission_callback' => array( Rest_API::class, 'verify_bearer_token' ),
			)
		);

		Debug::initializing( 'Registered route: /mapfusion/v1/list-markers.' );

		register_rest_route(
			'mapfusion/v1',
			'/add-marker',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'add_marker_callback' ),
				'permission_callback' => array( Rest_API::class, 'verify_bearer_token' ),
			)
		);

		register_rest_route(
			'mapfusion/v1',
			'/search-markers',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'search_markers_callback' ),
				'args'                => array(
					'term'   => array(
						'required'          => false,
						'validate_callback' => function ( $param ) {
							return is_string( $param );
						},
						'description'       => 'Search term to filter markers.',
					),
					'limit'  => array(
						'required'          => false,
						'validate_callback' => function ( $param ) {
							return is_numeric( $param ) && $param > 0;
						},
						'description'       => 'Number of results to return.',
					),
					'offset' => array(
						'required'          => false,
						'validate_callback' => function ( $param ) {
							return is_numeric( $param ) && $param >= 0;
						},
						'description'       => 'Offset for pagination.',
					),
				),
				'permission_callback' => array( Rest_API::class, 'verify_bearer_token' ),
			)
		);

		register_rest_route(
			'mapfusion/v1',
			'/get-marker-details/(?P<id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_marker_details_callback' ),
				'permission_callback' => array( Rest_API::class, 'verify_bearer_token' ),
			)
		);
	}

	/**
	 * Lists all markers with pagination.
	 *
	 * @param \WP_REST_Request $request The request object containing pagination parameters.
	 *                                  - 'map_id' (int) The ID of the map to retrieve markers from.
	 *                                  - 'per_page' (int) Number of markers per page (default: 25).
	 *                                  - 'total_limit' (int) Maximum number of markers to retrieve (default: 100).
	 *                                  - 'offset' (int) The starting point for pagination (default: 0).
	 * @return \WP_REST_Response The response object containing the paginated list of markers.
	 */
	public function list_markers_callback( $request ) {
		global $wpdb;

		$map_id      = intval( $request->get_param( 'map_id' ) ?? 0 );
		$per_page    = intval( $request->get_param( 'per_page' ) ?? 25 );
		$total_limit = intval( $request->get_param( 'total_limit' ) ?? 100 );
		$offset      = intval( $request->get_param( 'offset' ) ?? 0 );
		$table_name  = $wpdb->prefix . 'wpgmza';

		// Debug: Input parameters. //
		Debug::api(
			'list_markers_callback called.',
			array(
				'map_id'      => $map_id,
				'per_page'    => $per_page,
				'total_limit' => $total_limit,
				'offset'      => $offset,
			)
		);

		// Generate a cache key based on map ID. //
		$cache_key = ! empty( $map_id ) ? 'mapfusion_total_markers_' . $map_id : 'mapfusion_total_markers_all';

		// Attempt to retrieve cached data. //
		$total_count = wp_cache_get( $cache_key, 'mapfusion' );

		if ( false === $total_count ) {
			// Ensure table name is safely handled. //
			$query      = 'SELECT COUNT(*) FROM ' . $table_name;
			$query_args = array();

			if ( ! empty( $map_id ) ) {
				$query       .= ' WHERE map_id = %d';
				$query_args[] = $map_id;
			}

			// Prepare and execute query securely. //
			$prepared_query = $wpdb->prepare( $query, ...$query_args );
			$total_count    = (int) $wpdb->get_var( $prepared_query );

			// Store in cache (e.g., 10-minute expiration). //
			if ( ! empty( $total_count ) ) {
				wp_cache_set( $cache_key, $total_count, 'mapfusion', 600 );
			}
		}

		// Debug: Total count of markers. //
		Debug::api(
			'Total marker count calculated.',
			array(
				'total_count' => $total_count,
			)
		);

		// Check if the offset is out of bounds. //
		if ( $offset >= $total_count ) {
			Debug::warning(
				'Offset exceeds total markers. Returning empty result.',
				array(
					'offset'      => $offset,
					'total_count' => $total_count,
				)
			);

			return new WP_REST_Response(
				array(
					'success'    => true,
					'markers'    => array(),
					'pagination' => array(
						'per_page'    => $per_page,
						'offset'      => $offset,
						'total_limit' => $total_limit,
						'total'       => $total_count,
						'count'       => 0,
						'total_pages' => ceil( $total_count / $per_page ),
					),
				),
				200
			);
		}

		// Build base query. //
		$base_query = "SELECT id, map_id, title, lat, lng, address, description, pic, link, icon FROM {$table_name}";
		if ( ! empty( $map_id ) ) {
			$base_query .= $wpdb->prepare( ' WHERE map_id = %d', $map_id );
		}

		// Fetch paginated results. //
		$markers = Rest_API::fetch_paginated_results( $base_query, $per_page, $offset );

		// Debug: Executed query and results fetched. //
		Debug::api(
			'Paginated markers fetched.',
			array(
				'query'         => $base_query,
				'fetched_count' => count( $markers ),
				'offset'        => $offset,
				'results'       => $markers,
			)
		);

		// If no markers found. //
		if ( empty( $markers ) ) {
			Debug::warning( 'No markers found.', array( 'map_id' => $map_id ) );

			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'No markers found.',
				),
				404
			);
		}

		// Transform results: Add "marker_id", and include "pic" and "icon". //
		$markers_transformed = array_map(
			function ( $marker ) {
				return array(
					'marker_id'   => $marker['id'], // Change "id" to "marker_id". //
					'map_id'      => $marker['map_id'],
					'title'       => $marker['title'],
					'lat'         => $marker['lat'],
					'lng'         => $marker['lng'],
					'address'     => $marker['address'],
					'description' => $marker['description'],
					'pic'         => $marker['pic'],
					'link'        => $marker['link'],
					'icon'        => $marker['icon'],
				);
			},
			$markers
		);

		// Construct response. //
		$response = array(
			'success'    => true,
			'markers'    => $markers_transformed,
			'pagination' => array(
				'per_page'    => $per_page,
				'offset'      => $offset,
				'total_limit' => $total_limit,
				'total'       => $total_count,
				'count'       => count( $markers_transformed ),
				'total_pages' => ceil( $total_count / $per_page ),
			),
		);

		// Debug: Final response. //
		Debug::api(
			'Final response generated.',
			array(
				'response' => $response,
			)
		);

		return new WP_REST_Response( $response, 200 );
	}

	/**
	 * Search markers with pagination.
	 *
	 * @param \WP_REST_Request $request The request object containing pagination parameters.
	 *                                  - 'map_id' (int) The ID of the map to retrieve markers from.
	 *                                  - 'per_page' (int) Number of markers per page (default: 25).
	 *                                  - 'total_limit' (int) Maximum number of markers to retrieve (default: 100).
	 *                                  - 'offset' (int) The starting point for pagination (default: 0).
	 * @return \WP_REST_Response The response object containing the paginated list of markers.
	 */
	public function search_markers_callback( $request ) {
		global $wpdb;

		$term        = sanitize_text_field( $request->get_param( 'term' ) ?? '' );
		$map_id      = intval( $request->get_param( 'map_id' ) ?? 0 );
		$per_page    = intval( $request->get_param( 'per_page' ) ?? 25 );
		$total_limit = intval( $request->get_param( 'total_limit' ) ?? 100 );
		$offset      = intval( $request->get_param( 'offset' ) ?? 0 );
		$table_name  = $wpdb->prefix . 'wpgmza';

		// Debug: Input parameters. //
		Debug::api(
			'search_markers_callback called.',
			array(
				'term'        => $term,
				'map_id'      => $map_id,
				'per_page'    => $per_page,
				'total_limit' => $total_limit,
				'offset'      => $offset,
			)
		);

		// Generate a cache key based on search term and map ID. //
		$cache_key   = 'mapfusion_search_markers_' . md5( $term . '_' . $map_id );
		$total_count = wp_cache_get( $cache_key, 'mapfusion' );

		if ( false === $total_count ) {
			// Construct base query. //
			$query      = 'SELECT COUNT(*) FROM ' . $table_name . ' WHERE 1=1';
			$query_args = array();

			if ( ! empty( $map_id ) ) {
				$query       .= ' AND map_id = %d';
				$query_args[] = $map_id;
			}

			if ( ! empty( $term ) ) {
				$query       .= ' AND (title LIKE %s OR address LIKE %s OR description LIKE %s OR icon LIKE %s)';
				$search_term  = '%' . $wpdb->esc_like( $term ) . '%';
				$query_args[] = $search_term;
				$query_args[] = $search_term;
				$query_args[] = $search_term;
				$query_args[] = $search_term;
			}

			// Prepare and execute the query. //
			$prepared_query = $wpdb->prepare( $query, ...$query_args );
			$total_count    = (int) $wpdb->get_var( $prepared_query );

			// Store the result in cache (e.g., 10-minute expiration). //
			if ( ! empty( $total_count ) ) {
				wp_cache_set( $cache_key, $total_count, 'mapfusion', 600 );
			}
		}

		// Debug: Total marker count. //
		Debug::api(
			'Total marker count for search calculated.',
			array(
				'prepared_query' => $prepared_query,
				'total_count'    => $total_count,
			)
		);

		// Check if the offset is within bounds. //
		if ( $offset >= $total_count ) {
			Debug::warning(
				'Offset exceeds total markers. Returning empty result.',
				array(
					'offset'      => $offset,
					'total_count' => $total_count,
				)
			);

			return new WP_REST_Response(
				array(
					'success'    => true,
					'markers'    => array(),
					'pagination' => array(
						'per_page'    => $per_page,
						'offset'      => $offset,
						'total_limit' => $total_limit,
						'total'       => $total_count,
						'count'       => 0,
						'total_pages' => ceil( $total_count / $per_page ),
					),
				),
				200
			);
		}

		// Build base query. //
		$base_query = "SELECT id, map_id, title, lat, lng, address, description, pic, link, icon FROM {$table_name} WHERE 1=1";
		if ( ! empty( $term ) ) {
			$base_query .= $wpdb->prepare(
				' AND (title LIKE %s OR address LIKE %s OR description LIKE %s OR icon LIKE %s)',
				'%' . $wpdb->esc_like( $term ) . '%',
				'%' . $wpdb->esc_like( $term ) . '%',
				'%' . $wpdb->esc_like( $term ) . '%',
				'%' . $wpdb->esc_like( $term ) . '%'
			);
		}
		if ( ! empty( $map_id ) ) {
			$base_query .= $wpdb->prepare( ' AND map_id = %d', $map_id );
		}

		// Fetch paginated results. //
		$markers = Rest_API::fetch_paginated_results( $base_query, $per_page, $offset );

		// Debug: Query execution and fetched results. //
		Debug::api(
			'Search query executed and results fetched.',
			array(
				'query'         => $base_query,
				'fetched_count' => count( $markers ),
				'results'       => $markers,
			)
		);

		// If no markers found. //
		if ( empty( $markers ) ) {
			Debug::warning(
				'No markers found for search.',
				array(
					'term'   => $term,
					'map_id' => $map_id,
				)
			);

			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'No markers found.',
				),
				404
			);
		}

		// Transform results: Change "id" to "marker_id" and include additional fields. //
		$markers_transformed = array_map(
			function ( $marker ) {
				return array(
					'marker_id'   => $marker['id'], // Change "id" to "marker_id". //
					'map_id'      => $marker['map_id'],
					'title'       => $marker['title'],
					'lat'         => $marker['lat'],
					'lng'         => $marker['lng'],
					'address'     => $marker['address'],
					'description' => $marker['description'],
					'pic'         => $marker['pic'],
					'link'        => $marker['link'],
					'icon'        => $marker['icon'],
				);
			},
			$markers
		);

		// Construct response. //
		$response = array(
			'success'    => true,
			'markers'    => $markers_transformed,
			'pagination' => array(
				'per_page'    => $per_page,
				'offset'      => $offset,
				'total_limit' => $total_limit,
				'total'       => $total_count,
				'count'       => count( $markers_transformed ),
				'total_pages' => ceil( $total_count / $per_page ),
			),
		);

		// Debug: Final response. //
		Debug::api(
			'Final search response generated.',
			array(
				'response' => $response,
			)
		);

		return new WP_REST_Response( $response, 200 );
	}

	/**
	 * Retrieves details of a specific marker.
	 *
	 * @param \WP_REST_Request $request The request object containing the marker ID.
	 *                                  - 'id' (int) The ID of the marker to retrieve.
	 * @return \WP_REST_Response The response object containing the marker details.
	 */
	public function get_marker_details_callback( $request ) {
		global $wpdb;

		$marker_id  = intval( $request['id'] );
		$table_name = $wpdb->prefix . 'wpgmza';

		Debug::api( 'Fetching marker details.', array( 'marker_id' => $marker_id ) );

		// Generate a cache key based on marker ID. //
		$cache_key = 'mapfusion_marker_' . $marker_id;
		$marker    = wp_cache_get( $cache_key, 'mapfusion' );

		if ( false === $marker ) {
			// Ensure the table name is correctly defined (wpgmza is correct). //
			$table_name = $wpdb->prefix . 'wpgmza';

			// Cache miss, fetch data from the database. //
			$prepared_query = $wpdb->prepare(
				'SELECT * FROM ' . $table_name . ' WHERE id = %d',
				$marker_id
			);

			$marker = $wpdb->get_row( $prepared_query, ARRAY_A );

			// Store in cache (e.g., 10-minute expiration) if data is retrieved. //
			if ( ! empty( $marker ) ) {
				wp_cache_set( $cache_key, $marker, 'mapfusion', 600 );
			}
		}

		if ( ! $marker ) {
			Debug::api( 'Marker not found.', array( 'marker_id' => $marker_id ) );
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'Marker not found.',
				),
				404
			);
		}

		Debug::api( 'Marker details retrieved successfully.', array( 'marker_id' => $marker_id ) );
		return new WP_REST_Response(
			array(
				'success'     => true,
				'marker_id'   => $marker['id'],
				'map_id'      => $marker['map_id'],
				'title'       => $marker['title'],
				'latitude'    => $marker['latitude'],
				'longitude'   => $marker['longitude'],
				'address'     => $marker['address'],
				'description' => $marker['description'],
				'icon'        => $marker['icon'],
				'pic'         => $marker['pic'],
			),
			200
		);
	}

	/**
	 * Adds a new marker.
	 *
	 * @param \WP_REST_Request $request The request object containing marker details.
	 *                                  - 'map_id' (int) The ID of the map to add the marker to.
	 *                                  - 'title' (string) The title of the marker.
	 *                                  - 'lat' (string) The latitude of the marker.
	 *                                  - 'lng' (string) The longitude of the marker.
	 *                                  - 'address' (string) The address of the marker.
	 *                                  - 'description' (string) A description of the marker.
	 *                                  - 'icon' (string) The URL or identifier of the marker's icon.
	 *                                  - 'category' (string) The category associated with the marker.
	 *                                  - 'pic' (string) The URL of an image associated with the marker.
	 * @return \WP_REST_Response The response object containing the result of the operation.
	 */
	public function add_marker_callback( $request ) {
		global $wpdb;

		// Debug log to confirm function call. //
		Debug::api( 'add_marker_callback function called.', array( 'request_params' => $request->get_json_params() ) );

		$params      = $request->get_json_params();
		$map_id      = intval( $params['map_id'] ?? 0 );
		$title       = sanitize_text_field( $params['title'] ?? '' );
		$lat         = sanitize_text_field( $params['lat'] ?? '' );
		$lng         = sanitize_text_field( $params['lng'] ?? '' );
		$address     = sanitize_text_field( $params['address'] ?? '' );
		$description = sanitize_textarea_field( $params['description'] ?? '' );
		$icon        = sanitize_text_field( $params['icon'] ?? '' );
		$category    = sanitize_text_field( $params['category'] ?? '' );
		$pic         = esc_url_raw( $params['pic'] ?? '' ); // Ensure the URL is sanitized. //

		Debug::api( 'Adding new marker.', $params );

		// Ensure required parameters are present. //
		if ( empty( $map_id ) || empty( $title ) || empty( $lat ) || empty( $lng ) ) {
			Debug::api( 'Failed to add marker: Missing required parameters.', $params );
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'Missing required parameters.',
				),
				400
			);
		}

		// Define the correct table name. //
		$table_name = $wpdb->prefix . 'wpgmza';

		// Attempt to insert the data into the database. //
		$inserted = $wpdb->insert(
			$table_name,
			array(
				'map_id'      => absint( $map_id ),
				'title'       => $title,
				'lat'         => $lat,
				'lng'         => $lng,
				'address'     => $address,
				'description' => $description,
				'icon'        => $icon,
				'category'    => $category,
				'pic'         => $pic,
			),
			array( '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
		);

		// If the insert was successful, clear relevant cache entries. //
		if ( $inserted ) {
			wp_cache_delete( 'mapfusion_total_markers_count', 'mapfusion' );
			wp_cache_delete( 'mapfusion_markers_list', 'mapfusion' ); // Clear the markers list cache if applicable. //
			Debug::api( 'Marker successfully added.', array( 'inserted_id' => $wpdb->insert_id ) );

			return new WP_REST_Response(
				array(
					'success'     => true,
					'message'     => 'Marker added successfully!',
					'marker_id'   => $wpdb->insert_id,
					'map_id'      => $map_id,
					'title'       => $title,
					'lat'         => $lat,
					'lng'         => $lng,
					'address'     => $address,
					'description' => $description,
					'icon'        => $icon,
					'category'    => $category,
					'pic'         => $pic,
				),
				201
			);
		}

		// Log failure if insertion failed. //
		Debug::api( 'Failed to add marker: Database insert error.', array( 'wpdb_error' => $wpdb->last_error ) );

		return new WP_REST_Response(
			array(
				'success' => false,
				'message' => 'Failed to add marker.',
			),
			500
		);
	}
}

/**
 * Registers the routes for Markers_Free_API with fallback logic.
 */
function mapfusion_register_markers_free_api_routes() { // phpcs:ignore Universal.Files.SeparateFunctionsFromOO.Mixed
	if ( class_exists( '\\MapFusion\\Api\\Free\\Markers_Free_API' ) ) {
		Debug::Initializing( 'Initializing Markers_Free_API class.' );
		$markers_free_api = new \MapFusion\Api\Free\Markers_Free_API();
		$markers_free_api->register_routes();
	} else {
		Debug::critical( 'Markers_Free_API class not found. Fallback failed.' );
	}
}
add_action( 'rest_api_init', '\\MapFusion\\Api\\Free\\mapfusion_register_markers_free_api_routes' );
