<?php
/**
 * Free Maps API for MapFusion.
 *
 * This file defines the Free Maps API class, responsible for handling
 * REST API routes related to maps in the free version of MapFusion.
 *
 * @package MapFusion\Api\Free
 */

namespace MapFusion\Api\Free;

use MapFusion\Rest_API;
use MapFusion\Debug;
use WP_REST_Response;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly. //
}

/**
 * Handles Free Maps REST API routes for MapFusion.
 *
 * This class manages the REST API endpoints for basic map-related
 * operations available in the free version of MapFusion, such as
 * creating, retrieving, updating, and deleting maps.
 */
class Maps_Free_API {


	/**
	 * Registers Free Maps REST API routes.
	 */
	public function register_routes() {
		register_rest_route(
			'mapfusion/v1',
			'/list-maps',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'list_maps_callback' ),
				'args'                => array(
					'limit'  => array(
						'required'          => false,
						'validate_callback' => function ( $param ) {
							return is_numeric( $param ) && $param > 0;
						},
						'default'           => 100,
						'description'       => 'Maximum number of maps to retrieve. Default is 100.',
					),
					'offset' => array(
						'required'          => false,
						'validate_callback' => function ( $param ) {
							return is_numeric( $param ) && $param >= 0;
						},
						'default'           => 0,
						'description'       => 'Offset for pagination. Default is 0.',
					),
				),
				'permission_callback' => array( Rest_API::class, 'verify_bearer_token' ),
			)
		);

		register_rest_route(
			'mapfusion/v1',
			'/add-map',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'add_map_callback' ),
				'permission_callback' => array( Rest_API::class, 'verify_bearer_token' ),
			)
		);

		register_rest_route(
			'mapfusion/v1',
			'/search-maps',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'search_maps_callback' ),
				'args'                => array(
					'query'       => array(
						'required'          => true,
						'validate_callback' => function ( $param ) {
							return is_string( $param ) && ! empty( $param );
						},
						'description'       => 'The search query string.',
					),
					'per_page'    => array(
						'required'          => false,
						'validate_callback' => function ( $param ) {
							return is_numeric( $param ) && $param > 0;
						},
						'default'           => 10,
						'description'       => 'Number of maps to retrieve per page. Default is 10.',
					),
					'offset'      => array(
						'required'          => false,
						'validate_callback' => function ( $param ) {
							return is_numeric( $param ) && $param >= 0;
						},
						'default'           => 0,
						'description'       => 'The starting point for pagination. Default is 0.',
					),
					'total_limit' => array(
						'required'          => false,
						'validate_callback' => function ( $param ) {
							return is_numeric( $param ) && $param > 0;
						},
						'default'           => 100,
						'description'       => 'Maximum number of maps to retrieve in total. Default is 100.',
					),
				),
				'permission_callback' => array( Rest_API::class, 'verify_bearer_token' ),
			)
		);

		register_rest_route(
			'mapfusion/v1',
			'/get-map-details/(?P<id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_map_details_callback' ),
				'permission_callback' => array( Rest_API::class, 'verify_bearer_token' ),
			)
		);

		Debug::initializing( 'Registered route: /mapfusion/v1/list-maps' );
		Debug::initializing( 'Registered route: /mapfusion/v1/add-map' );
		Debug::initializing( 'Registered route: /mapfusion/v1/search-maps' );
		Debug::initializing( 'Registered route: /mapfusion/v1/get-map-details' );
	}


	/**
	 * Lists all maps.
	 *
	 * @param \WP_REST_Request $request The request object containing pagination parameters.
	 * @return \WP_REST_Response The response object with a list of maps.
	 */
	public function list_maps_callback( $request ) {
		global $wpdb;

		$per_page    = intval( $request->get_param( 'per_page' ) ?? 25 );
		$total_limit = intval( $request->get_param( 'total_limit' ) ?? 100 );
		$offset      = intval( $request->get_param( 'offset' ) ?? 0 );
		$table_name  = $wpdb->prefix . 'wpgmza_maps';

		// Debug: Input parameters. //
		Debug::api(
			'list_maps_callback called.',
			array(
				'input_parameters' => array(
					'per_page'    => $per_page,
					'offset'      => $offset,
					'total_limit' => $total_limit,
				),
			)
		);

		// Attempt to retrieve the cache first. //
		$cache_key   = 'mapfusion_total_maps_count';
		$total_count = wp_cache_get( $cache_key, 'mapfusion' );

		if ( false === $total_count ) {
			global $wpdb;

			// Define the table name in a safe way. //
			$table_name = $wpdb->prefix . 'wpgmza_maps';

			// Cache miss, fetch the count from the database. //
			$total_count = (int) $wpdb->get_var(
				$wpdb->prepare(
					'SELECT COUNT(*) FROM ' . $table_name
				)
			);

			// Store in cache (e.g., 10-minute expiration). //
			wp_cache_set( $cache_key, $total_count, 'mapfusion', 600 );
		}

		// Debug: Total count of maps. //
		Debug::api(
			'Total map count calculated.',
			array(
				'total_count' => $total_count,
			)
		);

		// Check if the offset is out of bounds. //
		if ( $offset >= $total_count ) {
			Debug::warning(
				'Offset out of bounds.',
				array(
					'offset'      => $offset,
					'total_count' => $total_count,
				)
			);

			return new WP_REST_Response(
				array(
					'success'    => true,
					'maps'       => array(),
					'pagination' => array(
						'per_page'    => $per_page,
						'offset'      => $offset,
						'total_limit' => $total_limit,
						'total'       => $total_count,
						'count'       => 0,
						'total_pages' => ceil( $total_count / $per_page ),
					),
				),
				200
			);
		}

		// Fetch paginated results. //
		$base_query = "SELECT id, map_title, map_start_lat, map_start_lng, map_width, map_height FROM {$table_name}";
		$maps       = Rest_API::fetch_paginated_results( $base_query, $per_page, $offset );

		// Transform the result: Change "id" to "map_id". //
		$maps_transformed = array_map(
			function ( $map ) {
				return array(
					'map_id'        => $map['id'], // Map "id" to "map_id". //
					'map_title'     => $map['map_title'],
					'map_start_lat' => $map['map_start_lat'],
					'map_start_lng' => $map['map_start_lng'],
					'map_width'     => $map['map_width'],
					'map_height'    => $map['map_height'],
				);
			},
			$maps
		);

		// Debug: Paginated results fetched. //
		Debug::api(
			'Paginated results transformed and fetched.',
			array(
				'query'         => $base_query,
				'fetched_count' => count( $maps_transformed ),
				'offset'        => $offset,
				'results'       => $maps_transformed,
			)
		);

		// If no results found. //
		if ( empty( $maps_transformed ) ) {
			Debug::warning(
				'No maps found for the current query.',
				array(
					'base_query' => $base_query,
					'offset'     => $offset,
				)
			);

			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'No maps found.',
				),
				404
			);
		}

		// Construct response. //
		$response = array(
			'success'    => true,
			'maps'       => $maps_transformed,
			'pagination' => array(
				'per_page'    => $per_page,
				'offset'      => $offset,
				'total_limit' => $total_limit,
				'total'       => $total_count,
				'count'       => count( $maps_transformed ),
				'total_pages' => ceil( $total_count / $per_page ),
			),
		);

		// Debug: Final response. //
		Debug::api(
			'Final response generated.',
			array(
				'response' => $response,
			)
		);

		return new WP_REST_Response( $response, 200 );
	}

	/**
	 * Adds a new map.
	 *
	 * @param \WP_REST_Request $request The request object containing map details.
	 * @return \WP_REST_Response The response object with the result of the operation.
	 */
	public function add_map_callback( $request ) {
		global $wpdb;

		Debug::api( 'Add map request received.', array( 'request_params' => $request->get_json_params() ) );

		// Retrieve and sanitize JSON parameters from the request. //
		$params        = $request->get_json_params();
		$map_title     = sanitize_text_field( $params['map_title'] ?? '' );
		$map_start_lat = sanitize_text_field( $params['map_start_lat'] ?? '' );
		$map_start_lng = sanitize_text_field( $params['map_start_lng'] ?? '' );
		$map_width     = sanitize_text_field( $params['map_width'] ?? '' );
		$map_height    = sanitize_text_field( $params['map_height'] ?? '' );

		// Validate required parameters. //
		if ( empty( $map_title ) || empty( $map_start_lat ) || empty( $map_start_lng ) || empty( $map_width ) || empty( $map_height ) ) {
			Debug::warning(
				'Failed to add map: Missing required parameters.',
				array(
					'map_title'     => $map_title,
					'map_start_lat' => $map_start_lat,
					'map_start_lng' => $map_start_lng,
					'map_width'     => $map_width,
					'map_height'    => $map_height,
				)
			);
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'Missing required parameters.',
				),
				400
			);
		}

		$table_name = $wpdb->prefix . 'wpgmza_maps';

		// Sanitize input data before inserting into the database. //
		$map_title     = sanitize_text_field( $map_title );
		$map_start_lat = sanitize_text_field( $map_start_lat );
		$map_start_lng = sanitize_text_field( $map_start_lng );
		$map_width     = sanitize_text_field( $map_width );
		$map_height    = sanitize_text_field( $map_height );

		global $wpdb;

		// Ensure the table name is safely defined. //
		$table_name = $wpdb->prefix . 'wpgmza_maps';

		// Sanitize input data before inserting into the database. //
		$map_title     = sanitize_text_field( $map_title );
		$map_start_lat = sanitize_text_field( $map_start_lat );
		$map_start_lng = sanitize_text_field( $map_start_lng );
		$map_width     = sanitize_text_field( $map_width );
		$map_height    = sanitize_text_field( $map_height );

		// Attempt to insert the map into the database. //
		$inserted = $wpdb->insert(
			$table_name,
			array(
				'map_title'     => $map_title,
				'map_start_lat' => $map_start_lat,
				'map_start_lng' => $map_start_lng,
				'map_width'     => $map_width,
				'map_height'    => $map_height,
			),
			array( '%s', '%s', '%s', '%s', '%s' )
		);

		// If a new map is inserted, clear related cache entries. //
		if ( $inserted ) {
			wp_cache_delete( 'mapfusion_total_maps_count', 'mapfusion' );
		}

		// If a new map is inserted, clear cache for total map count. //
		if ( $inserted ) {
			wp_cache_delete( 'mapfusion_total_maps_count', 'mapfusion' );
		}

		// Handle database insertion failure. //
		if ( false === $inserted ) {
			Debug::critical(
				'Failed to add map: Database insertion error.',
				array(
					'query' => $wpdb->last_query,
					'error' => $wpdb->last_error,
				)
			);
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'Failed to add map.',
				),
				500
			);
		}

		$inserted_id = $wpdb->insert_id;

		// Log successful map addition. //
		Debug::info(
			'Map added successfully.',
			array(
				'id'   => $inserted_id,
				'data' => array(
					'map_title'     => $map_title,
					'map_start_lat' => $map_start_lat,
					'map_start_lng' => $map_start_lng,
					'map_width'     => $map_width,
					'map_height'    => $map_height,
				),
			)
		);

		// Return a success response with the inserted map details. //
		return new WP_REST_Response(
			array(
				'success'       => true,
				'message'       => 'Map added successfully!',
				'map_id'        => $inserted_id,
				'map_title'     => $map_title,
				'map_start_lat' => $map_start_lat,
				'map_start_lng' => $map_start_lng,
				'map_width'     => $map_width,
				'map_height'    => $map_height,
			),
			200
		);
	}

	/**
	 * Searches maps based on a query string.
	 *
	 * @param \WP_REST_Request $request The request object containing search parameters.
	 * @return \WP_REST_Response The response object with the search results.
	 */
	public function search_maps_callback( $request ) {
		global $wpdb;

		// Retrieve and sanitize input parameters.
		$query       = sanitize_text_field( $request->get_param( 'query' ) ?? '' );
		$per_page    = intval( $request->get_param( 'per_page' ) ?? 25 );
		$total_limit = intval( $request->get_param( 'total_limit' ) ?? 100 );
		$offset      = intval( $request->get_param( 'offset' ) ?? 0 );

		$table_name = $wpdb->prefix . 'wpgmza_maps';

		// Debug: Log input parameters.
		Debug::api( 'search_maps_callback called.', compact( 'query', 'per_page', 'total_limit', 'offset' ) );

		// Start building the WHERE clause dynamically with placeholders.
		$where_clauses = array();
		$query_params  = array();

		// If a search query is provided, add it to the WHERE clause safely.
		if ( ! empty( $query ) ) {
			$where_clauses[] = 'map_title LIKE %s';
			$query_params[]  = '%' . $wpdb->esc_like( $query ) . '%';
		}

		// Construct the WHERE clause dynamically.
		$where_sql = ! empty( $where_clauses ) ? ' WHERE ' . implode( ' AND ', $where_clauses ) : '';

		// Cache key for total map count.
		$cache_key   = 'mapfusion_map_count_' . md5( wp_json_encode( array( $where_clauses, $query_params ) ) );
		$total_count = wp_cache_get( $cache_key, 'mapfusion' );

		if ( false === $total_count ) {
			// Retrieve total number of maps matching the query safely.
			$total_count_query = 'SELECT COUNT(*) FROM ' . $table_name . $where_sql;
			$prepared_query    = $wpdb->prepare( $total_count_query, ...$query_params );
			$total_count       = (int) $wpdb->get_var( $prepared_query );
			wp_cache_set( $cache_key, $total_count, 'mapfusion', 600 );
		}

		// Debug: Log total map count.
		Debug::api( 'Total map count for search calculated.', array( 'total_count' => $total_count ) );

		// Validate offset to prevent out-of-bounds errors.
		if ( $offset >= $total_count ) {
			Debug::warning( 'Offset exceeds total maps for search. Returning empty result.', compact( 'offset', 'total_count' ) );

			return new WP_REST_Response(
				array(
					'success'    => true,
					'maps'       => array(),
					'pagination' => compact( 'per_page', 'offset', 'total_limit', 'total_count' ),
				),
				200
			);
		}

		// Cache key for search results.
		$cache_key   = 'mapfusion_search_maps_' . md5( wp_json_encode( array( $where_clauses, $query_params, $per_page, $offset ) ) );
		$maps_result = wp_cache_get( $cache_key, 'mapfusion' );

		if ( false === $maps_result ) {
			// Construct base query safely.
			$base_query = 'SELECT id, map_title, map_start_lat, map_start_lng, map_width, map_height 
                       FROM ' . $table_name . $where_sql . ' LIMIT %d OFFSET %d';

			// Prepare and execute the query.
			$prepared_query = $wpdb->prepare( $base_query, ...array_merge( $query_params, array( $per_page, $offset ) ) );
			$maps_result    = $wpdb->get_results( $prepared_query, ARRAY_A );

			// Handle database errors.
			if ( false === $maps_result ) {
				Debug::critical( 'Database query failed.', array( 'query' => $prepared_query ) );
				return new WP_REST_Response(
					array(
						'success' => false,
						'message' => 'Database query failed.',
					),
					500
				);
			}

			// Store the result in cache.
			wp_cache_set( $cache_key, $maps_result, 'mapfusion', 600 );
		}

		// Debug: Log search query execution.
		Debug::api(
			'Search query executed and results fetched.',
			array(
				'query'         => $prepared_query,
				'fetched_count' => count( $maps_result ),
			)
		);

		// If no results found, return empty response.
		if ( empty( $maps_result ) ) {
			Debug::warning( 'No maps found for search query.', array( 'query' => $query ) );
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'No maps found.',
				),
				404
			);
		}

		// Transform the result: Convert "id" to "map_id".
		$maps_transformed = array_map(
			function ( $map ) {
				return array(
					'map_id'        => $map['id'],
					'map_title'     => $map['map_title'],
					'map_start_lat' => $map['map_start_lat'],
					'map_start_lng' => $map['map_start_lng'],
					'map_width'     => $map['map_width'],
					'map_height'    => $map['map_height'],
				);
			},
			$maps_result
		);

		// Debug: Log transformed results.
		Debug::api(
			'Paginated results transformed and fetched.',
			array(
				'fetched_count' => count( $maps_transformed ),
				'offset'        => $offset,
				'results'       => $maps_transformed,
			)
		);

		// Construct response.
		$response = array(
			'success'    => true,
			'maps'       => $maps_transformed,
			'pagination' => array(
				'per_page'    => $per_page,
				'offset'      => $offset,
				'total_limit' => $total_limit,
				'total'       => $total_count,
				'count'       => count( $maps_transformed ),
				'total_pages' => ceil( $total_count / $per_page ),
			),
		);

		// Debug: Log final response.
		Debug::api( 'Final search response generated.', array( 'response' => $response ) );

		return new WP_REST_Response( $response, 200 );
	}

	/**
	 * Retrieves details of a specific map.
	 *
	 * @param \WP_REST_Request $request The request object containing the map ID.
	 * @return \WP_REST_Response The response object with the map details.
	 */
	public function get_map_details_callback( $request ) {
		global $wpdb;

		// Retrieve the map ID from the request and sanitize it. //
		$map_id     = intval( $request['id'] );
		$table_name = $wpdb->prefix . 'wpgmza_maps';

		// Create cache key based on map ID. //
		$cache_key = 'mapfusion_map_' . $map_id;
		$map       = wp_cache_get( $cache_key, 'mapfusion' );

		// Generate a cache key for this specific map ID. //
		$cache_key = "mapfusion_map_{$map_id}";
		$map       = wp_cache_get( $cache_key, 'mapfusion' );

		if ( false === $map ) {
			global $wpdb;

			// Ensure the table name is safe and properly defined. //
			$table_name = $wpdb->prefix . 'wpgmza_maps';

			// Cache miss, fetch from the database. //
			$map = $wpdb->get_row(
				$wpdb->prepare(
					'SELECT * FROM ' . $table_name . ' WHERE id = %d',
					$map_id
				),
				ARRAY_A
			);

			// Store in cache (e.g., 10-minute expiration). //
			if ( ! empty( $map ) ) {
				wp_cache_set( $cache_key, $map, 'mapfusion', 600 );
			}
		}

		// If no map is found, log the debug message and return a 404 response. //
		if ( ! $map ) {
			Debug::warning( 'Map not found: ID ' . $map_id );
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'Map not found.',
				),
				404
			);
		}

		// Log a debug message for successful retrieval. //
		Debug::info( 'Retrieved map details for ID ' . $map_id );

		// Return the map details in the response. //
		return new WP_REST_Response(
			array(
				'success'   => true,
				'map_id'    => $map['id'],
				'title'     => $map['map_title'],
				'width'     => $map['map_width'],
				'height'    => $map['map_height'],
				'start_lat' => (float) $map['map_start_lat'],
				'start_lng' => (float) $map['map_start_lng'],
			),
			200
		);
	}
}

/**
 * Registers the routes for Maps_Free_API with fallback logic.
 */
function mapfusion_register_maps_free_api_routes() { // phpcs:ignore Universal.Files.SeparateFunctionsFromOO.Mixed
	// Check if the main Maps_Free_API class exists. //
	if ( class_exists( '\\MapFusion\\Api\\Free\\Maps_Free_API' ) ) {
		Debug::initializing( 'Initializing Maps_Free_API class.' );
		$maps_free_api = new \MapFusion\Api\Free\Maps_Free_API();
		$maps_free_api->register_routes();
	} else {
		Debug::warning( 'Maps_Free_API class not found. Attempting fallback...' );
		$fallback_file = __DIR__ . '/class-maps-free-api.php';

		// Check if the fallback file exists. //
		if ( file_exists( $fallback_file ) ) {
			require_once $fallback_file;
			Debug::info( 'Fallback file loaded: ' . $fallback_file );

			// Check if the Maps_Free_API class is now available. //
			if ( class_exists( '\\MapFusion\\Api\\Free\\Maps_Free_API' ) ) {
				Debug::initializing( 'Fallback succeeded. Initializing Maps_Free_API class.' );
				$maps_free_api = new \MapFusion\Api\Free\Maps_Free_API();
				$maps_free_api->register_routes();
			} else {
				Debug::critical( 'Failed to initialize Maps_Free_API class even after including fallback.' );
			}
		} else {
			Debug::critical( 'Fallback file not found: ' . $fallback_file );
		}
	}
}
add_action( 'rest_api_init', '\\MapFusion\\Api\\Free\\mapfusion_register_maps_free_api_routes' );
