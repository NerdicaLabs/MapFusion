<?php
/**
 * Miscellaneous API routes for MapFusion.
 *
 * This file defines the `Other_API` class, responsible for handling
 * various REST API routes that do not fit into specific categories,
 * such as API key validation and license verification.
 *
 * @package MapFusion\Api
 */

namespace MapFusion\Api;

use MapFusion\License_Validator;
use MapFusion\Rest_API;
use MapFusion\Debug;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly. //
}

/**
 * Handles miscellaneous REST API routes for MapFusion.
 *
 * This class provides endpoints for API key verification,
 * license validation, and other general API functionality
 * that does not belong to specific categories.
 */
class Other_API {

	/**
	 * Registers miscellaneous REST API routes. //
	 */
	public function register_routes() {
		Debug::initializing( '[register_routes] Registering routes for Other_API.' );

		register_rest_route(
			'mapfusion/v1',
			'/verify-key',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'verify_key_callback' ),
				'permission_callback' => array( Rest_API::class, 'verify_bearer_token' ),
			)
		);
		Debug::initializing( '[register_routes] Registered route: /mapfusion/v1/verify-key.' );

		register_rest_route(
			'mapfusion/v1',
			'/reset-api-key',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'reset_api_key_callback' ),
				'permission_callback' => '__return_true',
			)
		);
		Debug::initializing( '[register_routes] Registered route: /mapfusion/v1/reset-api-key.' );

		register_rest_route(
			'mapfusion/v1',
			'/validate-license',
			array(
				'methods'             => 'POST',
				'callback'            => array( License_Validator::class, 'validate_license_from_request' ),
				'permission_callback' => array( Rest_API::class, 'verify_bearer_token' ),
			)
		);
		Debug::initializing( '[register_routes] Registered route: /mapfusion/v1/validate-license.' );
	}

	/**
	 * Callback for verifying the API key.
	 *
	 * @param \WP_REST_Request $request The request object.
	 * @return \WP_REST_Response The response object.
	 */
	public function verify_key_callback( $request ) {
		Debug::api( '[verify_key_callback] Received verify-key request.' );

		// Verify the Bearer token. //
		$verification_result = Rest_API::verify_bearer_token( $request );
		if ( is_wp_error( $verification_result ) ) {
			Debug::api( '[verify_key_callback] Bearer token verification failed.' );
			return new \WP_REST_Response(
				array(
					'success' => false,
					'message' => $verification_result->get_error_message(),
				),
				$verification_result->get_error_data( 'status' )
			);
		}

		Debug::api( '[verify_key_callback] API key is valid.' );

		// Return success response. //
		return new \WP_REST_Response(
			array(
				'success' => true,
				'message' => 'API key is valid.',
			),
			200
		);
	}

	/**
	 * Callback for resetting the API key.
	 *
	 * @return \WP_REST_Response The response object.
	 */
	public function reset_api_key_callback() {
		Debug::api( '[reset_api_key_callback] Received reset-api-key request.' );

		$new_key = wp_generate_password( 40, false, false );

		if ( update_option( 'mapfusion_api_key', $new_key ) ) {
			Debug::api( '[reset_api_key_callback] API key reset successfully.' );
			return new \WP_REST_Response(
				array(
					'success' => true,
					'api_key' => $new_key,
				),
				200
			);
		}

		Debug::api( '[reset_api_key_callback] Failed to reset API key.' );
		return new \WP_REST_Response(
			array(
				'success' => false,
				'message' => 'Failed to reset API key.',
			),
			500
		);
	}

	/**
	 * Callback for validating the license.
	 *
	 * @param \WP_REST_Request $request The request object.
	 * @return \WP_REST_Response The response object.
	 */
	public function validate_license_callback( $request ) {
		Debug::api( '[validate_license_callback] Received validate-license request.' );

		$license_key = License_Validator::extract_license_key_from_request( $request );

		if ( License_Validator::validate_license_key( $license_key ) ) {
			Debug::api( '[validate_license_callback] License key is valid.' );
			return new \WP_REST_Response(
				array(
					'success' => true,
					'message' => 'License key is valid.',
				),
				200
			);
		}

		Debug::api( '[validate_license_callback] Invalid license key.' );
		return new \WP_REST_Response(
			array(
				'success' => false,
				'message' => 'Invalid license key.',
			),
			403
		);
	}
}

/**
 * Registers the routes for Other_API with fallback logic.
 */
function mapfusion_register_other_api_routes() { // phpcs:ignore Universal.Files.SeparateFunctionsFromOO.Mixed
	if ( class_exists( Other_API::class ) ) {
		Debug::initializing( '[mapfusion_register_other_api_routes] Initializing Other_API class.' );
		$other_api = new Other_API();
		$other_api->register_routes();
	} else {
		Debug::Initializing( '[mapfusion_register_other_api_routes] Other_API class not found.' );
	}
}
add_action( 'rest_api_init', __NAMESPACE__ . '\mapfusion_register_other_api_routes' );
