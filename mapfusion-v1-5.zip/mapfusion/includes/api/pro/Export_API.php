<?php
/**
 * Export API for MapFusion PRO.
 *
 * Handles all export-related REST API endpoints for the MapFusion PRO plugin.
 * Supports exporting maps and markers in JSON and CSV formats.
 *
 * @package MapFusion\Api\Pro
 */

namespace MapFusion\Api\Pro;

use MapFusion\Rest_API;
use WP_REST_Response;
use MapFusion\Debug;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly. //
}

/**
 * Handles the Export REST API routes for MapFusion PRO.
 *
 * This class is responsible for processing export requests,
 * including formatting data and responding with JSON or CSV outputs.
 *
 * @package MapFusion\Api\Pro
 */
class Export_API {



	/**
	 * Registers Export REST API routes.
	 */
	public function register_routes() {
		Debug::Initializing( 'Registering Export API routes.' );

		register_rest_route(
			'mapfusion/v1',
			'/export',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'export_callback' ),
				'permission_callback' => array( Rest_API::class, 'validate_permissions' ),
				'args'                => array(
					'format' => array(
						'required'          => true,
						'validate_callback' => function ( $param ) {
							return in_array( strtoupper( $param ), array( 'JSON', 'CSV' ), true );
						},
					),
					'map_id' => array(
						'required'          => false,
						'validate_callback' => function ( $param ) {
							return is_numeric( $param );
						},
					),
				),
			)
		);
		Debug::Initializing( 'Registered route: /mapfusion/v1/export.' );
	}

	/**
	 * Helper function to check if a directory is writable and create a file in it.
	 *
	 * @param string $dir_path The path of the directory to check.
	 * @param string $file_name The name of the file to create inside the directory.
	 * @return bool True if the directory is writable and the file was created, false otherwise.
	 */
	public static function check_and_create_file_in_directory( $dir_path, $file_name ) {
		global $wp_filesystem;

		// Initialize WP Filesystem if it's not already done
		if ( empty( $wp_filesystem ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			WP_Filesystem();
		}

		// Check if the directory exists and is writable
		if ( ! $wp_filesystem->exists( $dir_path ) ) {
			Debug::warning( 'Directory does not exist.', array( 'directory' => $dir_path ) );
			return false;
		}

		if ( ! $wp_filesystem->is_writable( $dir_path ) ) {
			Debug::warning( 'Directory is not writable.', array( 'directory' => $dir_path ) );
			return false;
		}

		// Try to create a file in the directory
		$file_path    = $dir_path . '/' . $file_name;
		$file_content = 'Sample content'; // You can adjust the content you want to write to the file

		if ( $wp_filesystem->put_contents( $file_path, $file_content ) === false ) {
			Debug::critical( 'Failed to create file in directory.', array( 'file' => $file_path ) );
			return false;
		}

		// Log success
		Debug::info( 'File created successfully in directory.', array( 'file' => $file_path ) );

		return true;
	}

	/**
	 * Generates the upload path for exported files.
	 *
	 * This function constructs the upload path for an export file with
	 * timestamp based on the given file extension.
	 *
	 * @param string $extension The file extension (e.g., "json", "csv").
	 * @return string The full file path for the export file.
	 * @throws \Exception If the directory cannot be created.
	 */
	private function get_upload_path( $extension ) {
		// Define the base directory for exports, ensuring no trailing slash.
		$base_dir = rtrim( WP_CONTENT_DIR . '/uploads/mapfusion/export', '/' );

		// Construct the full file path including the extension and timestamp.
		$file_name      = 'export_data_' . gmdate( 'Y-m-d_H-i-s' ) . '.' . $extension;
		$full_file_path = $base_dir . '/' . $file_name;

		// Ensure the URL does not have extra slashes.
		$file_url = rtrim( content_url( '/uploads/mapfusion/export' ), '/' ) . '/' . $file_name;

		// Return the full file path including the directory and file name.
		return array(
			'path' => $full_file_path,
			'url'  => $file_url,
		);
	}

	/**
	 * Recursively fixes encoding issues in data by converting to UTF-8.
	 *
	 * This function ensures that all strings within the given data
	 * are properly encoded in UTF-8, including nested arrays.
	 *
	 * @param mixed $data The data to be processed. Can be a string or an array.
	 * @return mixed The UTF-8 encoded data.
	 */
	private function fix_encoding( $data ) {
		if ( is_array( $data ) ) {
			foreach ( $data as $key => $value ) {
				$data[ $key ] = $this->fix_encoding( $value );
			}
		} elseif ( is_string( $data ) ) {
			// Convert to UTF-8. //
			$data = mb_convert_encoding( $data, 'UTF-8', 'UTF-8' );
		}

		return $data;
	}

	/**
	 * Handles the export of map data.
	 *
	 * @param \WP_REST_Request $request The request object containing export parameters.
	 *                                  - 'format' (string) The export format (e.g., CSV, JSON).
	 *                                  - 'map_id' (int|null) The ID of the map to export (optional).
	 * @return \WP_REST_Response The response object containing the exported data or an error message.
	 */
	public function export_callback( $request ) {
		global $wpdb;

		$params = $request->get_json_params();
		$format = strtoupper( sanitize_text_field( $params['format'] ?? '' ) );
		$map_id = isset( $params['map_id'] ) ? intval( $params['map_id'] ) : null;

		Debug::api(
			'Export request received.',
			array(
				'format' => $format,
				'map_id' => $map_id,
			)
		);

		if ( ! in_array( $format, array( 'JSON', 'CSV' ), true ) ) {
			Debug::api( 'Invalid export format.', array( 'format' => $format ) );
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'Invalid format. Use "JSON" or "CSV".',
				),
				400
			);
		}

		$maps_table    = $wpdb->prefix . 'wpgmza_maps';
		$markers_table = $wpdb->prefix . 'wpgmza';

		// Generate cache keys for maps and markers. //
		$maps_cache_key    = 'mapfusion_maps_list' . ( $map_id ? "_{$map_id}" : '' );
		$markers_cache_key = 'mapfusion_markers_list' . ( $map_id ? "_{$map_id}" : '' );

		// Attempt to retrieve cached data. //
		$maps    = wp_cache_get( $maps_cache_key, 'mapfusion' );
		$markers = wp_cache_get( $markers_cache_key, 'mapfusion' );

		if ( false === $maps ) {
			global $wpdb;

			// Construct maps query securely using $wpdb->prepare(). //
			$query_args = array();
			$maps_query = "SELECT * FROM {$maps_table}";

			if ( $map_id ) {
				$maps_query  .= ' WHERE id = %d';
				$query_args[] = $map_id;
			}

			// Prepare the query if parameters exist. //
			$prepared_query = ! empty( $query_args ) ? $wpdb->prepare( $maps_query, ...$query_args ) : $maps_query;

			// Fetch maps from the database. //
			$maps = $wpdb->get_results( $prepared_query, ARRAY_A );

			if ( ! empty( $maps ) ) {
				// Store maps in cache (10-minute expiration). //
				wp_cache_set( $maps_cache_key, $maps, 'mapfusion', 600 );
			} else {
				$maps = array(); // Ensure we return an empty array instead of false. //
			}
		}

		if ( false === $markers ) {
			global $wpdb;

			// Construct markers query securely using $wpdb->prepare(). //
			$query_args    = array();
			$markers_query = "SELECT * FROM {$markers_table}";

			if ( $map_id ) {
				$markers_query .= ' WHERE map_id = %d';
				$query_args[]   = $map_id;
			}

			// Prepare the query if parameters exist. //
			$prepared_query = ! empty( $query_args ) ? $wpdb->prepare( $markers_query, ...$query_args ) : $markers_query;

			// Fetch markers from the database. //
			$markers = $wpdb->get_results( $prepared_query, ARRAY_A );

			if ( ! empty( $markers ) ) {
				// Store markers in cache (10-minute expiration). //
				wp_cache_set( $markers_cache_key, $markers, 'mapfusion', 600 );
			} else {
				$markers = array(); // Ensure we return an empty array instead of false. //
			}
		}

		Debug::api(
			'Export data fetched.',
			array(
				'maps_count'    => count( $maps ),
				'markers_count' => count( $markers ),
			)
		);

		if ( empty( $maps ) && empty( $markers ) ) {
			Debug::api( 'No data available for export.' );
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'No data available.',
				),
				404
			);
		}

		return 'JSON' === $format
			? $this->export_as_json( $maps, $markers )
			: $this->export_as_csv( $maps, $markers );
	}

	/**
	 * Exports map and marker data as a JSON file.
	 *
	 * This function compiles the provided maps and markers data
	 * into a structured JSON file and saves it to the upload directory.
	 *
	 * @param array $maps    The list of maps to export.
	 * @param array $markers The list of markers to export.
	 * @return string The file path of the exported JSON file.
	 */
	private function export_as_json( $maps, $markers ) {
		// Prepare the data to be exported.
		$data = array(
			'maps'    => $maps,
			'markers' => $markers,
		);

		// Get the full path for the export file, including the directory and the timestamped file name.
		$file_path = $this->get_upload_path( 'json' );

		// Full file path including timestamped file name
		$full_file_path = $file_path['path'];

		// Ensure the directory is writable using the helper function.
		if ( ! self::check_and_create_file_in_directory( dirname( $full_file_path ), 'export_data.json' ) ) {
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'Export directory is not writable or does not exist.',
				),
				500
			);
		}

		// Encode data to JSON with error handling.
		$json_data = wp_json_encode( $data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE );
		if ( false === $json_data ) {
			$error_message = json_last_error_msg();

			// Attempt to fix encoding issues.
			$data_fixed      = $this->fix_encoding( $data );
			$json_data_fixed = wp_json_encode( $data_fixed, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE );
			if ( false === $json_data_fixed ) {
				Debug::critical(
					'JSON encoding failed, even after attempting to fix encoding.',
					array(
						'original_error' => $error_message,
						'fixed_error'    => json_last_error_msg(),
					)
				);
				return new WP_REST_Response(
					array(
						'success' => false,
						'message' => 'JSON encoding failed: ' . $error_message,
					),
					500
				);
			}

			$json_data = $json_data_fixed;
		}

		// Write the JSON data to the file using WP_Filesystem.
		global $wp_filesystem;

		// Ensure the WP Filesystem is initialized.
		if ( empty( $wp_filesystem ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			WP_Filesystem();
		}

		// Attempt to write the JSON file using WP_Filesystem.
		$bytes_written = $wp_filesystem->put_contents( $full_file_path, $json_data, FS_CHMOD_FILE );

		if ( false === $bytes_written || strlen( $json_data ) !== $wp_filesystem->size( $full_file_path ) ) {
			Debug::critical( 'Failed to write JSON export file.', array( 'file_path' => $full_file_path ) );
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'Failed to create JSON file.',
				),
				500
			);
		}

		Debug::api( 'JSON export created successfully.', array( 'file_path' => $full_file_path ) );

		return new WP_REST_Response(
			array(
				'success'  => true,
				'file_url' => $file_path['url'],
				'message'  => 'Your JSON export is ready.',
			),
			200
		);
	}

	/**
	 * Exports map and marker data as a CSV file.
	 *
	 * This function formats the provided maps and markers into a CSV file
	 * and saves it to the upload directory.
	 *
	 * @param array $maps    The list of maps to export.
	 * @param array $markers The list of markers to export.
	 * @return string The file path of the exported CSV file.
	 */
	private function export_as_csv( $maps, $markers ) {
		// Prepare the data to be exported.
		$data = array(
			'maps'    => $maps,
			'markers' => $markers,
		);

		// Get the full path for the export file, including the directory and the timestamped file name.
		$file_path = $this->get_upload_path( 'csv' );

		// Full file path including timestamped file name
		$full_file_path = $file_path['path'];

		// Ensure the directory is writable using the helper function.
		if ( ! self::check_and_create_file_in_directory( dirname( $full_file_path ), 'export_data.csv' ) ) {
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'Export directory is not writable or does not exist.',
				),
				500
			);
		}

		// Generate CSV content as a string.
		$csv_rows = array();

		// Add header row.
		$csv_rows[] = '"Type","ID","Map ID","Name","Latitude","Longitude","Address","Description","Pic","Link","Icon","Anim","Infoopen","Category","Approved","Retina","Marker Type","Did","Sticky","Other Data","LatLng","Layer Group"';

		// Add maps.
		foreach ( $maps as $map ) {
			$csv_rows[] = sprintf(
				'"%s","%d","","%s","","","","","","","","","","","","","","","","","",""',
				'Map',
				$map['id'],
				esc_attr( $map['map_title'] )
			);
		}

		// Add markers.
		foreach ( $markers as $marker ) {
			$csv_rows[] = sprintf(
				'"%s","%d","%d","%s","%s","%s","%s","%s","%s","%s","%s","%s","%s","%s","%s","%s","%s","%s","%s","%s","%s","%s"',
				'Marker',
				$marker['id'],
				$marker['map_id'],
				esc_attr( $marker['title'] ),
				esc_attr( $marker['lat'] ),
				esc_attr( $marker['lng'] ),
				esc_attr( $marker['address'] ),
				esc_attr( $marker['description'] ),
				esc_attr( $marker['pic'] ),
				esc_attr( $marker['link'] ),
				esc_attr( $marker['icon'] ),
				esc_attr( $marker['anim'] ),
				esc_attr( $marker['infoopen'] ),
				esc_attr( $marker['category'] ),
				esc_attr( $marker['approved'] ),
				esc_attr( $marker['retina'] ),
				esc_attr( $marker['type'] ),
				esc_attr( $marker['did'] ),
				esc_attr( $marker['sticky'] ),
				esc_attr( $marker['other_data'] ),
				esc_attr( $marker['latlng'] ),
				esc_attr( $marker['layergroup'] )
			);
		}

		// Convert array to CSV format.
		$csv_content = implode( "\n", $csv_rows );

		// Write CSV content to the file using WP_Filesystem.
		global $wp_filesystem;

		// Ensure the WP Filesystem is initialized.
		if ( empty( $wp_filesystem ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			WP_Filesystem();
		}

		// Attempt to write the CSV file using WP_Filesystem.
		$bytes_written = $wp_filesystem->put_contents( $full_file_path, $csv_content, FS_CHMOD_FILE );

		if ( false === $bytes_written || strlen( $csv_content ) !== $wp_filesystem->size( $full_file_path ) ) {
			Debug::critical( 'Failed to write CSV export file.', array( 'file_path' => $full_file_path ) );
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'Failed to create CSV file.',
				),
				500
			);
		}

		Debug::api( 'CSV export created successfully.', array( 'file_path' => $full_file_path ) );

		return new WP_REST_Response(
			array(
				'success'  => true,
				'file_url' => $file_path['url'],
				'message'  => 'Your CSV export is ready.',
			),
			200
		);
	}
}

/**
 * Registers the routes for Export_API with fallback logic.
 */
function mapfusion_register_export_api_routes() { // phpcs:ignore Universal.Files.SeparateFunctionsFromOO.Mixed
	Debug::Initializing( 'Initializing Export_API class.' );

	if ( class_exists( '\\MapFusion\\Api\\Pro\\Export_API' ) ) {
		$export_api = new Export_API();
		$export_api->register_routes();
	} else {
		Debug::critical( 'Export_API class not found. Fallback failed.' );
	}
}
add_action( 'rest_api_init', '\\MapFusion\\Api\\Pro\\mapfusion_register_export_api_routes' );
