<?php
/**
 * Import API for MapFusion PRO.
 *
 * This file defines the Import API class, responsible for handling
 * import requests, validating data, and storing maps and markers in the database.
 *
 * @package MapFusion\Api\Pro
 */

namespace MapFusion\Api\Pro;

use MapFusion\Rest_API;
use WP_REST_Response;
use MapFusion\Debug;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly. //
}

/**
 * Handles the Import REST API routes for MapFusion PRO.
 *
 * This class is responsible for processing import requests,
 * validating incoming data, and storing maps and markers
 * into the database with appropriate security measures.
 */
class Import_API {


	/**
	 * Registers Import REST API routes.
	 */
	public function register_routes() {
		Debug::Initializing( 'Registering Import API routes.' );

		register_rest_route(
			'mapfusion/v1',
			'/import',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'import_callback' ),
				'permission_callback' => array( Rest_API::class, 'validate_permissions' ),
			)
		);
		Debug::Initializing( 'Registered route: /mapfusion/v1/import.' );
	}

	/**
	 * Handles data import from a provided file URL.
	 *
	 * This function processes an import request, retrieves the file URL,
	 * validates it, and moves it to the import folder before further processing.
	 *
	 * @param WP_REST_Request $request The request object containing the file URL.
	 * @return WP_REST_Response JSON response indicating success or failure.
	 * @throws WP_Error If the file download or validation fails.
	 */
	public function import_callback( $request ) {
		$file_url = sanitize_text_field( $request->get_param( 'file_url' ) );
		Debug::api( 'Import request received.', array( 'file_url' => $file_url ) );

		$file_path = $this->save_to_import_folder( $file_url );
		if ( ! $file_path ) {
			Debug::api( 'Failed to save file to import folder.', array( 'file_url' => $file_url ) );
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'Failed to save file to import folder.',
				),
				500
			);
		}

		$file_content = $this->get_file_content( $file_path['path'] );
		if ( ! $file_content ) {
			Debug::api( 'No valid file provided for import.' );
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'No valid file provided.',
				),
				400
			);
		}

		$file_type = $this->detect_file_type( $file_content );
		Debug::api( 'Detected file type for import.', array( 'file_type' => $file_type ) );

		// Process import and ensure the response is a WP_REST_Response object. //
		$import_success = 'application/json' === $file_type
			? $this->import_json( $file_content )
			: $this->import_csv( $file_content );

		// Convert bool response to WP_REST_Response. //
		$response = $import_success
			? new WP_REST_Response(
				array(
					'success' => true,
					'message' => 'Import successful.',
				),
				200
			)
			: new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'Import failed.',
				),
				500
			);

		// Add file URL to the response for debugging or user reference. //
		if ( isset( $file_path['url'] ) ) {
			$response->set_data( array_merge( $response->get_data(), array( 'file_url' => $file_path['url'] ) ) );
		}

		return $response;
	}

	/**
	 * Saves the uploaded file to the `/mapfusion/import` directory.
	 *
	 * This function moves the uploaded file to the designated import folder
	 * within the WordPress uploads directory.
	 *
	 * @param string $file_url The URL of the uploaded file to be saved.
	 * @return string The full local path of the saved file.
	 * @throws WP_Error If the import directory cannot be created or the file cannot be saved.
	 */
	private function save_to_import_folder( $file_url ) {
		$upload_dir        = wp_upload_dir();
		$plugin_import_dir = $upload_dir['basedir'] . '/mapfusion/import';

		// Ensure the import directory exists. //
		if ( ! is_dir( $plugin_import_dir ) ) {
			if ( ! wp_mkdir_p( $plugin_import_dir ) ) {
				Debug::critical( 'Failed to create import directory.', array( 'directory' => $plugin_import_dir ) );
				return null;
			}
		}

		// Initialize WP_Filesystem if not already set up. //
		global $wp_filesystem;
		if ( empty( $wp_filesystem ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			WP_Filesystem();
		}

		// Check if the import directory is writable. //
		if ( ! $wp_filesystem->is_writable( $plugin_import_dir ) ) {
			Debug::critical( 'Import directory is not writable.', array( 'directory' => $plugin_import_dir ) );
			return null;
		}

		// Generate file name and path. //
		$filename  = sanitize_file_name( basename( $file_url ) );
		$file_path = trailingslashit( $plugin_import_dir ) . $filename;

		// Fetch the file content using WordPress HTTP API. //
		$response = wp_remote_get( $file_url, array( 'timeout' => 15 ) );

		if ( is_wp_error( $response ) ) {
			Debug::critical( 'Failed to fetch the file.', array( 'error' => $response->get_error_message() ) );
			return null;
		}

		$content = wp_remote_retrieve_body( $response );
		if ( empty( $content ) ) {
			Debug::critical( 'File content is empty.', array( 'file_url' => $file_url ) );
			return null;
		}

		// Save the file using WP_Filesystem. //
		if ( ! $wp_filesystem->put_contents( $file_path, $content, FS_CHMOD_FILE ) ) {
			Debug::critical( 'Failed to save the file.', array( 'file_path' => $file_path ) );
			return null;
		}

		Debug::api( 'File saved to import folder successfully.', array( 'file_path' => $file_path ) );

		return array(
			'path' => $file_path,
			'url'  => $upload_dir['baseurl'] . '/mapfusion/import/' . $filename,
		);
	}

	/**
	 * Fetches file content from a local path.
	 *
	 * This function reads the content of a file from the specified local path.
	 * It ensures that the file exists before attempting to read it.
	 *
	 * @param string $file_path The full path to the file.
	 * @return string|false The file content as a string, or false on failure.
	 * @throws WP_Error If the file does not exist or cannot be read.
	 */
	private function get_file_content( $file_path ) {
		global $wp_filesystem;

		// Initialize WP_Filesystem if not already set up. //
		if ( empty( $wp_filesystem ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			WP_Filesystem();
		}

		// Check if file exists using WP_Filesystem. //
		if ( ! $wp_filesystem->exists( $file_path ) ) {
			Debug::api( 'File does not exist.', array( 'file_path' => $file_path ) );
			return null;
		}

		// Read file content using WP_Filesystem. //
		$content = $wp_filesystem->get_contents( $file_path );
		if ( false === $content ) {
			Debug::api( 'Failed to read file content.', array( 'file_path' => $file_path ) );
			return null;
		}

		return $content;
	}

	/**
	 * Detects the file type based on its content.
	 *
	 * This function attempts to determine if the file content is in JSON or CSV format.
	 * If the content can be successfully parsed as JSON, it is classified as `application/json`.
	 * Otherwise, it is assumed to be `text/csv`.
	 *
	 * @param string $content The file content as a string.
	 * @return string The detected MIME type (`application/json` or `text/csv`).
	 */
	private function detect_file_type( $content ) {
		return json_decode( $content, true ) !== null ? 'application/json' : 'text/csv';
	}

	/**
	 * Imports JSON data and processes it into the database.
	 *
	 * This function decodes the provided JSON content and processes the data.
	 * It ensures that the data is valid before proceeding with the import.
	 *
	 * @param string $content The JSON file content as a string.
	 * @return bool True on successful import, false on failure.
	 * @throws WP_Error If the JSON content is invalid or cannot be processed.
	 */
	private function import_json( $content ) {
		$data = json_decode( $content, true );

		if ( json_last_error() !== JSON_ERROR_NONE ) {
			Debug::api( 'Invalid JSON file.', array( 'error' => json_last_error_msg() ) );
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'Invalid JSON file.',
				),
				400
			);
		}

		Debug::api( 'JSON import completed successfully.', array( 'data' => $data ) );
		return new WP_REST_Response(
			array(
				'success' => true,
				'message' => 'JSON imported successfully.',
			),
			200
		);
	}

	/**
	 * Imports CSV data and processes it into the database.
	 *
	 * This function reads and parses CSV content, ensuring it is valid before
	 * proceeding with the import into the database. It uses `WP_Filesystem`
	 * to handle file operations securely.
	 *
	 * @param string $content The CSV file content as a string.
	 * @return bool True on successful import, false on failure.
	 * @throws WP_Error If the CSV content is invalid or cannot be processed.
	 */
	private function import_csv( $content ) {
		global $wp_filesystem;

		// Initialize WP_Filesystem if not already set up.
		if ( empty( $wp_filesystem ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			WP_Filesystem();
		}

		// Use a temporary file for CSV processing.
		$temp_file = wp_tempnam( 'mapfusion_csv_import' );

		if ( ! $temp_file ) {
			Debug::error( 'Failed to create a temporary file for CSV import.' );
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'Failed to create a temporary file.',
				),
				500
			);
		}

		// Write content to the temporary file using WP_Filesystem.
		if ( ! $wp_filesystem->put_contents( $temp_file, $content, FS_CHMOD_FILE ) ) {
			Debug::error( 'Failed to write CSV content to the temporary file.' );
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'Failed to write CSV content.',
				),
				500
			);
		}

		// Read file content into an array using WP_Filesystem.
		$file_content = $wp_filesystem->get_contents( $temp_file );
		if ( false === $file_content ) {
			Debug::error( 'Failed to read CSV content from the temporary file.' );
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'Failed to read CSV content.',
				),
				500
			);
		}

		// Convert CSV string into an array.
		$rows = array_map( 'str_getcsv', explode( "\n", $file_content ) );

		// Extract the header row.
		$header = array_shift( $rows );

		// Process each row.
		foreach ( $rows as $row ) {
			if ( count( $row ) === count( $header ) ) {
				$data = array_combine( $header, $row );
				Debug::api( 'Importing row from CSV.', array( 'row' => $data ) );
			}
		}

		// Clean up the temporary file.
		$wp_filesystem->delete( $temp_file );

		Debug::api( 'CSV import completed successfully.' );
		return new WP_REST_Response(
			array(
				'success' => true,
				'message' => 'CSV imported successfully.',
			),
			200
		);
	}
}

/**
 * Registers the routes for Import_API with fallback logic.
 */
function mapfusion_register_import_api_routes() { // phpcs:ignore Universal.Files.SeparateFunctionsFromOO.Mixed
	Debug::Initializing( 'Initializing Import_API class.' );

	if ( class_exists( '\\MapFusion\\Api\\Pro\\Import_API' ) ) {
		$import_api = new Import_API();
		$import_api->register_routes();
	} else {
		Debug::critical( 'Import_API class not found. Fallback failed.' );
	}
}
add_action( 'rest_api_init', '\\MapFusion\\Api\\Pro\\mapfusion_register_import_api_routes' );
