<?php
/**
 * PRO Markers API for MapFusion.
 *
 * This file defines the PRO Markers API class, responsible for handling
 * advanced REST API routes related to markers in MapFusion PRO.
 *
 * @package MapFusion\Api\Pro
 */

namespace MapFusion\Api\Pro;

use MapFusion\Rest_API;
use WP_REST_Response;
use MapFusion\Debug;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly. //
}

/**
 * Handles PRO Markers REST API routes for MapFusion.
 *
 * This class manages the REST API endpoints for advanced marker-related
 * operations in MapFusion PRO, such as bulk updates, category assignments,
 * and extended marker configurations.
 */
class Markers_Pro_API {


	/**
	 * Registers PRO Markers REST API routes.
	 */
	public function register_routes() {
		Debug::Initializing( 'Registering routes for Markers_Pro_API.' );

		// Edit Marker. //
		register_rest_route(
			'mapfusion/v1',
			'/edit-marker/(?P<id>\d+)',
			array(
				'methods'             => 'PUT',
				'callback'            => array( $this, 'edit_marker_callback' ),
				'permission_callback' => array( Rest_API::class, 'validate_permissions' ),
			)
		);
		Debug::Initializing( 'Registered route: /mapfusion/v1/edit-marker.' );

		// Delete Marker. //
		register_rest_route(
			'mapfusion/v1',
			'/delete-marker/(?P<id>\d+)',
			array(
				'methods'             => 'DELETE',
				'callback'            => array( $this, 'delete_marker_callback' ),
				'permission_callback' => array( Rest_API::class, 'validate_permissions' ),
			)
		);
		Debug::Initializing( 'Registered route: /mapfusion/v1/delete-marker.' );

		// Duplicate Marker. //
		register_rest_route(
			'mapfusion/v1',
			'/duplicate-marker/(?P<id>\d+)',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'duplicate_marker_callback' ),
				'permission_callback' => array( Rest_API::class, 'validate_permissions' ),
			)
		);
		Debug::Initializing( 'Registered route: /mapfusion/v1/duplicate-marker.' );
	}

	/**
	 * Edits an existing marker.
	 *
	 * @param \WP_REST_Request $request The request object containing marker update data.
	 *                                  - 'id' (int) The ID of the marker to be edited.
	 *                                  - JSON body parameters with updated marker fields.
	 * @return \WP_REST_Response The response object indicating success or failure.
	 */
	public function edit_marker_callback( $request ) {
		global $wpdb;

		$marker_id  = intval( $request['id'] );
		$params     = $request->get_json_params();
		$table_name = $wpdb->prefix . 'wpgmza';

		Debug::api(
			'Editing marker.',
			array(
				'marker_id' => $marker_id,
				'params'    => $params,
			)
		);

		// Ensure marker ID is valid. //
		if ( empty( $marker_id ) ) {
			Debug::api( 'Invalid marker ID.', array( 'marker_id' => $marker_id ) );
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'Invalid marker ID.',
				),
				400
			);
		}

		// Sanitize input data. //
		$update_data   = array();
		$update_format = array();

		if ( isset( $params['title'] ) ) {
			$update_data['title'] = sanitize_text_field( $params['title'] );
			$update_format[]      = '%s';
		}
		if ( isset( $params['lat'] ) ) {
			$update_data['lat'] = sanitize_text_field( $params['lat'] );
			$update_format[]    = '%s';
		}
		if ( isset( $params['lng'] ) ) {
			$update_data['lng'] = sanitize_text_field( $params['lng'] );
			$update_format[]    = '%s';
		}
		if ( isset( $params['address'] ) ) {
			$update_data['address'] = sanitize_text_field( $params['address'] );
			$update_format[]        = '%s';
		}
		if ( isset( $params['description'] ) ) {
			$update_data['description'] = sanitize_textarea_field( $params['description'] );
			$update_format[]            = '%s';
		}
		if ( isset( $params['icon'] ) ) {
			$update_data['icon'] = esc_url_raw( $params['icon'] );
			$update_format[]     = '%s';
		}
		if ( isset( $params['category'] ) ) {
			$update_data['category'] = sanitize_text_field( $params['category'] );
			$update_format[]         = '%s';
		}
		if ( isset( $params['pic'] ) ) {
			$update_data['pic'] = esc_url_raw( $params['pic'] );
			$update_format[]    = '%s';
		}

		if ( empty( $update_data ) ) {
			Debug::api( 'No fields provided for update.', array( 'marker_id' => $marker_id ) );
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'No fields to update.',
				),
				400
			);
		}

		// Attempt to update the marker. //
		$updated = $wpdb->update(
			$table_name,
			$update_data,
			array( 'id' => $marker_id ),
			$update_format,
			array( '%d' )
		);

		if ( false === $updated ) {
			Debug::api(
				'Failed to update marker.',
				array(
					'marker_id'  => $marker_id,
					'wpdb_error' => $wpdb->last_error,
				)
			);
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'Failed to update marker.',
				),
				500
			);
		}

		// Invalidate cache to ensure updated data is reflected. //
		wp_cache_delete( "mapfusion_marker_{$marker_id}", 'mapfusion' );
		wp_cache_delete( 'mapfusion_total_markers_count', 'mapfusion' );

		Debug::api( 'Marker updated successfully.', array( 'marker_id' => $marker_id ) );
		return new WP_REST_Response(
			array(
				'success'   => true,
				'message'   => 'Marker updated successfully.',
				'marker_id' => $marker_id,
			),
			200
		);
	}

	/**
	 * Deletes a marker.
	 *
	 * @param \WP_REST_Request $request The request object containing the marker ID to delete.
	 *                                  - 'id' (int) The ID of the marker to be deleted.
	 * @return \WP_REST_Response The response object indicating success or failure.
	 */
	public function delete_marker_callback( $request ) {
		global $wpdb;

		$marker_id  = intval( $request['id'] );
		$table_name = $wpdb->prefix . 'wpgmza';

		Debug::api( 'Deleting marker.', array( 'marker_id' => $marker_id ) );

		// Validate the marker ID. //
		if ( empty( $marker_id ) ) {
			Debug::api( 'Invalid marker ID provided.', array( 'marker_id' => $marker_id ) );
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'Invalid marker ID.',
				),
				400
			);
		}

		// Check if the marker exists before attempting to delete. //
		$marker_exists = $wpdb->get_var(
			$wpdb->prepare( 'SELECT COUNT(*) FROM ' . $table_name . ' WHERE id = %d', $marker_id )
		);

		if ( '0' === $marker_exists ) {
			Debug::api( 'Marker not found.', array( 'marker_id' => $marker_id ) );
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'Marker not found.',
				),
				404
			);
		}

		// Attempt to delete the marker. //
		$deleted = $wpdb->delete( $table_name, array( 'id' => $marker_id ), array( '%d' ) );

		if ( false === $deleted || 0 === $deleted ) {
			Debug::api(
				'Failed to delete marker.',
				array(
					'marker_id'  => $marker_id,
					'wpdb_error' => $wpdb->last_error,
				)
			);
						return new WP_REST_Response(
							array(
								'success' => false,
								'message' => 'Failed to delete marker.',
							),
							500
						);
		}

		// Invalidate cache to ensure the marker list and count update. //
		wp_cache_delete( 'mapfusion_total_markers_count', 'mapfusion' );
		wp_cache_delete( "mapfusion_marker_{$marker_id}", 'mapfusion' );

		Debug::api( 'Marker deleted successfully.', array( 'marker_id' => $marker_id ) );

		return new WP_REST_Response(
			array(
				'success' => true,
				'message' => 'Marker deleted successfully.',
			),
			200
		);
	}

	/**
	 * Duplicates an existing marker.
	 *
	 * @param \WP_REST_Request $request The request object containing the marker ID to duplicate.
	 *                                  - 'id' (int) The ID of the marker to be duplicated.
	 * @return \WP_REST_Response The response object indicating success or failure.
	 */
	public function duplicate_marker_callback( $request ) {
		global $wpdb;

		$marker_id  = intval( $request['id'] );
		$table_name = $wpdb->prefix . 'wpgmza';

		Debug::api( 'Duplicating marker.', array( 'marker_id' => $marker_id ) );

		// Validate marker ID. //
		if ( empty( $marker_id ) ) {
			Debug::api( 'Invalid marker ID provided.', array( 'marker_id' => $marker_id ) );
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'Invalid marker ID.',
				),
				400
			);
		}

		// Generate cache key. //
		$cache_key = 'mapfusion_marker_' . $marker_id;

		// Attempt to retrieve cached data. //
		$marker = wp_cache_get( $cache_key, 'mapfusion' );

		if ( false === $marker ) {
			// Fetch the original marker securely. //
			$marker = $wpdb->get_row(
				$wpdb->prepare(
					'SELECT * FROM ' . $table_name . ' WHERE id = %d',
					$marker_id
				),
				ARRAY_A
			);

			// Cache the marker if found. //
			if ( $marker ) {
				wp_cache_set( $cache_key, $marker, 'mapfusion', 600 );
			}
		}

		if ( ! $marker ) {
			Debug::api( 'Marker not found for duplication.', array( 'marker_id' => $marker_id ) );
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'Marker not found.',
				),
				404
			);
		}

		// Remove the ID to create a new marker. //
		unset( $marker['id'] );

		// Duplicate the marker securely. //
		$duplicated = $wpdb->insert( $table_name, $marker );

		if ( false === $duplicated ) {
			Debug::api(
				'Failed to duplicate marker.',
				array(
					'marker_id'  => $marker_id,
					'wpdb_error' => $wpdb->last_error,
				)
			);
						return new WP_REST_Response(
							array(
								'success' => false,
								'message' => 'Failed to duplicate marker.',
							),
							500
						);
		}

		// Get the new ID. //
		$new_id = $wpdb->insert_id;

		// Invalidate cache to ensure the new marker is reflected in future queries. //
		wp_cache_delete( 'mapfusion_total_markers_count', 'mapfusion' );
		wp_cache_delete( "mapfusion_marker_{$new_id}", 'mapfusion' );

		Debug::api(
			'Marker duplicated successfully.',
			array(
				'old_marker_id' => $marker_id,
				'new_marker_id' => $new_id,
			)
		);

		return new WP_REST_Response(
			array(
				'success'       => true,
				'message'       => 'Marker duplicated successfully.',
				'new_marker_id' => $new_id,
			),
			201
		);
	}
}

/**
 * Registers the routes for Markers_Pro_API with fallback logic.
 */
function mapfusion_register_markers_pro_api_routes() { // phpcs:ignore Universal.Files.SeparateFunctionsFromOO.Mixed
	Debug::Initializing( 'Initializing Markers_Pro_API class.' );

	if ( class_exists( '\\MapFusion\\Api\\Pro\\Markers_Pro_API' ) ) {
		$markers_pro_api = new \MapFusion\Api\Pro\Markers_Pro_API();
		$markers_pro_api->register_routes();
	} else {
		Debug::critical( 'Markers_Pro_API class not found. Fallback failed.' );
	}
}
add_action( 'rest_api_init', '\\MapFusion\\Api\\Pro\\mapfusion_register_markers_pro_api_routes' );
