<?php
/**
 * PRO Maps API for MapFusion.
 *
 * This file defines the PRO Maps API class, responsible for handling
 * advanced REST API routes related to maps in MapFusion PRO.
 *
 * @package MapFusion\Api\Pro
 */

namespace MapFusion\Api\Pro;

use MapFusion\Rest_API;
use WP_REST_Response;
use MapFusion\Debug;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly. //
}

/**
 * Handles PRO Maps REST API routes for MapFusion.
 *
 * This class manages the REST API endpoints for advanced map-related
 * operations in MapFusion PRO, such as category management, bulk updates,
 * and extended map configurations.
 */
class Maps_Pro_API {



	/**
	 * Registers PRO Maps REST API routes.
	 */
	public function register_routes() {
		Debug::initializing( 'Registering PRO Maps REST API routes.' );

		register_rest_route(
			'mapfusion/v1',
			'/edit-map/(?P<id>\\d+)',
			array(
				'methods'             => 'PUT',
				'callback'            => array( $this, 'edit_map_callback' ),
				'permission_callback' => array( Rest_API::class, 'validate_permissions' ),
			)
		);

		register_rest_route(
			'mapfusion/v1',
			'/delete-map/(?P<id>\\d+)',
			array(
				'methods'             => 'DELETE',
				'callback'            => array( $this, 'delete_map_callback' ),
				'permission_callback' => array( Rest_API::class, 'validate_permissions' ),
			)
		);

		register_rest_route(
			'mapfusion/v1',
			'/duplicate-map/(?P<id>\\d+)',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'duplicate_map_callback' ),
				'permission_callback' => array( Rest_API::class, 'validate_permissions' ),
			)
		);

		Debug::Initializing( 'PRO Maps REST API routes registered successfully.' );
	}

	/**
	 * Edits an existing map.
	 *
	 * @param \WP_REST_Request $request The request object containing map update data.
	 *                                  - 'id' (int) The ID of the map to be edited.
	 *                                  - JSON body parameters with updated map fields.
	 * @return \WP_REST_Response The response object indicating success or failure.
	 */
	public function edit_map_callback( $request ) {
		global $wpdb;

		$map_id = intval( $request['id'] );
		Debug::api( 'Received edit-map request.', array( 'id' => $map_id ) );

		if ( ! $map_id ) {
			Debug::api( 'Invalid map ID.', array( 'id' => $map_id ) );
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'Invalid map ID.',
				),
				400
			);
		}

		$params     = $request->get_json_params();
		$table_name = $wpdb->prefix . 'wpgmza_maps';

		// Sanitize input data. //
		$update_data   = array();
		$update_format = array();

		if ( isset( $params['map_title'] ) ) {
			$update_data['map_title'] = sanitize_text_field( $params['map_title'] );
			$update_format[]          = '%s';
		}
		if ( isset( $params['map_start_lat'] ) ) {
			$update_data['map_start_lat'] = sanitize_text_field( $params['map_start_lat'] );
			$update_format[]              = '%s';
		}
		if ( isset( $params['map_start_lng'] ) ) {
			$update_data['map_start_lng'] = sanitize_text_field( $params['map_start_lng'] );
			$update_format[]              = '%s';
		}
		if ( isset( $params['map_width'] ) ) {
			$update_data['map_width'] = sanitize_text_field( $params['map_width'] );
			$update_format[]          = '%s';
		}
		if ( isset( $params['map_height'] ) ) {
			$update_data['map_height'] = sanitize_text_field( $params['map_height'] );
			$update_format[]           = '%s';
		}

		if ( empty( $update_data ) ) {
			Debug::api( 'No fields to update.', array( 'id' => $map_id ) );
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'No fields to update.',
				),
				400
			);
		}

		// Attempt to update the map securely. //
		$updated = $wpdb->update(
			$table_name,
			$update_data,
			array( 'id' => $map_id ),
			$update_format,
			array( '%d' )
		);

		if ( false === $updated ) {
			Debug::api(
				'Failed to update map.',
				array(
					'id'         => $map_id,
					'wpdb_error' => $wpdb->last_error,
				)
			);
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'Failed to update map.',
				),
				500
			);
		}

		// Invalidate cache to ensure the updated map data is reflected. //
		wp_cache_delete( 'mapfusion_total_maps_count', 'mapfusion' );
		wp_cache_delete( "mapfusion_map_{$map_id}", 'mapfusion' );

		Debug::api( 'Map updated successfully.', array( 'id' => $map_id ) );
		return new WP_REST_Response(
			array(
				'success' => true,
				'message' => 'Map updated successfully.',
				'map_id'  => $map_id,
			),
			200
		);
	}

	/**
	 * Deletes a map.
	 *
	 * @param \WP_REST_Request $request The request object containing the map ID to delete.
	 *                                  - 'id' (int) The ID of the map to be deleted.
	 * @return \WP_REST_Response The response object indicating success or failure.
	 */
	public function delete_map_callback( $request ) {
		global $wpdb;

		$map_id     = intval( $request['id'] );
		$table_name = $wpdb->prefix . 'wpgmza_maps';

		Debug::api( 'Deleting map.', array( 'id' => $map_id ) );

		// Validate the map ID. //
		if ( empty( $map_id ) ) {
			Debug::api( 'Invalid map ID provided.', array( 'id' => $map_id ) );
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'Invalid map ID.',
				),
				400
			);
		}

		// Check if the map exists before deleting. //
		$map_exists = $wpdb->get_var(
			$wpdb->prepare( 'SELECT COUNT(*) FROM ' . $table_name . ' WHERE id = %d', $map_id )
		);

		if ( '0' === $map_exists ) {
			Debug::api( 'Map does not exist.', array( 'id' => $map_id ) );
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'Map not found.',
				),
				404
			);
		}

		// Attempt to delete the map. //
		$deleted = $wpdb->delete( $table_name, array( 'id' => $map_id ), array( '%d' ) );

		if ( false === $deleted || $deleted === 0 ) { // phpcs:ignore WordPress.PHP.YodaConditions.NotYoda
			Debug::api(
				'Failed to delete map.',
				array(
					'id'         => $map_id,
					'wpdb_error' => $wpdb->last_error,
				)
			);
						return new WP_REST_Response(
							array(
								'success' => false,
								'message' => 'Failed to delete map.',
							),
							500
						);
		}

		// Invalidate cache to ensure the total map count updates. //
		wp_cache_delete( 'mapfusion_total_maps_count', 'mapfusion' );
		wp_cache_delete( "mapfusion_map_{$map_id}", 'mapfusion' );

		Debug::api( 'Map deleted successfully.', array( 'id' => $map_id ) );

		return new WP_REST_Response(
			array(
				'success' => true,
				'message' => 'Map deleted successfully.',
			),
			200
		);
	}

	/**
	 * Duplicates an existing map.
	 *
	 * @param \WP_REST_Request $request The request object containing the map ID to duplicate.
	 *                                  - 'id' (int) The ID of the map to be duplicated.
	 * @return \WP_REST_Response The response object indicating success or failure.
	 */
	public function duplicate_map_callback( $request ) {
		global $wpdb;

		$map_id     = intval( $request['id'] );
		$table_name = $wpdb->prefix . 'wpgmza_maps';

		Debug::api( 'Fetching map for duplication.', array( 'id' => $map_id ) );

		// Retrieve map data securely. //
		$map = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT * FROM ' . $table_name . ' WHERE id = %d',
				$map_id
			),
			ARRAY_A
		);

		if ( ! $map ) {
			Debug::api( 'Map not found for duplication.', array( 'id' => $map_id ) );
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => 'Map not found.',
				),
				404
			);
		}

		unset( $map['id'] ); // Remove ID for duplication. //

		// Insert duplicated map securely. //
		$duplicated = $wpdb->insert( $table_name, $map );

		if ( false === $duplicated ) {
			Debug::api(
				'Failed to duplicate map.',
				array(
					'id'         => $map_id,
					'wpdb_error' => $wpdb->last_error,
				)
			);
						return new WP_REST_Response(
							array(
								'success' => false,
								'message' => 'Failed to duplicate map.',
							),
							500
						);
		}

		$new_id = $wpdb->insert_id;

		// Invalidate cache to ensure new map appears in future queries. //
		wp_cache_delete( 'mapfusion_total_maps_count', 'mapfusion' );

		Debug::api(
			'Map duplicated successfully.',
			array(
				'old_id' => $map_id,
				'new_id' => $new_id,
			)
		);

		return new WP_REST_Response(
			array(
				'success' => true,
				'message' => 'Map duplicated successfully.',
				'data'    => array( 'new_map_id' => $new_id ),
			),
			201
		);
	}
}

/**
 * Fallback registration
 */
function mapfusion_register_maps_pro_api_routes() { // phpcs:ignore Universal.Files.SeparateFunctionsFromOO.Mixed
	Debug::Initializing( 'Initializing Maps_Pro_API class.' );

	if ( class_exists( '\\MapFusion\\Api\\Pro\\Maps_Pro_API' ) ) {
		$maps_pro_api = new \MapFusion\Api\Pro\Maps_Pro_API();
		$maps_pro_api->register_routes();
	} else {
		Debug::info( 'Maps_Pro_API class not found. Fallback failed.' );
	}
}
add_action( 'rest_api_init', '\\MapFusion\\Api\\Pro\\mapfusion_register_maps_pro_api_routes' );
