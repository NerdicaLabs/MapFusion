<?php
/**
 * AJAX Handler for MapFusion.
 *
 * This file defines the `Ajax` class, responsible for handling
 * all AJAX-related functionality within the MapFusion plugin,
 * including data processing, API communication, and user interactions.
 *
 * @package MapFusion
 */

namespace MapFusion;

use MapFusion\MakeSettings;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly. //
}

/**
 * Handles all AJAX-related logic for the MapFusion plugin.
 *
 * This class registers and processes AJAX requests, ensuring
 * secure and efficient communication between the front-end
 * and back-end of the plugin.
 */
class Ajax {


	/**
	 * Initialize AJAX handlers.
	 */
	public static function init() {
		Debug::initializing( 'Initializing AJAX handlers.' );

		// Define AJAX handlers. //
		$ajax_handlers = array(
			// Helper Functions //
			// get_setting //
			// set_setting //
			// update_option //
			// delete_setting //

			// Debug Functions //
			'mapfusion_get_debug_settings'  => array( __CLASS__, 'get_debug_settings' ),
			'mapfusion_save_debug'          => array( __CLASS__, 'save_debug_settings' ),
			'mapfusion_test_debug'          => array( __CLASS__, 'test_debug_log' ),
			'mapfusion_clear_log'           => array( __CLASS__, 'clear_log_file' ),

			// API-Key Management //
			'mapfusion_get_api_key'         => array( __CLASS__, 'handle_get_api_key' ),
			'mapfusion_reset_api_key'       => array( __CLASS__, 'handle_reset_api_key' ),

			// License Key Management //
			'mapfusion_get_license_key'     => array( __CLASS__, 'handle_get_license_key' ),
			'mapfusion_clear_license_key'   => array( __CLASS__, 'handle_clear_license_key' ),
			'mapfusion_save_license_key'    => array( __CLASS__, 'handle_save_license_key' ),
			'mapfusion_activate_license'    => array( __CLASS__, 'handle_activate_license' ),
			'mapfusion_deactivate_license'  => array( __CLASS__, 'handle_deactivate_license' ),

			// Make Token Management //
			'mapfusion_get_token'           => array( __CLASS__, 'handle_get_token' ),
			'mapfusion_save_make_token'     => array( __CLASS__, 'handle_save_make_token' ),
			'mapfusion_clear_make_token'    => array( __CLASS__, 'handle_clear_make_token' ),
			'mapfusion_delete_make_token'   => array( __CLASS__, 'handle_delete_token' ),
			'mapfusion_get_new_token'       => array( __CLASS__, 'handle_get_new_token' ),
			'mapfusion_test_make_token'     => array( __CLASS__, 'handle_test_make_token' ),
			'make_save_temp_token'          => array( __CLASS__, 'save_temp_make_token' ),
			'make_clear_temp_token'         => array( __CLASS__, 'clear_temp_make_token' ),

			// Make Settings Management //
			'mapfusion_fetch_zone'          => array( __CLASS__, 'handle_fetch_zone' ),
			'mapfusion_save_zone'           => array( __CLASS__, 'handle_save_zone' ),
			'mapfusion_fetch_organizations' => array( __CLASS__, 'handle_fetch_organizations' ),
			'mapfusion_save_organization'   => array( __CLASS__, 'handle_save_organization' ),
			'mapfusion_fetch_teams'         => array( __CLASS__, 'handle_fetch_teams' ),
			'mapfusion_save_team'           => array( __CLASS__, 'handle_save_team' ),
			'mapfusion_fetch_connections'   => array( __CLASS__, 'handle_fetch_connections' ),
			'mapfusion_save_connection'     => array( __CLASS__, 'handle_save_connection' ),

			// Make Connection Management //
			'mapfusion_test_connection'     => array( __CLASS__, 'handle_test_connection' ),
			'mapfusion_fetch_current'       => array( __CLASS__, 'handle_fetch_current' ),

			// Database Management //
			'mapfusion_export_database'     => array( __CLASS__, 'export_database' ),
			'mapfusion_import_database'     => array( __CLASS__, 'import_database' ),
			'mapfusion_clear_database'      => array( __CLASS__, 'clear_database' ),
		);

		// Register and log AJAX handlers. //
		foreach ( $ajax_handlers as $action => $callback ) {
			add_action( "wp_ajax_{$action}", $callback );
			Debug::initializing( "Registered AJAX handler: {$action}" );
		}
	}

	// =========================================
	// Helper Functions //
	// =========================================

	/**
	 * Helper function to retrieve a setting from the database with caching.
	 *
	 * @param string $table_name  The name of the settings table.
	 * @param string $setting_key The key of the setting to retrieve.
	 * @param string $cache_group The cache group name. Default 'mapfusion'.
	 * @param int    $cache_time  The cache expiration time in seconds. Default 3600.
	 * @return mixed The setting value or false if not found.
	 */
	private static function get_setting( $table_name, $setting_key, $cache_group = 'mapfusion', $cache_time = 3600 ) {
		global $wpdb;
		$cache_key = 'mapfusion_setting_' . $setting_key;
		$value     = wp_cache_get( $cache_key, $cache_group );
		if ( false === $value ) {
			$value = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT setting_value FROM {$table_name} WHERE setting_key = %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
					$setting_key
				)
			);
			if ( null !== $value ) {
				wp_cache_set( $cache_key, $value, $cache_group, $cache_time );
			}
		}
		return $value;
	}

	/**
	 * Helper function to save or update a setting in the database and update the cache.
	 *
	 * @param string $table_name  The name of the settings table.
	 * @param string $setting_key The key of the setting to update.
	 * @param mixed  $setting_value The new value for the setting.
	 * @param string $cache_group The cache group name. Default 'mapfusion'.
	 * @return bool True on success, false on failure.
	 */
	private static function set_setting( $table_name, $setting_key, $setting_value, $cache_group = 'mapfusion' ) {
		global $wpdb;
		$cache_key = 'mapfusion_setting_' . $setting_key;

		// Update or insert the setting. //
		$result = $wpdb->replace(
			$table_name,
			array(
				'setting_key'   => $setting_key,
				'setting_value' => $setting_value,
				'updated_at'    => current_time( 'mysql' ),
			),
			array( '%s', '%s', '%s' )
		);

		if ( false !== $result ) {
			// Clear and update cache. //
			wp_cache_delete( $cache_key, $cache_group );
			wp_cache_set( $cache_key, $setting_value, $cache_group, 3600 );
			return true;
		}
		return false;
	}

	/**
	 * Helper function to update a setting in the database and refresh its cache.
	 *
	 * @param string $table_name    The database table name.
	 * @param string $setting_key   The name of the setting to update.
	 * @param mixed  $setting_value The new value for the setting.
	 * @param string $cache_group   The cache group name. Default 'mapfusion'.
	 * @return bool True on success, false on failure.
	 */
	private static function update_setting( $table_name, $setting_key, $setting_value, $cache_group = 'mapfusion' ) {
		global $wpdb;
		$cache_key = 'mapfusion_setting_' . $setting_key;

		// Update only if the setting already exists in the database.
		$result = $wpdb->update(
			$table_name,
			array(
				'setting_value' => $setting_value,
				'updated_at'    => current_time( 'mysql' ),
			),
			array( 'setting_key' => $setting_key ),
			array( '%s', '%s' ), // Data types for the values
			array( '%s' )        // Data type for the WHERE clause
		);

		// Check if the update was successful and the row was modified.
		if ( false !== $result && $result > 0 ) {
			// Clear the cache to ensure the new value is used next time.
			wp_cache_delete( $cache_key, $cache_group );
			wp_cache_set( $cache_key, $setting_value, $cache_group, 3600 );
			return true;
		}
		return false;
	}

	/**
	 * Helper function to delete a setting from the database and clear its cache.
	 *
	 * @param string $table_name  The name of the settings table.
	 * @param string $setting_key The key of the setting to delete.
	 * @param string $cache_group The cache group name. Default 'mapfusion'.
	 * @return bool True on success, false on failure.
	 */
	private static function delete_setting( $table_name, $setting_key, $cache_group = 'mapfusion' ) {
		global $wpdb;
		$result = $wpdb->delete(
			$table_name,
			array( 'setting_key' => $setting_key ),
			array( '%s' )
		);

		if ( false !== $result ) {
			// Clear the associated cache.
			$cache_key = 'mapfusion_setting_' . $setting_key;
			wp_cache_delete( $cache_key, $cache_group );
			return true;
		}

		return false;
	}

	// =========================================
	// Debug Functions //
	// =========================================

	/**
	 * Handle fetching debug settings via AJAX.
	 */
	public static function get_debug_settings() {
		global $wpdb;

		try {
			Debug::info( '[get_debug_settings] Function called.' );

			// Validate nonce. //
			$nonce = isset( $_POST['nonce'] ) ? wp_unslash( $_POST['nonce'] ) : '';
			if ( ! check_ajax_referer( 'mapfusion_nonce', 'nonce', false ) ) {
				Debug::error( '[get_debug_settings] Nonce validation failed.' );
				wp_send_json_error(
					array(
						'message' => __( 'Invalid nonce. Action unauthorized.', 'mapfusion' ),
					),
					403
				);
				return;
			}

			// Check if debug settings are cached. //
			$cache_key       = 'mapfusion_debug_settings';
			$cached_settings = wp_cache_get( $cache_key, 'mapfusion' );
			if ( false !== $cached_settings ) {
				Debug::api( '[get_debug_settings] Returning cached debug settings:', $cached_settings );
				wp_send_json_success( $cached_settings );
				return;
			}

			// Define table name. //
			$table_name = $wpdb->prefix . 'mapfusion_settings';

			// Retrieve debug settings using helper function. //
			$debug_logging_value = self::get_setting( $table_name, 'debug_logging' );
			$debug_logging       = ( false !== $debug_logging_value ) ? (bool) $debug_logging_value : false;

			$debug_levels_value = self::get_setting( $table_name, 'debug_levels' );
			if ( false !== $debug_levels_value ) {
				$decoded_levels = json_decode( $debug_levels_value, true );
				$debug_levels   = is_array( $decoded_levels ) ? $decoded_levels : array( 'error', 'warning', 'info' );
			} else {
				$debug_levels = array( 'error', 'warning', 'info' );
			}

			// Construct response array. //
			$debug_settings = array(
				'debug_logging' => $debug_logging,
				'debug_levels'  => $debug_levels,
			);

			// Cache the debug settings. //
			wp_cache_set( $cache_key, $debug_settings, 'mapfusion', 3600 );

			Debug::api( '[get_debug_settings] Sending debug settings:', $debug_settings );
			wp_send_json_success( $debug_settings );
		} catch ( \Exception $e ) {
			Debug::critical(
				'[get_debug_settings] Exception occurred.',
				array(
					'error_message' => $e->getMessage(),
				)
			);
			wp_send_json_error(
				array(
					'message' => __( 'An unexpected error occurred. Please try again.', 'mapfusion' ),
				),
				500
			);
		}
	}

	/**
	 * Handle saving debug settings via AJAX.
	 *
	 * @throws \Exception If the database transaction fails.
	 */
	public static function save_debug_settings() {
		global $wpdb;

		// Validate nonce. //
		check_ajax_referer( 'mapfusion_nonce', 'nonce' );

		// Sanitize input values. //
		$debug_logging = isset( $_POST['debug_logging'] )
		? filter_var( wp_unslash( $_POST['debug_logging'] ), FILTER_VALIDATE_BOOLEAN )
		: false;

		$debug_levels = isset( $_POST['debug_levels'] )
		? json_decode( wp_unslash( $_POST['debug_levels'] ), true )
		: array();

		// Validate debug levels. //
		if ( ! is_array( $debug_levels ) ) {
			Debug::error( '[save_debug_settings] Invalid debug levels format.' );
			wp_send_json_error( array( 'message' => __( 'Invalid debug levels format.', 'mapfusion' ) ) );
			return;
		}

		// Define table name and combined cache key. //
		$table_name = $wpdb->prefix . 'mapfusion_settings';
		$cache_key  = 'mapfusion_debug_settings';

		try {
			$wpdb->query( 'START TRANSACTION' );

			// Store debug logging setting using helper function. //
			$result_logging = self::set_setting( $table_name, 'debug_logging', $debug_logging ? '1' : '0' );

			// Store debug levels setting using helper function. //
			$result_levels = self::set_setting( $table_name, 'debug_levels', wp_json_encode( $debug_levels ) );

			// Check for errors. //
			if ( false === $result_logging || false === $result_levels ) {
				throw new \Exception( __( 'Failed to save debug settings.', 'mapfusion' ) );
			}

			$wpdb->query( 'COMMIT' );

			// Refresh combined debug settings cache. //
			wp_cache_set(
				$cache_key,
				array(
					'debug_logging' => $debug_logging,
					'debug_levels'  => $debug_levels,
				),
				'mapfusion',
				3600
			);

				Debug::info(
					'[save_debug_settings] Debug settings updated successfully.',
					array(
						'debug_logging' => $debug_logging,
						'debug_levels'  => $debug_levels,
					)
				);

				wp_send_json_success( array( 'message' => __( 'Debug settings updated successfully.', 'mapfusion' ) ) );
		} catch ( \Exception $e ) {
			$wpdb->query( 'ROLLBACK' );
			Debug::error( '[save_debug_settings] Failed to save debug settings.', array( 'error' => $e->getMessage() ) );
			wp_send_json_error( array( 'message' => __( 'Failed to save debug settings.', 'mapfusion' ) ) );
		}
	}

	/**
	 * Handle clearing debug log file via AJAX using WP_Filesystem.
	 */
	public static function clear_log_file() {
		check_ajax_referer( 'mapfusion_nonce', 'nonce' );

		global $wp_filesystem;

		// Ensure WP_Filesystem is initialized //
		if ( empty( $wp_filesystem ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			WP_Filesystem();
		}

		$log_file = WP_CONTENT_DIR . '/mapfusion-debug.log';

		// Validate log file path security //
		$log_realpath    = realpath( $log_file );
		$wp_content_path = realpath( WP_CONTENT_DIR );

		if ( false === $log_realpath || false === $wp_content_path || ! str_starts_with( $log_realpath, $wp_content_path ) ) {
			Debug::critical( '[clear_log_file] Attempt to clear unauthorized log file.', array( 'log_file' => $log_file ) );
			wp_send_json_error( array( 'message' => __( 'Unauthorized log file path.', 'mapfusion' ) ) );
		}

		// Check if log file exists and is writable //
		if ( $wp_filesystem->exists( $log_file ) && $wp_filesystem->is_writable( $log_file ) ) {
			$success = $wp_filesystem->put_contents( $log_file, "[MapFusion INFO][Log Cleared] Log file cleared successfully.\n" );

			if ( $success ) {
				Debug::info( '[clear_log_file] Log file cleared successfully.' );
				wp_send_json_success( array( 'message' => __( 'Log file cleared successfully.', 'mapfusion' ) ) );
			}
		}

		Debug::error( '[clear_log_file] Log file does not exist or is not writable.', array( 'log_file' => $log_file ) );
		wp_send_json_error( array( 'message' => __( 'Log file does not exist or is not writable.', 'mapfusion' ) ) );
	}

	/**
	 * Handle testing debug logging via AJAX.
	 */
	public static function test_debug_log() {
		// Validate nonce.
		check_ajax_referer( 'mapfusion_nonce', 'nonce' );

		// Sanitize input.
		$level = isset( $_POST['level'] ) ? sanitize_text_field( wp_unslash( $_POST['level'] ) ) : null;

		if ( ! $level ) {
			$error_message = __( 'Missing log level.', 'mapfusion' );
			Debug::error( '[test_debug_log] Missing log level.' );
			wp_send_json_error( array( 'message' => $error_message ) );
		}

		// Log function call.
		Debug::info( '[test_debug_log] Function called with level: ' . $level );
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			error_log( '[MapFusion DEBUG] Function called with level: ' . $level ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		}

		if ( method_exists( Debug::class, $level ) ) {
			try {
				// Attempt to create a test log using the specified level.
				Debug::$level( 'Test log message created via AJAX.', array( 'context' => 'AJAX test' ) );

				// Log success.
				Debug::info( "Test log created successfully with level: {$level}", array( 'context' => 'AJAX test' ) );
				if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
					error_log( "[MapFusion DEBUG] Test log created successfully with level: {$level}" ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
				}

				// translators: %s is the log level used for the test log.
				wp_send_json_success( array( 'message' => sprintf( __( 'Test log created with level: %s', 'mapfusion' ), $level ) ) );
			} catch ( \Exception $e ) {
				$error_message = '[test_debug_log] Failed to create test log.';
				if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
					error_log( "[MapFusion ERROR] {$error_message} Exception: " . $e->getMessage() ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
				}
				Debug::error( $error_message, array( 'error' => $e->getMessage() ) );
				wp_send_json_error( array( 'message' => __( 'Failed to create test log.', 'mapfusion' ) ) );
			}
		} else {
			$error_message = __( 'Invalid log level.', 'mapfusion' );
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				error_log( "[MapFusion ERROR] {$error_message} Level: {$level}" ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
			}
			Debug::error( '[test_debug_log] Invalid log level.', array( 'level' => $level ) );
			wp_send_json_error( array( 'message' => $error_message ) );
		}
	}

	// =========================================
	// API-Key Management //
	// =========================================

	/**
	 * Handle the AJAX request to fetch the API key from wp_options.
	 */
	public static function handle_get_api_key() {
		$option_name = 'mapfusion_api_key';

		Debug::api( sprintf( '[handle_get_api_key] Fetching API key from wp_options with key "%s".', esc_html( $option_name ) ) );

		// Retrieve the API key from wp_options.
		$api_key = get_option( $option_name, false );

		// Log the raw return value from get_option().
		Debug::api( sprintf( '[handle_get_api_key] Raw value from get_option(): "%s".', esc_html( print_r( $api_key, true ) ) ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_print_r

		// Ensure a valid API key was retrieved.
		if ( false === $api_key || null === $api_key ) {
			Debug::api( sprintf( '[handle_get_api_key] No API key found for key "%s".', esc_html( $option_name ) ) );
			wp_send_json_error( array( 'message' => __( 'No API key found.', 'mapfusion' ) ), 404 );
		}

		// Sanitize and trim the API key.
		$api_key = trim( sanitize_text_field( $api_key ) );

		// Check if the API key is empty after sanitization.
		if ( empty( $api_key ) ) {
			Debug::api( sprintf( '[handle_get_api_key] API key found for key "%s" is empty after sanitization.', esc_html( $option_name ) ) );
			wp_send_json_error( array( 'message' => __( 'API key is empty.', 'mapfusion' ) ), 400 );
		}

		Debug::api( sprintf( '[handle_get_api_key] Successfully retrieved API key: "%s".', esc_html( $api_key ) ) );

		// Return API key to frontend.
		wp_send_json_success( array( 'apiKey' => $api_key ) );
	}

	/**
	 * Handle the AJAX request to reset the API key.
	 *
	 * Generates a new API key, updates it in the database and cache,
	 * and returns the new key. If an error occurs, an exception is thrown.
	 *
	 * @throws \Exception If a database error occurs while updating the API key.
	 */
	public static function handle_reset_api_key() {
		Debug::info( '[handle_reset_api_key] Starting API key reset process.' );

		// Validate security nonce.
		check_ajax_referer( 'mapfusion_nonce', 'nonce' );

		// Generate a new API key.
		$new_api_key = wp_generate_password( 40, false, false );

		// Log that a new key was generated (without exposing it).
		Debug::api( '[handle_reset_api_key] New API key generated.' );

		global $wpdb;
		$table_name = $wpdb->prefix . 'mapfusion_settings';
		$cache_key  = 'mapfusion_api_key';

		try {
			// Ensure the generated key is valid.
			if ( empty( $new_api_key ) || ! is_string( $new_api_key ) || strlen( $new_api_key ) < 40 ) {
				throw new \Exception( 'Generated API key is invalid.' );
			}

			// Save the new API key using helper function WITH CACHE.
			$result = self::update_setting( $table_name, 'mapfusion_api_key', $new_api_key, $cache_key );

			if ( false === $result ) {
				throw new \Exception( 'Database update failed for API key.' );
			}

			// Check if cache is updated correctly
			$cached_api_key = wp_cache_get( $cache_key, 'mapfusion' );
			if ( $cached_api_key !== $new_api_key ) {
				Debug::warning(
					'[handle_reset_api_key] Cache mismatch after update.',
					array(
						'expected' => $new_api_key,
						'cached'   => $cached_api_key,
					)
				);
			} else {
				Debug::info( '[handle_reset_api_key] Cache updated successfully.' );
			}

			Debug::info( '[handle_reset_api_key] API key successfully saved.' );
			wp_send_json_success(
				array(
					'message' => __( 'API key has been reset successfully.', 'mapfusion' ),
					'api_key' => $new_api_key,
				)
			);
		} catch ( \Exception $e ) {
			Debug::critical( '[handle_reset_api_key] Exception occurred.', array( 'error_message' => $e->getMessage() ) );
			wp_send_json_error(
				array(
					'message' => __( 'An unexpected error occurred while resetting the API key.', 'mapfusion' ),
					'code'    => 'exception_error',
				),
				500
			);
		}
	}

	// =========================================
	// License Key Management //
	// =========================================

	/**
	 * Handle the AJAX request to fetch the license key and active status.
	 *
	 * Retrieves the `mapfusion_license_key` and `mapfusion_license_active` status from the database.
	 */
	public static function handle_get_license_key() {
		global $wpdb;

		$table_name  = $wpdb->prefix . 'mapfusion_settings';
		$key_setting = 'mapfusion_license_key';
		$status_key  = 'mapfusion_license_active';

		Debug::api( sprintf( '[handle_get_license_key] Fetching license key and active status from table "%s".', esc_html( $table_name ) ) );

		// Ensure the get_setting method exists to avoid fatal errors.
		if ( ! method_exists( __CLASS__, 'get_setting' ) ) {
			Debug::critical( '[handle_get_license_key] Method get_setting does not exist. Cannot retrieve license key and status.' );
			wp_send_json_error( array( 'message' => __( 'Internal error: Unable to retrieve license key and status.', 'mapfusion' ) ), 500 );
		}

		// Retrieve the license key using the helper function.
		$license_key = self::get_setting( $table_name, $key_setting );

		// If no license key found, return a 204 No Content response without triggering an error
		if ( false === $license_key || null === $license_key ) {
			Debug::api( '[handle_get_license_key] No license key found.' );
			status_header( 204 );  // 204 No Content
			exit; // Stop the execution without sending additional data
		}

		// Retrieve the license active status using the helper function.
		$license_active = self::get_setting( $table_name, $status_key );

		// If no active status found, assume inactive by default
		if ( false === $license_active || null === $license_active ) {
			Debug::api( '[handle_get_license_key] No active status found. Assuming inactive.' );
			$license_active = 0; // Default to inactive
		}

		// Sanitize and interpret the license active status
		$license_active = (int) $license_active; // Ensure it's treated as an integer (0 or 1)
		$status_message = ( 1 === $license_active ) ? 'active' : 'inactive';

		// Return both license key and status
		Debug::api( '[handle_get_license_key] License key and status retrieved successfully.' );
		wp_send_json_success(
			array(
				'license_key'    => $license_key,        // Send the license key
				'license_status' => $status_message,     // Send the interpreted license status (active/inactive)
			)
		);
	}

	/**
	 * Handle the AJAX request to save a new license key.
	 *
	 * Stores the provided license key in the database and updates the cache.
	 *
	 * @throws \Exception If a database error occurs while saving the license key.
	 */
	public static function handle_save_license_key() {
		Debug::api( '[handle_save_license_key] Starting license key save process.' );

		// Validate security nonce.
		if ( ! check_ajax_referer( 'mapfusion_nonce', 'nonce', false ) ) {
			Debug::warning( '[handle_save_license_key] Nonce validation failed.' );
			wp_send_json_error(
				array(
					'message' => __( 'Nonce validation failed.', 'mapfusion' ),
					'code'    => 'nonce_error',
				),
				403
			);
		}

		// Get the license key from the request.
		$license_key = isset( $_POST['license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['license_key'] ) ) : '';

		Debug::api( sprintf( '[handle_save_license_key] Received license key: "%s"', esc_html( $license_key ) ) );

		if ( empty( $license_key ) || strlen( $license_key ) < 20 ) {
			Debug::warning( '[handle_save_license_key] Invalid or empty license key provided.' );
			wp_send_json_error(
				array(
					'message' => __( 'Invalid license key. Please enter a valid key.', 'mapfusion' ),
					'code'    => 'invalid_license_key',
				),
				400
			);
		}

		global $wpdb;
		$table_name  = $wpdb->prefix . 'mapfusion_settings';
		$setting_key = 'mapfusion_license_key';
		$cache_key   = 'mapfusion_license_key';

		Debug::api( sprintf( '[handle_save_license_key] Saving license key in table "%s" with setting key "%s".', esc_html( $table_name ), esc_html( $setting_key ) ) );

		try {
			// Save the new license key.
			$result = self::set_setting( $table_name, $setting_key, $license_key, $cache_key );

			if ( false === $result ) {
				throw new \Exception( 'Database update failed while saving the license key.' );
			}

			Debug::api( '[handle_save_license_key] License key successfully stored in database.' );

			// Ensure cache is updated.
			wp_cache_set( $cache_key, $license_key, 'mapfusion' );

			// Check if cache is updated correctly
			$cached_license_key = wp_cache_get( $cache_key, 'mapfusion' );
			if ( $cached_license_key !== $license_key ) {
				Debug::warning(
					'[handle_save_license_key] Cache mismatch after update.',
					array(
						'expected' => $license_key,
						'cached'   => $cached_license_key,
					)
				);
			} else {
				Debug::api( '[handle_save_license_key] Cache updated successfully.' );
			}

			Debug::api( '[handle_save_license_key] License key successfully saved as "mapfusion_license_key".' );
			wp_send_json_success(
				array(
					'message'     => __( 'License key has been saved successfully.', 'mapfusion' ),
					'license_key' => $license_key,
				)
			);
		} catch ( \Exception $e ) {
			Debug::critical( '[handle_save_license_key] Exception occurred.', array( 'error_message' => $e->getMessage() ) );
			wp_send_json_error(
				array(
					'message' => __( 'An unexpected error occurred while saving the license key.', 'mapfusion' ),
					'code'    => 'exception_error',
				),
				500
			);
		}
	}

	/**
	 * Handle the AJAX request to clear the license key.
	 *
	 * Removes the stored license key from the database and cache.
	 *
	 * @throws \Exception If a database error occurs while clearing the license key.
	 */
	public static function handle_clear_license_key() {
		Debug::info( '[handle_clear_license_key] Starting license key clearing process.' );

		// Validate security nonce.
		check_ajax_referer( 'mapfusion_nonce', 'nonce' );

		global $wpdb;
		$table_name = $wpdb->prefix . 'mapfusion_settings';
		$cache_key  = 'mapfusion_license_key';

		try {
			// Remove the license key from the database.
			$result = self::update_setting( $table_name, 'mapfusion_license_key', '', $cache_key );

			if ( false === $result ) {
				throw new \Exception( 'Database update failed while clearing the license key.' );
			}

			// Ensure cache is cleared.
			wp_cache_delete( $cache_key, 'mapfusion' );

			Debug::info( '[handle_clear_license_key] License key successfully cleared.' );
			wp_send_json_success(
				array(
					'message' => __( 'License key has been cleared successfully.', 'mapfusion' ),
				)
			);
		} catch ( \Exception $e ) {
			Debug::critical( '[handle_clear_license_key] Exception occurred.', array( 'error_message' => $e->getMessage() ) );
			wp_send_json_error(
				array(
					'message' => __( 'An unexpected error occurred while clearing the license key.', 'mapfusion' ),
					'code'    => 'exception_error',
				),
				500
			);
		}
	}

	/**
	 * Handle the AJAX request to activate the license and update the license active status.
	 *
	 * Updates the `mapfusion_license_active` field in the database to true.
	 *
	 * @throws \Exception If an error occurs while updating the database or making an API request.
	 */
	public static function handle_activate_license() {
		Debug::api( '[handle_activate_license] Starting license activation process.' );

		// Validate security nonce.
		if ( ! check_ajax_referer( 'mapfusion_nonce', 'nonce', false ) ) {
			Debug::warning( '[handle_activate_license] Nonce validation failed.' );
			wp_send_json_error(
				array(
					'message' => __( 'Nonce validation failed.', 'mapfusion' ),
					'code'    => 'nonce_error',
				),
				403
			);
		}

		global $wpdb;
		$table_name = $wpdb->prefix . 'mapfusion_settings';
		$status_key = 'mapfusion_license_active'; // Field to update (active status)

		try {
			// Use the helper function to set the 'mapfusion_license_active' field to true
			$status_result = self::set_setting( $table_name, $status_key, 1, 'mapfusion_license_active' );

			if ( false === $status_result ) {
				throw new \Exception( 'Database update failed while setting the license active status.' );
			}

			Debug::api( '[handle_activate_license] License active status successfully updated to true.' );
			wp_send_json_success(
				array(
					'message' => __( 'License has been successfully activated and marked as active.', 'mapfusion' ),
				)
			);
		} catch ( \Exception $e ) {
			Debug::critical( '[handle_activate_license] Exception occurred.', array( 'error_message' => $e->getMessage() ) );
			wp_send_json_error(
				array(
					'message' => __( 'An unexpected error occurred while activating the license.', 'mapfusion' ),
					'code'    => 'exception_error',
				),
				500
			);
		}
	}

	/**
	 * Handle the AJAX request to deactivate the license and update the license active status.
	 *
	 * Updates the `mapfusion_license_active` field in the database to false.
	 *
	 * @throws \Exception If an error occurs while updating the database or making an API request.
	 */
	public static function handle_deactivate_license() {
		Debug::api( '[handle_deactivate_license] Starting license deactivation process.' );

		// Validate security nonce.
		if ( ! check_ajax_referer( 'mapfusion_nonce', 'nonce', false ) ) {
			Debug::warning( '[handle_deactivate_license] Nonce validation failed.' );
			wp_send_json_error(
				array(
					'message' => __( 'Nonce validation failed.', 'mapfusion' ),
					'code'    => 'nonce_error',
				),
				403
			);
		}

		global $wpdb;
		$table_name = $wpdb->prefix . 'mapfusion_settings';
		$status_key = 'mapfusion_license_active'; // Field to update (active status)

		try {
			// Use the helper function to set the 'mapfusion_license_active' field to false
			$status_result = self::set_setting( $table_name, $status_key, 0, 'mapfusion_license_active' );

			if ( false === $status_result ) {
				throw new \Exception( 'Database update failed while setting the license inactive status.' );
			}

			Debug::api( '[handle_deactivate_license] License active status successfully updated to false.' );
			wp_send_json_success(
				array(
					'message' => __( 'License has been successfully deactivated and marked as inactive.', 'mapfusion' ),
				)
			);
		} catch ( \Exception $e ) {
			Debug::critical( '[handle_deactivate_license] Exception occurred.', array( 'error_message' => $e->getMessage() ) );
			wp_send_json_error(
				array(
					'message' => __( 'An unexpected error occurred while deactivating the license.', 'mapfusion' ),
					'code'    => 'exception_error',
				),
				500
			);
		}
	}

	// =========================================
	// Make Token Management //
	// =========================================

	/**
	 * Handle the AJAX request to fetch the Make API token from the database.
	 */
	public static function handle_get_token() {
		global $wpdb;

		$table_name  = $wpdb->prefix . 'mapfusion_settings';
		$setting_key = 'make_token';

		Debug::api( sprintf( '[handle_get_token] Fetching Make token from table "%s" with key "%s".', esc_html( $table_name ), esc_html( $setting_key ) ) );

		// Retrieve the token using the helper function.
		$make_token = self::get_setting( $table_name, $setting_key );

		// Ensure a valid token was retrieved.
		if ( false === $make_token || null === $make_token ) {
			Debug::api( sprintf( '[handle_get_token] No token found for key "%s".', esc_html( $setting_key ) ) );
			wp_send_json_error( array( 'message' => __( 'No token found.', 'mapfusion' ) ), 404 );
		}

		// Sanitize and trim the token.
		$make_token = trim( sanitize_text_field( $make_token ) );

		// Ensure token is not empty.
		if ( empty( $make_token ) ) {
			Debug::api( sprintf( '[handle_get_token] Token found for key "%s" is empty.', esc_html( $setting_key ) ) );
			wp_send_json_error( array( 'message' => __( 'Token is empty.', 'mapfusion' ) ), 400 );
		}

		Debug::api( sprintf( '[handle_get_token] Token retrieved successfully for key "%s".', esc_html( $setting_key ) ) );
		wp_send_json_success( array( 'token' => $make_token ) );
	}

	/**
	 * Handle the AJAX request to save the Make Token.
	 *
	 * @throws \Exception If the database transaction fails.
	 */
	public static function handle_save_make_token() {
		Debug::info( '[handle_save_make_token] Starting save process for Make token.' );

		// Validate security nonce.
		check_ajax_referer( 'mapfusion_nonce', 'nonce' );

		// Retrieve and sanitize the token from POST.
		$token = isset( $_POST['token'] ) ? sanitize_text_field( wp_unslash( $_POST['token'] ) ) : '';

		// Ensure the token is not empty.
		if ( empty( $token ) ) {
			Debug::error( '[handle_save_make_token] Token is missing.' );
			wp_send_json_error(
				array(
					'message' => __( 'Token is required.', 'mapfusion' ),
					'code'    => 'token_missing',
				),
				400
			);
				return;
		}

		global $wpdb;
		$table_name = $wpdb->prefix . 'mapfusion_settings';
		$cache_key  = 'mapfusion_make_token';

		Debug::info( '[handle_save_make_token] Using table: ' . esc_html( $table_name ) );
		Debug::api( '[handle_save_make_token] Received token.', array( 'token_length' => strlen( $token ) ) );

		try {
			$wpdb->query( 'START TRANSACTION' );

			// Use helper function to update the token in the database.
			$result = self::set_setting( $table_name, 'make_token', $token );
			if ( false === $result ) {
				throw new \Exception( 'Database error: failed to save token.' );
			}

			$wpdb->query( 'COMMIT' );

			// Refresh token cache.
			wp_cache_set( $cache_key, $token, 'mapfusion', 3600 );

			Debug::info( '[handle_save_make_token] Token successfully saved.' );
			wp_send_json_success(
				array(
					'message' => __( 'Token saved successfully.', 'mapfusion' ),
					'token'   => $token,
				)
			);
		} catch ( \Exception $e ) {
			$wpdb->query( 'ROLLBACK' );
			Debug::critical( '[handle_save_make_token] Exception occurred.', array( 'error' => $e->getMessage() ) );
			wp_send_json_error(
				array(
					'message' => __( 'An unexpected error occurred while saving the token.', 'mapfusion' ),
					'code'    => 'exception_error',
				),
				500
			);
		}
	}

	/**
	 * Handle the AJAX request to clear the Make Token.
	 *
	 * Clears the Make token from the database. Supports both AJAX calls (wp_send_json_*)
	 * and internal calls (returns structured data).
	 *
	 * @param bool $return_only If true, returns the result as an array instead of sending a JSON response.
	 * @return mixed Returns an array indicating success or failure if $return_only is true.
	 * @throws \Exception If a database error occurs while deleting the token.
	 */
	public static function handle_clear_make_token( $return_only = false ): mixed {
		Debug::info( '[handle_clear_make_token] Starting token clear process.' );
		global $wpdb;
		$table_name = $wpdb->prefix . 'mapfusion_settings';

		try {
			$wpdb->query( 'START TRANSACTION' );

			// Use helper function to delete the token from the database and clear its cache.
			$result = self::delete_setting( $table_name, 'make_token' );
			if ( false === $result ) {
				throw new \Exception( 'Database error: failed to delete token.' );
			}

			$wpdb->query( 'COMMIT' );

			Debug::info( '[handle_clear_make_token] Token successfully cleared from the database.' );
			$success_response = array(
				'success' => true,
				'message' => __( 'Token cleared successfully.', 'mapfusion' ),
			);

			return $return_only ? $success_response : wp_send_json_success( $success_response );
		} catch ( \Exception $e ) {
			$wpdb->query( 'ROLLBACK' );
			Debug::critical( '[handle_clear_make_token] Exception occurred.', array( 'error_message' => $e->getMessage() ) );
			$error_response = array(
				'success' => false,
				'message' => __( 'An unexpected error occurred while clearing the token.', 'mapfusion' ),
				'code'    => 'exception_error',
			);

			return $return_only ? $error_response : wp_send_json_error( $error_response, 500 );
		}
	}

	/**
	 * Handles the deletion of the Make token.
	 *
	 * Fetches the token and zone from the database via helper functions, verifies
	 * the token via the Make API, deletes it via an API request, and removes it
	 * from the database and cache. Supports both AJAX calls and internal calls.
	 *
	 * @param bool $return_only If true, returns an array instead of sending a JSON response.
	 * @return mixed Returns an array if $return_only is true, otherwise sends a JSON response.
	 * @throws \Exception If an unexpected error occurs during the token deletion process.
	 */
	public static function handle_delete_token( $return_only = false ): mixed {
		global $wpdb;
		$table_name = $wpdb->prefix . 'mapfusion_settings';

		Debug::api( '[handle_delete_token] Starting token deletion process.' );

		try {
			// Retrieve Make zone and token using helper functions.
			$make_zone  = self::get_setting( $table_name, 'make_zone' );
			$make_token = self::get_setting( $table_name, 'make_token' );

			// Ensure both values are present.
			if ( empty( $make_zone ) || empty( $make_token ) ) {
				throw new \Exception( __( 'Missing required database values.', 'mapfusion' ) );
			}

			// Validate token via test API call.
			Debug::api( '[handle_delete_token] Validating token...' );
			$test_result = self::handle_test_make_token( true );
			if ( ! is_array( $test_result ) || empty( $test_result['isValid'] ) || empty( $test_result['timestamp'] ) ) {
				throw new \Exception( __( 'Token test failed or invalid.', 'mapfusion' ) );
			}
			$timestamp = sanitize_text_field( $test_result['timestamp'] );

			// Construct API request.
			$base_url = MakeSettings::VALID_ZONES[ $make_zone ] ?? null;
			if ( ! $base_url ) {
				throw new \Exception( __( 'Invalid zone value provided.', 'mapfusion' ) );
			}
			$api_url = trailingslashit( $base_url ) . 'api/v2/users/me/api-tokens/' . rawurlencode( $timestamp );
			Debug::api( '[handle_delete_token] DELETE API URL: ' . esc_url( $api_url ) );

			$headers = array(
				'Authorization' => 'Token ' . $make_token,
			);

			// Send DELETE request to the Make API.
			Debug::api( '[handle_delete_token] Sending DELETE request...' );
			$response = wp_remote_request(
				$api_url,
				array(
					'method'  => 'DELETE',
					'headers' => $headers,
					'timeout' => 15,
				)
			);

			if ( is_wp_error( $response ) ) {
				throw new \Exception( __( 'Error during API request.', 'mapfusion' ) );
			}

				$response_code = wp_remote_retrieve_response_code( $response );
			if ( ! in_array( $response_code, array( 200, 204 ), true ) ) {
				throw new \Exception( __( 'Failed to delete token.', 'mapfusion' ) );
			}

				Debug::api( '[handle_delete_token] Token deleted successfully from Make API.' );

				// Remove token from the database using our helper function.
				$delete_result = self::delete_setting( $table_name, 'make_token' );
			if ( false === $delete_result ) {
				throw new \Exception( __( 'Failed to delete token in database.', 'mapfusion' ) );
			}

				// Clear the Make zone cache manually (if nödvändigt).
				wp_cache_delete( 'mapfusion_setting_make_zone', 'mapfusion' );
				Debug::api( '[handle_delete_token] Cache cleared.' );

				$success_response = array(
					'success' => true,
					'message' => __( 'Token deleted successfully.', 'mapfusion' ),
				);

				return $return_only ? $success_response : wp_send_json_success( $success_response );
		} catch ( \Exception $e ) {
			Debug::critical( '[handle_delete_token] Exception occurred: ' . $e->getMessage() );

			$error_response = array(
				'success' => false,
				'message' => $e->getMessage(),
			);

			return $return_only ? $error_response : wp_send_json_error( $error_response, 500 );
		}
	}

	/**
	 * Handles the AJAX request to retrieve and replace the Make token.
	 *
	 * Validates the current token, generates a new one, deletes the old token,
	 * and stores the new token securely.
	 *
	 * @throws \Exception If an unexpected error occurs.
	 */
	public static function handle_get_new_token() {
		global $wpdb;
		$cache_key  = 'mapfusion_make_token';
		$table_name = $wpdb->prefix . 'mapfusion_settings';

		Debug::api( '[handle_get_new_token] Starting the process to obtain a new token.' );

		try {
			// Validate the current token.
			Debug::api( '[handle_get_new_token] Testing the current token...' );
			$test_result = self::handle_test_make_token( true );
			if ( ! is_array( $test_result ) || empty( $test_result['isValid'] ) || empty( $test_result['timestamp'] ) ) {
				throw new \Exception( __( 'Current token is invalid or could not be tested.', 'mapfusion' ) );
			}

			$timestamp = sanitize_text_field( $test_result['timestamp'] );
			Debug::api( '[handle_get_new_token] Retrieved token timestamp: ' . esc_html( $timestamp ) );

			// Generate a new token.
			Debug::api( '[handle_get_new_token] Creating a new token...' );
			$new_token_result = self::create_new_token();
			if ( empty( $new_token_result['token'] ) ) {
				throw new \Exception( __( 'Failed to create a new token.', 'mapfusion' ) );
			}

			$new_token = sanitize_text_field( trim( $new_token_result['token'] ) );
			Debug::api( '[handle_get_new_token] Sanitized new token: ' . esc_html( $new_token ) );

			// Save the new token temporarily.
			Debug::api( '[handle_get_new_token] Temporarily saving the new token...' );
			if ( ! self::save_temp_make_token( $new_token ) ) {
				throw new \Exception( __( 'Failed to temporarily save the new token.', 'mapfusion' ) );
			}

			// Delete the old token.
			Debug::api( '[handle_get_new_token] Deleting the old token...' );
			$delete_result = self::handle_delete_token( true );
			if ( ! is_array( $delete_result ) || empty( $delete_result['success'] ) ) {
				throw new \Exception( __( 'Failed to delete the old token.', 'mapfusion' ) );
			}

			// Save the new token permanently in the database using the helper function.
			Debug::api( '[handle_get_new_token] Saving the new token in the database...' );
			if ( ! self::update_setting( $table_name, 'make_token', $new_token ) ) {
				throw new \Exception( __( 'Failed to save the token permanently.', 'mapfusion' ) );
			}

			// Clear the cache and temporary token.
			wp_cache_delete( $cache_key );
			self::clear_temp_make_token();

			Debug::api( '[handle_get_new_token] New token successfully created and saved.' );
			wp_send_json_success(
				array(
					'message' => __( 'New token created, old token deleted, and saved successfully.', 'mapfusion' ),
					'token'   => $new_token,
				)
			);
		} catch ( \Exception $e ) {
			Debug::critical( '[handle_get_new_token] Exception occurred: ' . $e->getMessage() );
			wp_send_json_error(
				array(
					'message' => $e->getMessage(),
				),
				500
			);
		}
	}

	/**
	 * Creates a new Make API Token.
	 *
	 * Fetches necessary credentials from the database, validates the zone, and
	 * makes a request to Make's API to generate a new token.
	 *
	 * @throws \Exception If an unexpected error occurs.
	 * @return array Response containing the token or an error message.
	 */
	private static function create_new_token() {
		global $wpdb;

		$cache_key = 'mapfusion_new_make_token';

		// Check if a cached token exists.
		$cached_token = wp_cache_get( $cache_key, 'mapfusion' );
		if ( false !== $cached_token ) {
			Debug::api( '[create_new_token] Returning cached API token.' );
			return array( 'token' => $cached_token );
		}

		Debug::api( '[create_new_token] Starting request to create a new Make API Token.' );

		try {
			// Define table name.
			$table_name = $wpdb->prefix . 'mapfusion_settings';

			// Retrieve required values from the database using helper function.
			$make_zone  = self::get_setting( $table_name, 'make_zone' );
			$make_token = self::get_setting( $table_name, 'make_token' );

			if ( empty( $make_zone ) || empty( $make_token ) ) {
				throw new \Exception( __( 'Missing required database values.', 'mapfusion' ) );
			}

			// Validate API base URL.
			Debug::api( '[create_new_token] Validating zone and constructing API URL...' );
			$base_url = MakeSettings::get_zone_baseurl( $make_zone );
			if ( ! $base_url ) {
				throw new \Exception( __( 'Invalid zone specified in the database.', 'mapfusion' ) );
			}

			$api_url = trailingslashit( $base_url ) . 'api/v2/users/me/api-tokens';
			Debug::api( '[create_new_token] Constructed API URL: ' . esc_url( $api_url ) );

			// Define the request body and headers.
			$body = wp_json_encode(
				array(
					'label' => 'MapFusion Generated Token',
					'scope' => MakeSettings::get_scopes(),
				),
				JSON_UNESCAPED_SLASHES
			);

				$headers = array(
					'Authorization' => 'Token ' . $make_token,
					'Content-Type'  => 'application/json',
				);

				// Send API request.
				Debug::api( '[create_new_token] Sending API request...' );
				$response = wp_remote_post(
					$api_url,
					array(
						'headers' => $headers,
						'body'    => $body,
						'timeout' => 15,
					)
				);

				// Handle API errors.
			if ( is_wp_error( $response ) ) {
				// translators: %s represents the error message returned from the API request.
				throw new \Exception( sprintf( __( 'API request failed: %s', 'mapfusion' ), $response->get_error_message() ) );
			}

				$response_body    = wp_remote_retrieve_body( $response );
				$decoded_response = json_decode( $response_body, true );

			if ( empty( $decoded_response['apiToken']['token'] ) ) {
				throw new \Exception( __( 'Token not found in API response.', 'mapfusion' ) );
			}

				$new_token = sanitize_text_field( $decoded_response['apiToken']['token'] );

				// Cache the new token for performance.
				wp_cache_set( $cache_key, $new_token, 'mapfusion', 3600 );

				Debug::api( '[create_new_token] New API Token created successfully.' );

				return array( 'token' => $new_token );
		} catch ( \Exception $e ) {
			Debug::critical( '[create_new_token] Exception occurred: ' . $e->getMessage() );
			return array( 'error' => $e->getMessage() );
		}
	}

	/**
	 * Handle the AJAX request to test the Make Token.
	 *
	 * Fetches the Make API token and validates it by sending a request to Make's API.
	 * Supports both AJAX calls (wp_send_json_*) and internal calls (returns structured data).
	 *
	 * @param bool $return_only If true, returns the result as an array instead of sending a JSON response.
	 * @throws \Exception If an unexpected error occurs.
	 * @return array|null Returns an array if $return_only is true, otherwise null.
	 */
	public static function handle_test_make_token( $return_only = false ) {
		global $wpdb;
		$cache_key    = 'mapfusion_make_token_check';
		$cache_result = wp_cache_get( $cache_key, 'mapfusion' );

		if ( false !== $cache_result ) {
			Debug::api( '[handle_test_make_token] Returning cached API token validation.' );
			if ( $return_only ) {
				return $cache_result;
			}
			wp_send_json_success( $cache_result );
		}

		Debug::api( '[handle_test_make_token] Starting request to test Make API Token.' );

		try {
			$table_name = $wpdb->prefix . 'mapfusion_settings';

			// Retrieve make_zone and make_token using helper function.
			$make_zone  = self::get_setting( $table_name, 'make_zone' );
			$make_token = self::get_setting( $table_name, 'make_token' );

			if ( empty( $make_zone ) || empty( $make_token ) ) {
				throw new \Exception( __( 'Missing required database values.', 'mapfusion' ) );
			}

			// Validate API base URL.
			$base_url = MakeSettings::VALID_ZONES[ $make_zone ] ?? null;
			if ( ! $base_url ) {
				throw new \Exception( __( 'Invalid zone value.', 'mapfusion' ) );
			}

			$api_url = trailingslashit( $base_url ) . 'api/v2/users/me/api-tokens';
			$headers = array( 'Authorization' => 'Token ' . $make_token );

			Debug::api( '[handle_test_make_token] Sending API request.', array( 'url' => $api_url ) );

			// Send API request.
			$response = wp_remote_get( $api_url, array( 'headers' => $headers ) );

			if ( is_wp_error( $response ) ) {
				// translators: %s represents the error message returned from the API request.
				throw new \Exception( sprintf( __( 'API request error: %s', 'mapfusion' ), $response->get_error_message() ) );
			}

			// Validate API response.
			$response_code    = wp_remote_retrieve_response_code( $response );
			$response_body    = wp_remote_retrieve_body( $response );
			$decoded_response = json_decode( $response_body, true );

			if ( empty( $decoded_response['apiTokens'] ) ) {
				throw new \Exception( __( 'No tokens found in API response.', 'mapfusion' ) );
			}

			Debug::api( '[handle_test_make_token] API response status code: ' . $response_code );

			$tokens    = $decoded_response['apiTokens'];
			$is_valid  = false;
			$timestamp = null;

			foreach ( $tokens as $token ) {
				// Compare the prefix of the tokens.
				if ( explode( '-', $make_token )[0] === explode( '-', $token['token'] )[0] ) { // phpcs:ignore WordPress.PHP.YodaConditions.NotYoda
					$is_valid  = true;
					$timestamp = $token['created'] ?? null;
					Debug::api( '[handle_test_make_token] Match found for token.' );
					break;
				}
			}

			$result = array(
				'isValid'   => $is_valid,
				'timestamp' => $timestamp,
			);

			// Cache result.
			wp_cache_set( $cache_key, $result, 'mapfusion', 3600 );

			if ( $return_only ) {
				return $result;
			}

			wp_send_json_success( $result );
		} catch ( \Exception $e ) {
			Debug::critical( '[handle_test_make_token] Exception occurred: ' . $e->getMessage() );

			$error_response = array(
				'isValid'   => false,
				'timestamp' => null,
			);

			if ( $return_only ) {
				return $error_response;
			}

			wp_send_json_error( array( 'message' => $e->getMessage() ), 500 );
		}
	}

	/**
	 * Save a temporary Make API Token to the database.
	 *
	 * @param string $token The Make API token to be saved.
	 * @return bool True if the token was successfully saved, false otherwise.
	 * @throws \Exception If a database error occurs.
	 */
	public static function save_temp_make_token( $token ) {
		if ( empty( $token ) ) {
			Debug::api( '[save_temp_make_token] Token is empty. Aborting.' );
			return false;
		}

		global $wpdb;
		$table_name = $wpdb->prefix . 'mapfusion_settings';
		Debug::api( '[save_temp_make_token] Saving temporary token to the database.' );

		// Use the helper function to update the temporary token.
		$result = self::update_setting( $table_name, 'temp_make_token', sanitize_text_field( $token ) );
		if ( false === $result ) {
			Debug::critical( '[save_temp_make_token] Failed to save the temporary token.' );
			return false;
		}

		Debug::api( '[save_temp_make_token] Temporary token saved successfully.' );
		return true;
	}

	/**
	 * Clear the temporary Make API Token from the database.
	 *
	 * @return bool True if the token was successfully deleted, false otherwise.
	 * @throws \Exception If a database error occurs.
	 */
	public static function clear_temp_make_token() {
		global $wpdb;
		$table_name = $wpdb->prefix . 'mapfusion_settings';
		Debug::api( '[clear_temp_make_token] Clearing temporary token from the database.' );

		// Use the helper function to delete the temporary token.
		$result = self::delete_setting( $table_name, 'temp_make_token' );
		if ( false === $result ) {
			Debug::critical( '[clear_temp_make_token] Failed to clear the temporary token.' );
			return false;
		}

		Debug::api( '[clear_temp_make_token] Temporary token cleared successfully.' );
		return true;
	}

	// =========================================
	// Make Settings Management
	// =========================================

	/**
	 * Handle AJAX request to fetch zones for dropdown menu.
	 *
	 * Fetches valid zones for the dropdown, validates nonce and user permissions,
	 * and retrieves cached data if available.
	 */
	public static function handle_fetch_zone() {
		Debug::info( '[handle_fetch_zone] Fetching zones for dropdown.' );

		// Validate nonce.
		$nonce = isset( $_POST['nonce'] ) ? wp_unslash( $_POST['nonce'] ) : '';
		if ( ! check_ajax_referer( 'mapfusion_nonce', 'nonce', false ) ) {
			Debug::error( '[handle_fetch_zone] Invalid nonce.' );
			wp_send_json_error(
				array(
					'message' => __( 'Invalid security token. Please reload the page.', 'mapfusion' ),
				),
				403
			);
		}

		// Check user permissions.
		if ( ! current_user_can( 'manage_options' ) ) {
			Debug::error( '[handle_fetch_zone] Unauthorized action attempted.' );
			wp_send_json_error(
				array(
					'message' => __( 'You do not have permission to perform this action.', 'mapfusion' ),
				),
				403
			);
		}

		// Cache key for storing the list of zones.
		$cache_key = 'mapfusion_zone_list';
		$zones     = wp_cache_get( $cache_key, 'mapfusion' );

		// Fetch valid zones for the dropdown if not cached.
		if ( false === $zones ) {
			$zones = MakeSettings::get_zones_for_dropdown();

			if ( ! empty( $zones ) ) {
				wp_cache_set( $cache_key, $zones, 'mapfusion', 3600 ); // Store in cache for 1 hour.
			}
		}

		// Handle empty zone list.
		if ( empty( $zones ) ) {
			Debug::error( '[handle_fetch_zone] No zones available for dropdown.' );
			wp_send_json_error(
				array(
					'message' => __( 'No zones available for dropdown.', 'mapfusion' ),
				),
				404
			);
		}

		// Return the list of zones as a JSON response.
		Debug::info( '[handle_fetch_zone] Zones for dropdown fetched successfully.', array( 'zones' => $zones ) );
		wp_send_json_success( array( 'zones' => $zones ) );
	}

	/**
	 * Handle AJAX request to save zone settings.
	 *
	 * Validates nonce, user permissions, and zone input before updating the database.
	 *
	 * @throws \Exception If database transaction fails.
	 */
	public static function handle_save_zone() {
		Debug::info( '[handle_save_zone] Initiating save zone process.' );

		// Validate nonce.
		$nonce = isset( $_POST['nonce'] ) ? wp_unslash( $_POST['nonce'] ) : '';
		if ( ! check_ajax_referer( 'mapfusion_nonce', 'nonce', false ) ) {
			Debug::error( '[handle_save_zone] Invalid nonce.' );
			wp_send_json_error(
				array(
					'message' => __( 'Invalid security token. Please reload the page.', 'mapfusion' ),
					'code'    => 'invalid_nonce',
				),
				403
			);
		}

		// Validate user permissions.
		if ( ! current_user_can( 'manage_options' ) ) {
			Debug::error( '[handle_save_zone] Unauthorized action attempted.' );
			wp_send_json_error(
				array(
					'message' => __( 'You do not have permission to perform this action.', 'mapfusion' ),
					'code'    => 'unauthorized_action',
				),
				403
			);
		}

		// Sanitize and validate zone input.
		$zone = isset( $_POST['zone'] ) ? sanitize_text_field( wp_unslash( $_POST['zone'] ) ) : '';
		$zone = strtolower( $zone ); // Standardize to lowercase.
		Debug::info( '[handle_save_zone] Zone submitted (standardized to lowercase): ' . esc_html( $zone ) );

		if ( empty( $zone ) || ! array_key_exists( $zone, MakeSettings::VALID_ZONES ) ) {
			Debug::error( '[handle_save_zone] Invalid or empty zone submitted: ' . esc_html( $zone ) );
			wp_send_json_error(
				array(
					'message' => __( 'Invalid or empty zone selected.', 'mapfusion' ),
					'code'    => 'invalid_zone',
				),
				400
			);
		}

		global $wpdb;
		$table_name = $wpdb->prefix . 'mapfusion_settings';
		$cache_key  = 'mapfusion_current_settings';

		try {
			// Retrieve current zone setting using the helper function.
			$current_zone = self::get_setting( $table_name, 'make_zone' );

			if ( $current_zone === $zone ) {
				Debug::info( '[handle_save_zone] Zone already set to: ' . esc_html( $zone ) );
				wp_send_json_success(
					array(
						'message' => __( 'Zone is already set.', 'mapfusion' ),
						'zone'    => $zone,
					)
				);
			}

			// Update zone setting using the helper function.
			$update_result = self::update_setting( $table_name, 'make_zone', $zone );
			if ( false === $update_result ) {
				throw new \Exception( __( 'Failed to save zone. Please try again.', 'mapfusion' ) );
			}

			// Clear cache.
			wp_cache_delete( $cache_key, 'mapfusion' );

			Debug::info( '[handle_save_zone] Zone successfully updated to: ' . esc_html( $zone ) );
			wp_send_json_success(
				array(
					'message' => __( 'Zone saved successfully.', 'mapfusion' ),
					'zone'    => $zone,
				)
			);
		} catch ( \Exception $e ) {
			Debug::error(
				'[handle_save_zone] Failed to update zone setting.',
				array( 'error_message' => $e->getMessage() )
			);

			wp_send_json_error(
				array(
					'message' => __( 'Failed to save zone. Please try again.', 'mapfusion' ),
					'code'    => 'database_error',
				),
				500
			);
		}
	}

	/**
	 * Handle Fetch Organizations.
	 *
	 * Fetches a list of organizations from the database or the Make API if force_update is true.
	 *
	 * @throws \Exception If an unexpected error occurs.
	 */
	public static function handle_fetch_organizations() {
		global $wpdb;

		// Validate nonce.
		if ( ! isset( $_POST['nonce'] ) || ! check_ajax_referer( 'mapfusion_nonce', 'nonce', false ) ) {
			Debug::error( '[handle_fetch_organizations] Invalid nonce provided.' );
			wp_send_json_error( array( 'message' => __( 'Invalid security token. Please reload the page.', 'mapfusion' ) ), 403 );
		}

		// Check user permissions.
		if ( ! current_user_can( 'manage_options' ) ) {
			Debug::error( '[handle_fetch_organizations] Unauthorized action attempted.', array( 'user_id' => get_current_user_id() ) );
			wp_send_json_error( array( 'message' => __( 'You do not have permission to perform this action.', 'mapfusion' ) ), 403 );
		}

		// Handle force update flag.
		$force_update = isset( $_POST['force_update'] ) ? filter_var( wp_unslash( $_POST['force_update'] ), FILTER_VALIDATE_BOOLEAN ) : false;

		// Define table name securely.
		$table_name = $wpdb->prefix . 'mapfusion_settings';
		$cache_key  = 'mapfusion_organization_list';

		// Return cached organizations if available and no force update.
		if ( ! $force_update ) {
			$cached_organizations = wp_cache_get( $cache_key, 'mapfusion' );
			if ( false !== $cached_organizations ) {
				Debug::info( '[handle_fetch_organizations] Returning cached organizations.' );
				wp_send_json_success( $cached_organizations );
			}

			// Retrieve organizations from the database.
			$organization_data = self::get_setting( $table_name, 'organization_dropdown' );
			if ( ! empty( $organization_data ) ) {
				// Retrieve current organization ID.
				$current_organization_id = self::get_setting( $table_name, 'make_organizationID' );
				$response_data           = array(
					'organizations'           => json_decode( $organization_data, true ),
					'current_organization_id' => $current_organization_id,
					'message'                 => __( 'Organizations retrieved from the database.', 'mapfusion' ),
				);

				wp_cache_set( $cache_key, $response_data, 'mapfusion', 3600 );
				wp_send_json_success( $response_data );
			}
		}

		// Fetch settings for API request.
		$make_zone  = self::get_setting( $table_name, 'make_zone' );
		$make_token = trim( self::get_setting( $table_name, 'make_token' ) );

		// Validate required settings.
		if ( empty( $make_zone ) || empty( $make_token ) ) {
			Debug::api( '[handle_fetch_organizations] Missing required settings.' );
			wp_send_json_error( array( 'message' => __( 'Missing required database values.', 'mapfusion' ) ), 400 );
		}

		// Validate zone and construct API URL.
		$base_url = MakeSettings::VALID_ZONES[ $make_zone ] ?? null;
		if ( ! $base_url ) {
			Debug::api( '[handle_fetch_organizations] Invalid zone value.', array( 'zone' => $make_zone ) );
			wp_send_json_error( array( 'message' => __( 'Invalid zone value.', 'mapfusion' ) ), 400 );
		}

		$api_url = trailingslashit( $base_url ) . 'api/v2/organizations';
		$headers = array( 'Authorization' => 'Token ' . sanitize_text_field( $make_token ) );

		Debug::api(
			'[handle_fetch_organizations] Sending API request.',
			array(
				'url'     => $api_url,
				'headers' => $headers,
			)
		);

		// Make API request.
		$response = wp_remote_get(
			$api_url,
			array(
				'headers' => $headers,
				'timeout' => 15,
			)
		);

		if ( is_wp_error( $response ) ) {
			Debug::api( '[handle_fetch_organizations] API request failed.', array( 'error_message' => $response->get_error_message() ) );
			// translators: %s represents the error message returned from the API request.
			wp_send_json_error( array( 'message' => sprintf( __( 'API request error: %s', 'mapfusion' ), $response->get_error_message() ) ), 500 );
		}

		// Parse and validate API response.
		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( empty( $data['organizations'] ) || ! is_array( $data['organizations'] ) ) {
			Debug::api( '[handle_fetch_organizations] Unexpected API response structure.', array( 'response' => $body ) );
			wp_send_json_error( array( 'message' => __( 'Unexpected API response structure.', 'mapfusion' ) ), 500 );
		}

		// Format organizations data.
		$formatted_organizations = array_map(
			function ( $org ) {
				return array(
					'name' => sanitize_text_field( $org['name'] ?? 'Unknown Name' ),
					'zone' => sanitize_text_field( str_replace( '.make.com', '', $org['zone'] ?? 'unknown' ) ),
					'id'   => sanitize_text_field( $org['id'] ?? '' ),
				);
			},
			$data['organizations']
		);

		Debug::api( '[handle_fetch_organizations] Processed organizations for database storage.', $formatted_organizations );

		// Store organizations in the database using our helper function.
		$update_result = self::update_setting( $table_name, 'organization_dropdown', wp_json_encode( $formatted_organizations ) );
		if ( false === $update_result ) {
			Debug::error( '[handle_fetch_organizations] Failed to update organization_dropdown setting.' );
			wp_send_json_error( array( 'message' => __( 'Failed to save organizations to the database.', 'mapfusion' ) ), 500 );
		}

		// Retrieve current organization ID.
		$current_organization_id = self::get_setting( $table_name, 'make_organizationID' );

		// Clear cache and store new data.
		wp_cache_delete( $cache_key, 'mapfusion' );
		$response_data = array(
			'organizations'           => $formatted_organizations,
			'current_organization_id' => $current_organization_id,
			'message'                 => __( 'Organizations retrieved from the API and saved to the database.', 'mapfusion' ),
		);
		wp_cache_set( $cache_key, $response_data, 'mapfusion', 3600 );

		Debug::api( '[handle_fetch_organizations] Organizations fetched and saved successfully.' );
		wp_send_json_success( $response_data );
	}

	/**
	 * Save Organization
	 *
	 * Saves the selected organization's name, zone, and ID to the database.
	 *
	 * @throws \Exception If saving the organization details fails.
	 */
	public static function handle_save_organization() {
		Debug::info( '[handle_save_organization] Initiating save organization process.' );

		// Validate nonce.
		if ( ! isset( $_POST['nonce'] ) || ! check_ajax_referer( 'mapfusion_nonce', 'nonce', false ) ) {
			Debug::error( '[handle_save_organization] Invalid nonce provided.' );
			wp_send_json_error(
				array(
					'message' => __( 'Invalid security token. Please reload the page.', 'mapfusion' ),
				),
				403
			);
		}

		// Check user permissions.
		if ( ! current_user_can( 'manage_options' ) ) {
			Debug::error(
				'[handle_save_organization] Unauthorized action attempted.',
				array( 'user_id' => get_current_user_id() )
			);
			wp_send_json_error(
				array(
					'message' => __( 'You do not have permission to perform this action.', 'mapfusion' ),
				),
				403
			);
		}

		// Sanitize and validate input.
		$organization_name = isset( $_POST['organization_name'] ) ? sanitize_text_field( wp_unslash( $_POST['organization_name'] ) ) : '';
		$organization_zone = isset( $_POST['organization_zone'] ) ? sanitize_text_field( wp_unslash( $_POST['organization_zone'] ) ) : '';
		$organization_id   = isset( $_POST['organization_id'] ) ? sanitize_text_field( wp_unslash( $_POST['organization_id'] ) ) : '';

		Debug::info(
			'[handle_save_organization] Organization details received from AJAX.',
			array(
				'organization_name' => $organization_name,
				'organization_zone' => $organization_zone,
				'organization_id'   => $organization_id,
			)
		);

		if ( empty( $organization_name ) || empty( $organization_zone ) || empty( $organization_id ) ) {
			Debug::error( '[handle_save_organization] Missing required organization details.' );
			wp_send_json_error(
				array(
					'message' => __( 'All organization details (name, zone, ID) are required.', 'mapfusion' ),
				),
				400
			);
		}

		global $wpdb;
		$table_name = $wpdb->prefix . 'mapfusion_settings';
		$cache_key  = 'mapfusion_current_settings';

		// Start transaction.
		$wpdb->query( 'START TRANSACTION' );

		try {
			// Saves organization name and zone as a plain text string instead of JSON
			$organization_text = $organization_name . ', ' . $organization_zone;

			// Save organization details using the helper function.
			$result_org = self::set_setting( $table_name, 'make_organization', $organization_text );
			$result_id  = self::set_setting( $table_name, 'make_organizationID', $organization_id );

			if ( false === $result_org || false === $result_id ) {
				throw new \Exception( __( 'Failed to save organization details.', 'mapfusion' ) );
			}

			// Clear cache after update.
			wp_cache_delete( $cache_key, 'mapfusion' );

			$wpdb->query( 'COMMIT' );

			Debug::info(
				'[handle_save_organization] Organization details saved successfully.',
				array(
					'organization_name' => $organization_name,
					'organization_zone' => $organization_zone,
					'organization_id'   => $organization_id,
				)
			);

			wp_send_json_success(
				array(
					'message'           => __( 'Organization saved successfully.', 'mapfusion' ),
					'organization_name' => $organization_name,
					'organization_zone' => $organization_zone,
					'organization_id'   => $organization_id,
				)
			);
		} catch ( \Exception $e ) {
			$wpdb->query( 'ROLLBACK' );

			Debug::error(
				'[handle_save_organization] Failed to save organization details.',
				array( 'error_message' => $e->getMessage() )
			);

			wp_send_json_error(
				array(
					'message' => __( 'Failed to save organization details. Please try again.', 'mapfusion' ),
				),
				500
			);
		}
	}

	/**
	 * Handle Fetch Teams
	 *
	 * Fetches a list of teams from the database or the Make API if force_update is true.
	 */
	public static function handle_fetch_teams() {
		global $wpdb;

		// Validate nonce.
		if ( ! isset( $_POST['nonce'] ) || ! check_ajax_referer( 'mapfusion_nonce', 'nonce', false ) ) {
			Debug::error( '[handle_fetch_teams] Invalid nonce provided.' );
			wp_send_json_error( array( 'message' => __( 'Invalid security token. Please reload the page.', 'mapfusion' ) ), 403 );
		}

		// Check user permissions.
		if ( ! current_user_can( 'manage_options' ) ) {
			Debug::error( '[handle_fetch_teams] Unauthorized action attempted.', array( 'user_id' => get_current_user_id() ) );
			wp_send_json_error( array( 'message' => __( 'You do not have permission to perform this action.', 'mapfusion' ) ), 403 );
		}

		// Handle force update flag.
		$force_update = isset( $_POST['force_update'] ) ? filter_var( wp_unslash( $_POST['force_update'] ), FILTER_VALIDATE_BOOLEAN ) : false;

		// Define cache key and table name.
		$cache_key  = 'mapfusion_team_list';
		$table_name = $wpdb->prefix . 'mapfusion_settings';

		// Return cached teams if available and no force update.
		if ( ! $force_update ) {
			$cached_teams = wp_cache_get( $cache_key, 'mapfusion' );
			if ( false !== $cached_teams ) {
				Debug::info( '[handle_fetch_teams] Returning cached teams.' );
				wp_send_json_success( $cached_teams );
			}

			// Retrieve teams from the database.
			$team_data = self::get_setting( $table_name, 'team_dropdown' );
			if ( ! empty( $team_data ) ) {
				// Retrieve current team ID.
				$current_team_id = self::get_setting( $table_name, 'make_teamID' );
				$response_data   = array(
					'teams'           => json_decode( $team_data, true ),
					'current_team_id' => $current_team_id,
					'message'         => __( 'Teams retrieved from the database.', 'mapfusion' ),
				);

				wp_cache_set( $cache_key, $response_data, 'mapfusion', 3600 );
				wp_send_json_success( $response_data );
			}
		}

		// Fetch settings for API request.
		$make_zone       = self::get_setting( $table_name, 'make_zone' );
		$make_token      = trim( self::get_setting( $table_name, 'make_token' ) );
		$organization_id = self::get_setting( $table_name, 'make_organizationID' );

		// Validate required settings.
		if ( empty( $make_zone ) || empty( $make_token ) || empty( $organization_id ) ) {
			Debug::api( '[handle_fetch_teams] Missing required settings.' );
			wp_send_json_error( array( 'message' => __( 'Missing required database values.', 'mapfusion' ) ), 400 );
		}

		// Validate zone and construct API URL.
		$base_url = MakeSettings::VALID_ZONES[ $make_zone ] ?? null;
		if ( ! $base_url ) {
			Debug::api( '[handle_fetch_teams] Invalid zone value.', array( 'zone' => $make_zone ) );
			wp_send_json_error( array( 'message' => __( 'Invalid zone value.', 'mapfusion' ) ), 400 );
		}

		$api_url = trailingslashit( $base_url ) . 'api/v2/teams?organizationId=' . rawurlencode( $organization_id );
		$headers = array( 'Authorization' => 'Token ' . sanitize_text_field( $make_token ) );

		Debug::api(
			'[handle_fetch_teams] Sending API request.',
			array(
				'url'     => $api_url,
				'headers' => $headers,
			)
		);

		// Make API request.
		$response = wp_remote_get(
			$api_url,
			array(
				'headers' => $headers,
				'timeout' => 15,
			)
		);

		if ( is_wp_error( $response ) ) {
			Debug::api(
				'[handle_fetch_teams] API request failed.',
				array( 'error_message' => $response->get_error_message() )
			);
			wp_send_json_error(
				array(
					// translators: %s represents the error message returned from the API request.
					'message' => sprintf( __( 'API request error: %s', 'mapfusion' ), $response->get_error_message() ),
				),
				500
			);
		}

		// Parse and validate API response.
		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( empty( $data['teams'] ) || ! is_array( $data['teams'] ) ) {
			Debug::api( '[handle_fetch_teams] Unexpected API response structure.', array( 'response' => $body ) );
			wp_send_json_error( array( 'message' => __( 'Unexpected API response structure.', 'mapfusion' ) ), 500 );
		}

		// Format teams data.
		$formatted_teams = array_map(
			function ( $team ) {
				return array(
					'name' => sanitize_text_field( $team['name'] ?? 'Unknown Name' ),
					'id'   => sanitize_text_field( $team['id'] ?? '' ),
				);
			},
			$data['teams']
		);

		Debug::api( '[handle_fetch_teams] Processed teams for database storage.', $formatted_teams );

		// Store teams in the database using the helper function.
		$update_result = self::update_setting( $table_name, 'team_dropdown', wp_json_encode( $formatted_teams ) );
		if ( false === $update_result ) {
			Debug::error( '[handle_fetch_teams] Failed to update team_dropdown setting.' );
			wp_send_json_error( array( 'message' => __( 'Failed to save teams to the database.', 'mapfusion' ) ), 500 );
		}

		// Retrieve current team ID.
		$current_team_id = self::get_setting( $table_name, 'make_teamID' );

		// Clear cache and store new data.
		wp_cache_delete( $cache_key, 'mapfusion' );
		$response_data = array(
			'teams'           => $formatted_teams,
			'current_team_id' => $current_team_id,
			'message'         => __( 'Teams retrieved from the API and saved to the database.', 'mapfusion' ),
		);
		wp_cache_set( $cache_key, $response_data, 'mapfusion', 3600 );

		Debug::api( '[handle_fetch_teams] Teams fetched and saved successfully.' );
		wp_send_json_success( $response_data );
	}

	/**
	 * Save Team
	 *
	 * Saves the selected team's name and ID to the database.
	 *
	 * @throws \Exception If saving the team details fails.
	 */
	public static function handle_save_team() {
		Debug::info( '[handle_save_team] Initiating save team process.' );

		// Validate and sanitize nonce.
		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
		if ( ! check_ajax_referer( 'mapfusion_nonce', 'nonce', false ) ) {
			Debug::error( '[handle_save_team] Invalid nonce provided.', array( 'nonce' => $nonce ) );
			wp_send_json_error(
				array(
					'message' => __( 'Invalid security token. Please reload the page.', 'mapfusion' ),
				)
			);
		}

		// Check user permissions.
		if ( ! current_user_can( 'manage_options' ) ) {
			Debug::error(
				'[handle_save_team] Unauthorized action attempted.',
				array(
					'user_id' => get_current_user_id(),
				)
			);
			wp_send_json_error(
				array(
					'message' => __( 'You do not have permission to perform this action.', 'mapfusion' ),
				)
			);
		}

		// Sanitize and validate input.
		$team_name = isset( $_POST['team_name'] ) ? sanitize_text_field( wp_unslash( $_POST['team_name'] ) ) : '';
		$team_id   = isset( $_POST['team_id'] ) ? sanitize_text_field( wp_unslash( $_POST['team_id'] ) ) : '';

		Debug::info(
			'[handle_save_team] Team details received from AJAX.',
			array(
				'team_name' => $team_name,
				'team_id'   => $team_id,
			)
		);

		if ( empty( $team_name ) || empty( $team_id ) ) {
			Debug::error( '[handle_save_team] Missing required team details.' );
			wp_send_json_error(
				array(
					'message' => __( 'Both team name and ID are required.', 'mapfusion' ),
				)
			);
		}

		global $wpdb;
		$table_name = $wpdb->prefix . 'mapfusion_settings';

		// Fetch current team ID using the helper function.
		$current_team_id = self::get_setting( $table_name, 'make_teamID' );

		// If the team is already set to the same value, return success early.
		if ( $current_team_id === $team_id ) {
			Debug::info( '[handle_save_team] Team is already set to the same ID.', array( 'team_id' => $team_id ) );
			wp_send_json_success(
				array(
					'message'   => __( 'Team is already set.', 'mapfusion' ),
					'team_name' => $team_name,
					'team_id'   => $team_id,
				)
			);
		}

		// Start transaction and update team details using our helper functions.
		$wpdb->query( 'START TRANSACTION' );

		try {
			// Saves as a plain text string instead of JSON (Team name + ID)
			$result_team   = self::set_setting( $table_name, 'make_team', $team_name . ', ' . $team_id );
			$result_teamid = self::set_setting( $table_name, 'make_teamID', $team_id );

			if ( false === $result_team || false === $result_teamid ) {
				throw new \Exception( __( 'Failed to save team details.', 'mapfusion' ) );
			}

			// Clear cache after update.
			wp_cache_delete( 'mapfusion_current_settings', 'mapfusion' );

			$wpdb->query( 'COMMIT' );

			Debug::info(
				'[handle_save_team] Team details saved successfully.',
				array(
					'team_name' => $team_name,
					'team_id'   => $team_id,
				)
			);

			wp_send_json_success(
				array(
					'message'   => __( 'Team saved successfully.', 'mapfusion' ),
					'team_name' => $team_name,
					'team_id'   => $team_id,
				)
			);
		} catch ( \Exception $e ) {
			$wpdb->query( 'ROLLBACK' );

			Debug::error(
				'[handle_save_team] Failed to save team details.',
				array( 'error_message' => $e->getMessage() )
			);

			wp_send_json_error(
				array(
					'message' => __( 'Failed to save team details. Please try again.', 'mapfusion' ),
				)
			);
		}
	}

	/**
	 * Handle Fetch Connections
	 *
	 * Fetches a list of connections from the database or the Make API if force_update is true.
	 *
	 * @throws \Exception If saving the connections to the database fails.
	 */
	public static function handle_fetch_connections() {
		global $wpdb;

		// Validate nonce.
		if ( ! isset( $_POST['nonce'] ) || ! check_ajax_referer( 'mapfusion_nonce', 'nonce', false ) ) {
			Debug::error( '[handle_fetch_connections] Invalid nonce provided.' );
			wp_send_json_error( array( 'message' => __( 'Invalid security token. Please reload the page.', 'mapfusion' ) ), 403 );
		}

		// Check user permissions.
		if ( ! current_user_can( 'manage_options' ) ) {
			Debug::error( '[handle_fetch_connections] Unauthorized action attempted.', array( 'user_id' => get_current_user_id() ) );
			wp_send_json_error( array( 'message' => __( 'You do not have permission to perform this action.', 'mapfusion' ) ), 403 );
		}

		// Handle force update flag.
		$force_update = isset( $_POST['force_update'] ) ? filter_var( wp_unslash( $_POST['force_update'] ), FILTER_VALIDATE_BOOLEAN ) : false;

		// Define cache key and table name.
		$cache_key  = 'mapfusion_connection_list';
		$table_name = $wpdb->prefix . 'mapfusion_settings';

		// Return cached connections if available and no force update.
		if ( ! $force_update ) {
			$cached_connections = wp_cache_get( $cache_key, 'mapfusion' );
			if ( false !== $cached_connections ) {
				Debug::info( '[handle_fetch_connections] Returning cached connections.' );
				wp_send_json_success( $cached_connections );
			}

			// Retrieve connections from the database.
			$connection_data = self::get_setting( $table_name, 'connection_dropdown' );
			if ( ! empty( $connection_data ) ) {
				// Retrieve current connection ID.
				$current_connection_id = self::get_setting( $table_name, 'make_connectionID' );
				$response_data         = array(
					'connections'           => json_decode( $connection_data, true ),
					'current_connection_id' => $current_connection_id,
					'message'               => __( 'Connections retrieved from the database.', 'mapfusion' ),
				);

				wp_cache_set( $cache_key, $response_data, 'mapfusion', 3600 );
				wp_send_json_success( $response_data );
			}
		}

		// Fetch settings for API request.
		$make_zone  = self::get_setting( $table_name, 'make_zone' );
		$make_token = trim( self::get_setting( $table_name, 'make_token' ) );
		$team_id    = self::get_setting( $table_name, 'make_teamID' );

		// Validate required settings.
		if ( empty( $make_zone ) || empty( $make_token ) || empty( $team_id ) ) {
			Debug::api( '[handle_fetch_connections] Missing required settings.' );
			wp_send_json_error( array( 'message' => __( 'Missing required database values.', 'mapfusion' ) ), 400 );
		}

		// Validate zone and construct API URL.
		$base_url = MakeSettings::VALID_ZONES[ $make_zone ] ?? null;
		if ( ! $base_url ) {
			Debug::api( '[handle_fetch_connections] Invalid zone value.', array( 'zone' => $make_zone ) );
			wp_send_json_error( array( 'message' => __( 'Invalid zone value.', 'mapfusion' ) ), 400 );
		}

		$api_url = trailingslashit( $base_url ) . 'api/v2/connections?teamId=' . rawurlencode( $team_id );
		$headers = array( 'Authorization' => 'Token ' . sanitize_text_field( $make_token ) );

		Debug::api(
			'[handle_fetch_connections] Sending API request.',
			array(
				'url'     => $api_url,
				'headers' => $headers,
			)
		);

		// Make the API request.
		$response = wp_remote_get(
			$api_url,
			array(
				'headers' => $headers,
				'timeout' => 15,
			)
		);

		if ( is_wp_error( $response ) ) {
			Debug::api(
				'[handle_fetch_connections] API request failed.',
				array( 'error_message' => $response->get_error_message() )
			);
			wp_send_json_error(
				array(
					// translators: %s represents the error message returned from the API request.
					'message' => sprintf( __( 'API request error: %s', 'mapfusion' ), $response->get_error_message() ),

				),
				500
			);
		}

		// Parse and validate API response.
		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( empty( $data['connections'] ) || ! is_array( $data['connections'] ) ) {
			Debug::api( '[handle_fetch_connections] Unexpected API response structure.', array( 'response' => $body ) );
			wp_send_json_error( array( 'message' => __( 'Unexpected API response structure.', 'mapfusion' ) ), 500 );
		}

		// Format connections data.
		$formatted_connections = array_map(
			function ( $connection ) {
				return array(
					'name' => sanitize_text_field( $connection['name'] ?? 'Unknown Name' ),
					'id'   => sanitize_text_field( $connection['id'] ?? '' ),
				);
			},
			$data['connections']
		);

		Debug::api( '[handle_fetch_connections] Processed connections for database storage.', $formatted_connections );

		// Store connections in the database using a transaction.
		$wpdb->query( 'START TRANSACTION' );
		try {
			$update_result = self::update_setting( $table_name, 'connection_dropdown', wp_json_encode( $formatted_connections ) );
			if ( false === $update_result ) {
				throw new \Exception( __( 'Failed to save connections to the database.', 'mapfusion' ) );
			}

			// Retrieve current connection ID.
			$current_connection_id = self::get_setting( $table_name, 'make_connectionID' );

			// Clear cache and store new data.
			wp_cache_delete( $cache_key, 'mapfusion' );
			$response_data = array(
				'connections'           => $formatted_connections,
				'current_connection_id' => $current_connection_id,
				'message'               => __( 'Connections retrieved from the API and saved to the database.', 'mapfusion' ),
			);
			wp_cache_set( $cache_key, $response_data, 'mapfusion', 3600 );

			$wpdb->query( 'COMMIT' );

			Debug::api( '[handle_fetch_connections] Connections fetched and saved successfully.' );
			wp_send_json_success( $response_data );
		} catch ( \Exception $e ) {
			$wpdb->query( 'ROLLBACK' );
			Debug::error(
				'[handle_fetch_connections] Failed to save connections in database.',
				array( 'error_message' => $e->getMessage() )
			);
			wp_send_json_error( array( 'message' => __( 'Failed to save connections. Please try again.', 'mapfusion' ) ), 500 );
		}
	}

	/**
	 * Save Connection
	 *
	 * Saves the selected connection's name and ID to the database.
	 *
	 * @throws \Exception If saving the connection details fails.
	 */
	public static function handle_save_connection() {
		Debug::info( '[handle_save_connection] Initiating save connection process.' );

		// Validate and sanitize nonce.
		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
		if ( ! check_ajax_referer( 'mapfusion_nonce', 'nonce', false ) ) {
			Debug::error( '[handle_save_connection] Invalid nonce provided.', array( 'nonce' => $nonce ) );
			wp_send_json_error(
				array(
					'message' => __( 'Invalid security token. Please reload the page.', 'mapfusion' ),
				)
			);
		}

		// Check user permissions.
		if ( ! current_user_can( 'manage_options' ) ) {
			Debug::error(
				'[handle_save_connection] Unauthorized action attempted.',
				array(
					'user_id' => get_current_user_id(),
				)
			);
			wp_send_json_error(
				array(
					'message' => __( 'You do not have permission to perform this action.', 'mapfusion' ),
				)
			);
		}

		// Sanitize and validate input.
		$connection_name = isset( $_POST['connection_name'] ) ? sanitize_text_field( wp_unslash( $_POST['connection_name'] ) ) : '';
		$connection_id   = isset( $_POST['connection_id'] ) ? sanitize_text_field( wp_unslash( $_POST['connection_id'] ) ) : '';

		Debug::info(
			'[handle_save_connection] Connection details received from AJAX.',
			array(
				'connection_name' => $connection_name,
				'connection_id'   => $connection_id,
			)
		);

		if ( empty( $connection_name ) || empty( $connection_id ) ) {
			Debug::error( '[handle_save_connection] Missing required connection details.' );
			wp_send_json_error(
				array(
					'message' => __( 'Both connection name and ID are required.', 'mapfusion' ),
				)
			);
		}

		global $wpdb;
		$table_name = $wpdb->prefix . 'mapfusion_settings';

		// Start transaction.
		$wpdb->query( 'START TRANSACTION' );

		try {
			// Saves as a plain text string instead of JSON
			$result_conn = self::set_setting(
				$table_name,
				'make_connection',
				$connection_name . ', ' . $connection_id
			);

			$result_connid = self::set_setting( $table_name, 'make_connectionID', $connection_id );

			if ( false === $result_conn || false === $result_connid ) {
				throw new \Exception( __( 'Failed to save connection details.', 'mapfusion' ) );
			}

			// Clear cache after update.
			wp_cache_delete( 'mapfusion_current_settings', 'mapfusion' );

			$wpdb->query( 'COMMIT' );

			Debug::info(
				'[handle_save_connection] Connection details saved successfully.',
				array(
					'connection_name' => $connection_name,
					'connection_id'   => $connection_id,
				)
			);

			wp_send_json_success(
				array(
					'message'         => __( 'Connection saved successfully.', 'mapfusion' ),
					'connection_name' => $connection_name,
					'connection_id'   => $connection_id,
				)
			);
		} catch ( \Exception $e ) {
			$wpdb->query( 'ROLLBACK' );

			Debug::error(
				'[handle_save_connection] Failed to save connection details.',
				array( 'error_message' => $e->getMessage() )
			);

			wp_send_json_error(
				array(
					'message' => __( 'Failed to save connection details. Please try again.', 'mapfusion' ),
				)
			);
		}
	}

	// =========================================
	// Make Connection Management
	// =========================================

	/**
	 * Handle Fetch Current Settings
	 *
	 * Fetches all the current settings (zone, organization, team, connection) from the database,
	 * including their respective IDs.
	 */
	public static function handle_fetch_current() {
		global $wpdb;

		$cache_key = 'mapfusion_current_settings';
		$settings  = wp_cache_get( $cache_key );

		if ( false === $settings ) {
			$table_name = $wpdb->prefix . 'mapfusion_settings';

			// Validate table name to prevent SQL injection.
			if ( ! preg_match( '/^[a-zA-Z0-9_]+$/', $table_name ) ) {
				Debug::critical( '[handle_fetch_current] Invalid table name detected.' );
				wp_send_json_error( array( 'message' => __( 'Invalid table name.', 'mapfusion' ) ) );
			}

			// Define the setting keys to fetch.
			$setting_keys = array(
				'make_zone',
				'make_organization',
				'make_organizationID',
				'make_team',
				'make_teamID',
				'make_connection',
				'make_connectionID',
			);

			// Prepare placeholders for the query.
			$placeholders = implode( ',', array_fill( 0, count( $setting_keys ), '%s' ) );

			// Construct and prepare the query safely.
			$query          = "SELECT setting_key, setting_value FROM `$table_name` WHERE setting_key IN ($placeholders)";
			$prepared_query = $wpdb->prepare( $query, ...$setting_keys );

			// Fetch results.
			$results = $wpdb->get_results( $prepared_query, ARRAY_A );

			// Process results into an associative array.
			$settings = array();
			foreach ( $results as $row ) {
				$settings[ $row['setting_key'] ] = $row['setting_value'];
			}

			// Cache the result for 1 hour.
			wp_cache_set( $cache_key, $settings, '', 3600 );
		}

		Debug::api( '[handle_fetch_current] Current settings fetched.', $settings );

		// Send response with all current settings.
		wp_send_json_success(
			array(
				'zone'            => $settings['make_zone'] ?? null,
				'organization'    => $settings['make_organization'] ?? null,
				'organization_id' => $settings['make_organizationID'] ?? null,
				'team'            => $settings['make_team'] ?? null,
				'team_id'         => $settings['make_teamID'] ?? null,
				'connection'      => $settings['make_connection'] ?? null,
				'connection_id'   => $settings['make_connectionID'] ?? null,
			)
		);
	}

	/**
	 * Handle Test Connection
	 *
	 * Tests the connection by sending an API request based on database values.
	 *
	 * @param bool $return_only If true, returns the result instead of sending a JSON response.
	 */
	public static function handle_test_connection( $return_only = false ) {
		global $wpdb;

		Debug::api( '[handle_test_connection] Starting connection test process.' );

		// Validate nonce.
		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
		if ( ! check_ajax_referer( 'mapfusion_nonce', 'nonce', false ) ) {
			Debug::api( '[handle_test_connection] Invalid nonce provided.', array( 'nonce' => $nonce ) );
			wp_send_json_error(
				array(
					'message' => __( 'Invalid security token. Please reload the page.', 'mapfusion' ),
				)
			);
		}

		// Check user permissions.
		if ( ! current_user_can( 'manage_options' ) ) {
			Debug::api(
				'[handle_test_connection] Unauthorized action attempted.',
				array(
					'user_id' => get_current_user_id(),
				)
			);
			wp_send_json_error(
				array(
					'message' => __( 'You do not have permission to perform this action.', 'mapfusion' ),
				)
			);
		}

		// Fetch required database values using caching.
		$cache_key   = 'mapfusion_connection_test';
		$cached_data = wp_cache_get( $cache_key, 'mapfusion' );
		if ( false === $cached_data ) {
			$table_name    = $wpdb->prefix . 'mapfusion_settings';
			$make_zone     = self::get_setting( $table_name, 'make_zone' );
			$make_token    = self::get_setting( $table_name, 'make_token' );
			$connection_id = self::get_setting( $table_name, 'make_connectionID' );

			$cached_data = compact( 'make_zone', 'make_token', 'connection_id' );
			wp_cache_set( $cache_key, $cached_data, 'mapfusion', 3600 );
		}

		$make_zone     = $cached_data['make_zone'] ?? null;
		$make_token    = $cached_data['make_token'] ?? null;
		$connection_id = $cached_data['connection_id'] ?? null;

		Debug::api(
			'[handle_test_connection] Retrieved database values.',
			array(
				'zone'          => $make_zone,
				'token'         => $make_token ? 'REDACTED' : 'EMPTY',
				'connection_id' => $connection_id,
			)
		);

		// Validate retrieved values.
		if ( empty( $make_zone ) || empty( $make_token ) || empty( $connection_id ) ) {
			Debug::api( '[handle_test_connection] Missing required database values.' );
			wp_send_json_error(
				array(
					'message' => __( 'Missing required database values (Zone, Token, or Connection ID).', 'mapfusion' ),
				)
			);
		}

		// Validate zone and construct API URL.
		$base_url = MakeSettings::VALID_ZONES[ $make_zone ] ?? null;
		if ( ! $base_url ) {
			Debug::api( '[handle_test_connection] Invalid zone value.', array( 'zone' => $make_zone ) );
			wp_send_json_error(
				array(
					'message' => __( 'Invalid zone value.', 'mapfusion' ),
				)
			);
		}

		$api_url = trailingslashit( $base_url ) . 'api/v2/connections/' . rawurlencode( $connection_id ) . '/test';
		$headers = array( 'Authorization' => 'Token ' . sanitize_text_field( $make_token ) );

		Debug::api(
			'[handle_test_connection] Prepared API request.',
			array(
				'url'     => $api_url,
				'headers' => $headers,
			)
		);

		// Make the API request.
		$response = wp_remote_post( $api_url, array( 'headers' => $headers ) );
		if ( is_wp_error( $response ) ) {
			Debug::api(
				'[handle_test_connection] API request failed.',
				array(
					'error_message' => $response->get_error_message(),
				)
			);
			wp_send_json_error(
				array(
					// translators: %s is the API error message.
					'message'    => sprintf( __( 'API request failed: %s', 'mapfusion' ), $response->get_error_message() ),
					'status'     => 500,
					'statusText' => 'Failed',
				)
			);
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( empty( $data['verified'] ) || ! $data['verified'] ) {
			Debug::api(
				'[handle_test_connection] API response indicates failure.',
				array(
					'response_body' => $body,
				)
			);
			wp_send_json_error(
				array(
					'message'    => $data['message'] ?? __( 'Connection test failed.', 'mapfusion' ),
					'detail'     => $data['detail'] ?? 'No additional details available.',
					'code'       => $data['code'] ?? 'Unknown error code',
					'status'     => wp_remote_retrieve_response_code( $response ),
					'statusText' => 'Error',
				)
			);
		}

		Debug::api(
			'[handle_test_connection] Connection test successful.',
			array(
				'connection_id'   => $data['connection']['id'] ?? 'Unknown ID',
				'connection_name' => $data['connection']['name'] ?? 'Unknown Name',
				'response'        => $data,
			)
		);

		$result = array(
			'message'    => __( 'Connection test successful.', 'mapfusion' ),
			'status'     => wp_remote_retrieve_response_code( $response ),
			'verified'   => $data['verified'] ?? false,
			'connection' => $data['connection'] ?? null,
			'statusText' => $data['verified'] ? 'Active' : 'Inactive',
		);

		if ( $return_only ) {
			return $result;
		}
		wp_send_json_success( $result );
	}

	// =========================================
	// Database Management
	// =========================================

	/**
	 * Handle exporting the database via AJAX.
	 */
	public static function export_database() {
		Debug::info( '[export_database] Exporting database started.' );

		// Validate nonce.
		check_ajax_referer( 'mapfusion_nonce', 'nonce' );

		global $wpdb;
		$table_name = $wpdb->prefix . 'mapfusion_settings';
		$cache_key  = 'mapfusion_settings_export';

		// Check if cached data exists.
		$results = wp_cache_get( $cache_key, 'mapfusion' );
		if ( false === $results ) {
			$query   = "SELECT * FROM `$table_name`";
			$results = $wpdb->get_results( $query, ARRAY_A );

			if ( null === $results ) {
				Debug::error( '[export_database] Failed to fetch database records.' );
				wp_send_json_error( array( 'message' => __( 'Failed to fetch database records.', 'mapfusion' ) ) );
			}

			if ( empty( $results ) ) {
				Debug::warning( '[export_database] No records found in the database.' );
				wp_send_json_error( array( 'message' => __( 'No records found in the database.', 'mapfusion' ) ) );
			}

			// Cache results for better performance.
			wp_cache_set( $cache_key, $results, 'mapfusion', 3600 );
		}

		Debug::info( '[export_database] Database exported successfully.' );
		wp_send_json_success( $results );
	}

	/**
	 * Handle importing the database via AJAX.
	 *
	 * @throws \Exception If the database import fails.
	 */
	public static function import_database() {
		Debug::info( '[import_database] Importing database started.' );

		// Verify security nonce.
		check_ajax_referer( 'mapfusion_nonce', 'nonce' );

		// Unslash and decode JSON data.
		$data = isset( $_POST['data'] ) ? json_decode( wp_unslash( $_POST['data'] ), true ) : null;
		if ( ! $data || ! is_array( $data ) ) {
			Debug::error( '[import_database] Invalid data format received.' );
			wp_send_json_error( array( 'message' => __( 'Invalid data format.', 'mapfusion' ) ) );
		}

		global $wpdb;
		$table_name = $wpdb->prefix . 'mapfusion_settings';

		// Ensure the table name is safe.
		if ( ! preg_match( '/^[a-zA-Z0-9_]+$/', $table_name ) ) {
			Debug::critical( '[import_database] Invalid table name detected.' );
			wp_send_json_error( array( 'message' => __( 'Invalid table name.', 'mapfusion' ) ) );
		}

		// Start transaction.
		$wpdb->query( 'START TRANSACTION' );

		try {
			Debug::info( '[import_database] Truncating existing table.' );
			// Since $table_name is validated, we can safely use it in the query.
			$truncate_result = $wpdb->query( "TRUNCATE TABLE `$table_name`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			if ( false === $truncate_result ) {
				throw new \Exception( 'Failed to truncate table: ' . $wpdb->last_error );
			}

			foreach ( $data as $row ) {
				// Validate and sanitize input fields.
				if ( ! isset( $row['setting_key'], $row['setting_value'], $row['updated_at'] ) ) {
					throw new \Exception( 'Invalid row format: ' . wp_json_encode( $row ) );
				}

				$setting_key   = sanitize_text_field( $row['setting_key'] );
				$setting_value = sanitize_text_field( $row['setting_value'] );
				$updated_at    = sanitize_text_field( $row['updated_at'] );

				$query = $wpdb->prepare(
					"INSERT INTO `$table_name` (`setting_key`, `setting_value`, `updated_at`) VALUES (%s, %s, %s)", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
					$setting_key,
					$setting_value,
					$updated_at
				);

				$result = $wpdb->query( $query );
				if ( false === $result ) {
					throw new \Exception( 'Failed to insert row: ' . $wpdb->last_error );
				}
			}

			// Clear cache to ensure fresh data.
			wp_cache_delete( 'mapfusion_settings_cache', 'mapfusion' );

			$wpdb->query( 'COMMIT' );
			Debug::info( '[import_database] Database imported successfully.' );
			wp_send_json_success( array( 'message' => __( 'Database imported successfully.', 'mapfusion' ) ) );
		} catch ( \Exception $e ) {
			$wpdb->query( 'ROLLBACK' );
			Debug::critical( '[import_database] Import failed.', array( 'error' => $e->getMessage() ) );
			wp_send_json_error( array( 'message' => __( 'Failed to import database.', 'mapfusion' ) ) );
		}
	}

	/**
	 * Handle clearing the database via AJAX.
	 */
	public static function clear_database() {
		Debug::info( '[clear_database] Clearing database started.' );

		// Verify the nonce for security.
		check_ajax_referer( 'mapfusion_nonce', 'nonce' );

		global $wpdb;
		$table_name = $wpdb->prefix . 'mapfusion_settings';

		// Validate table name to prevent SQL injection.
		if ( ! preg_match( '/^[a-zA-Z0-9_]+$/', $table_name ) ) {
			Debug::critical( '[clear_database] Invalid table name detected: ' . $table_name );
			wp_send_json_error( array( 'message' => __( 'Invalid table name. Operation aborted.', 'mapfusion' ) ) );
			return;
		}

		// Perform the TRUNCATE operation.
		$result = $wpdb->query( "TRUNCATE TABLE `$table_name`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		if ( false === $result ) {
			Debug::error( '[clear_database] Failed to clear database.', array( 'error' => $wpdb->last_error ) );
			wp_send_json_error( array( 'message' => __( 'Failed to clear database.', 'mapfusion' ) ) );
		}

		Debug::info( '[clear_database] Database cleared successfully.' );
		wp_send_json_success( array( 'message' => __( 'Database cleared successfully.', 'mapfusion' ) ) );
	}
}
// Initialize the class hooks.
Ajax::init();
