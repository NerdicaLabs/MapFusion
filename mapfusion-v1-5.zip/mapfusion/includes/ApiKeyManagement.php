<?php
/**
 * API Key Management for MapFusion.
 *
 * This file defines the `ApiKeyManagement` class, responsible for
 * handling API key validation, renewal, and security checks within MapFusion.
 *
 * @package MapFusion
 */

namespace MapFusion;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly. //
}

/**
 * Handles API key management logic for MapFusion.
 *
 * This class is responsible for generating, validating, and
 * renewing API keys, ensuring secure API access for users.
 */
class ApiKeyManagement {


	/**
	 * Retrieve the API URL for the current zone.
	 *
	 * @return string API base URL.
	 */
	public static function get_api_url() {
		global $wpdb;
		$table_name = $wpdb->prefix . 'mapfusion_settings';

		try {
			// Generate a cache key for the zone URL. //
			$cache_key = 'mapfusion_zone_url';
			$zone_url  = wp_cache_get( $cache_key, 'mapfusion' );

			if ( false === $zone_url ) {
				global $wpdb;

				// Fetch the zone URL from the database. //
				$zone_url = $wpdb->get_var(
					$wpdb->prepare(
						'SELECT setting_value FROM ' . $wpdb->prefix . 'mapfusion_settings WHERE setting_key = %s',
						'mapfusion_zone'
					)
				);

				// Store the result in cache (e.g., 10-minute expiration). //
				if ( null !== $zone_url ) {
					wp_cache_set( 'mapfusion_zone_url', $zone_url, 'mapfusion', 600 );
				}
			}

			if ( ! $zone_url ) {
				// Fallback to the default zone if no value is found. //
				$zone_url = \MapFusion\MakeSettings::VALID_ZONES['EU1'];
				Debug::warning( '[get_api_url] Zone URL not found in database, using default: ' . $zone_url );
			} else {
				Debug::info( '[get_api_url] Zone URL fetched from database: ' . $zone_url );
			}

			return rtrim( $zone_url, '/' ) . '/api/v2/connections';
		} catch ( \Exception $e ) {
			// Log the error and use the default zone URL. //
			$fallback_zone = \MapFusion\MakeSettings::VALID_ZONES['EU1'];
			Debug::critical(
				'[get_api_url] Database error occurred. Falling back to default zone URL.',
				array(
					'error'         => $e->getMessage(),
					'fallback_zone' => $fallback_zone,
				)
			);
			return rtrim( $fallback_zone, '/' ) . '/api/v2/connections';
		}
	}
}
