<?php // phpcs:ignore WordPress.Files.FileName.InvalidClassFileName

/*
 * Plugin Name: MapFusion
 * Plugin URI: https://www.mapfusion.site/
 * Description: Advanced mapping plugin for WordPress, providing customizable maps and seamless integration.
 * Version: 1.5.0
 * Author: NerdicaLabs
 * Author URI: https://www.nerdicalabs.site
 * Contributors: charlienerdica, Frank
 * Text Domain: mapfusion
 * Tags: maps, markers, integration
 * Requires at least: 5.8
 * Tested up to: 6.7
 * Requires PHP: 7.4
 * License: GPLv3 or later
 * License URI: https://www.gnu.org/licenses/gpl-3.0.html
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

define( 'MAPFUSION_VERSION', '1.5.0' );
define( 'MAPFUSION_IS_BETA', false );

// Autoload dependencies.
try {
	$autoload_path = __DIR__ . '/vendor/autoload.php';

	if ( ! file_exists( $autoload_path ) ) {
		throw new \Exception( "Autoload file not found at path: {$autoload_path}" );
	}

	require_once $autoload_path;
	MapFusion\Debug::initializing( 'Autoload file included successfully.', array( 'path' => $autoload_path ) );
} catch ( \Exception $e ) {
	MapFusion\Debug::critical(
		'Failed to load autoload file.',
		array(
			'error' => $e->getMessage(),
			'trace' => $e->getTraceAsString(),
		)
	);
}


// Include critical classes.
$critical_classes = array(
	'MapFusion\Admin_Scripts'         => '/includes/Admin_Scripts.php',
	'MapFusion\Ajax'                  => '/includes/Ajax.php',
	'MapFusion\ApiKeyManagement'      => '/includes/ApiKeyManagement.php',
	'MapFusion\Database'              => '/includes/Database.php',
	'MapFusion\Debug'                 => '/includes/Debug.php',
	'MapFusion\MakeSettings'          => '/includes/MakeSettings.php',
	'MapFusion\Privacy_Policy_Notice' => '/includes/Privacy_Policy_Notice.php',
	'MapFusion\Render'                => '/includes/Render.php',
	'MapFusion\Rest_API'              => '/includes/Rest_API.php',
	'MapFusion\Settings'              => '/includes/Settings.php',
	'MapFusion\WPGM_Integration'      => '/includes/WPGM_Integration.php',
);

foreach ( $critical_classes as $class => $class_path ) {
	if ( ! class_exists( $class ) ) {
		$file = __DIR__ . $class_path;
		if ( file_exists( $file ) ) {
			require_once $file;
			if ( class_exists( $class ) ) {
				MapFusion\Debug::info( "Class {$class} loaded." );
			} elseif ( WP_DEBUG ) {
				// Use WordPress's logging system if debugging is enabled.
				wp_debug_log( "Failed to load class {$class}." );
			}
		} elseif ( WP_DEBUG ) {
			// Log missing file only when debugging is enabled.
			wp_debug_log( "File not found for class {$class}: {$class_path}" );
		}
	}
}


/**
 * Main class for the MapFusion plugin.
 */
class MapFusion {

	/**
	 * Constructor.
	 */
	public function __construct() {
		MapFusion\Debug::initializing( 'Constructor called.' );
		$this->initialize_hooks();
	}

	/**
	 * Initialize WordPress hooks.
	 */
	private function initialize_hooks() {
		MapFusion\Debug::initializing( 'Initializing hooks.' );
		add_action( 'plugins_loaded', array( 'MapFusion\Settings', 'init' ) );
		add_action( 'plugins_loaded', array( 'MapFusion\Admin_Scripts', 'init' ) );
		add_action( 'rest_api_init', array( $this, 'initialize_rest_api' ) );
		add_action( 'admin_init', array( $this, 'check_wp_go_maps_pro' ) );
	}

	/**
	 * Check if WP Go Maps Pro Add-on is installed and active.
	 */
	public function check_wp_go_maps_pro() {
		MapFusion\Debug::initializing( 'Checking WP Go Maps Pro.' );
		if ( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		if ( ! is_plugin_active( 'wp-google-maps-pro/wp-google-maps-pro.php' ) ) {
			MapFusion\Debug::warning( 'WP Go Maps Pro is not active.' );
			add_action(
				'admin_notices',
				function () {
					printf(
						'<div class="notice notice-error"><p>%s</p></div>',
						sprintf(
						// translators: %s is the URL to install and activate WP Go Maps - Pro Add-on.
							wp_kses_post( __( 'MapFusion requires WP Go Maps - Pro Add-on to function properly. Please <a href="%s" target="_blank">install and activate the plugin</a>.', 'mapfusion' ) ),
							esc_url( 'https://www.wpgmaps.com' )
						)
					);
				}
			);
		} else {
			MapFusion\Debug::initializing( 'WP Go Maps Pro is active.' );
		}
	}

	/**
	 * Initialize REST API.
	 */
	public function initialize_rest_api() {
		MapFusion\Debug::initializing( 'Initializing REST API.' );
		if ( class_exists( 'MapFusion\Rest_API' ) ) {
			MapFusion\Rest_API::load_api_classes();
			MapFusion\Debug::initializing( 'REST API initialized.' );
		} else {
			MapFusion\Debug::error( 'Rest_API class not found.' );
		}
	}
}

// Register activation hook.
register_activation_hook(
	__FILE__,
	function () {
		MapFusion\Debug::initializing( 'Plugin activation started.' );

		try {
			// Generate API key.
			if ( ! get_option( 'mapfusion_api_key' ) ) {
				update_option( 'mapfusion_api_key', wp_generate_password( 40, false, false ) );
				MapFusion\Debug::initializing( 'API key generated.' );
			}

			// Create database table.
			if ( class_exists( 'MapFusion\Database' ) ) {
				MapFusion\Database::create_database_table();
				MapFusion\Debug::initializing( 'Database table creation triggered.' );
			} else {
				MapFusion\Debug::error( 'Database class not found.' );
			}

			// Create Export and Import directories.
			if ( class_exists( 'MapFusion\Rest_API' ) ) {
				MapFusion\Rest_API::create_export_import_directories();
				MapFusion\Debug::info( 'Create Export and Import directories triggered.' );
			} else {
				MapFusion\Debug::error( 'Rest_API class not found.' );
			}
		} catch ( Exception $e ) {
			MapFusion\Debug::error( 'Error during activation: ' . $e->getMessage() );
		}
	}
);

// Initialize the plugin.
MapFusion\Debug::initializing( 'Plugin initialization started.' );
new MapFusion();
