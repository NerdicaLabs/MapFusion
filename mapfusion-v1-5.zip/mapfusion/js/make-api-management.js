// File: make-api-management.js

/**
 * MapFusion Make API Management
 * Handles all functionality related to Make API Key, connection status,
 * test connection, fetch connection ID, and related interactions.
 */

document.addEventListener('DOMContentLoaded', function () {
    console.log("[MapFusion] make-api-management.js has loaded.");

    // ====================
    // === DOM Elements ===
    // ====================

    const elements = {
        // === Token Management ===
        makeTokenInput: document.getElementById('make-token-input'),
        saveTokenButton: document.getElementById('make-save-token'),
        clearTokenButton: document.getElementById('make-clear-token'),
        deleteTokenButton: document.getElementById('make-delete-token'),
        getNewTokenButton: document.getElementById('make-get-new-token'),
        testTokenButton: document.getElementById('make-test-token'),

        // === Settings Management ===
        zoneDropdown: document.getElementById('make-zone-dropdown'),
        organizationDropdown: document.getElementById('make-organization-dropdown'),
        fetchOrganizationsButton: document.getElementById('make-fetch-organization'),
        teamDropdown: document.getElementById('make-team-dropdown'),
        fetchTeamsButton: document.getElementById('make-fetch-teams'),
        connectionDropdown: document.getElementById('make-connection-dropdown'),
        fetchConnectionsButton: document.getElementById('make-fetch-connections'),

        // === Connection Management ===
        currentZone: document.getElementById('make-current-zone'),
        currentOrganization: document.getElementById('make-current-organization'),
        currentTeam: document.getElementById('make-current-team'),
        currentConnection: document.getElementById('make-current-connection'),
        connectionAPIButton: document.getElementById('make-test-connection'),
        connectionAPIResult: document.getElementById('make-api-result'),
        connectionAPIStatus: document.getElementById('make-api-status'),

        // === Message Management ===
        tokenMessages: document.getElementById('make-token-messages'),
        tokenLoadingMessage: document.getElementById('make-token-loading-message'),
        tokenSuccessMessage: document.getElementById('make-token-success-message'),
        tokenErrorMessage: document.getElementById('make-token-error-message'),
        settingsMessages: document.getElementById('make-settings-messages'),
        settingsLoadingMessage: document.getElementById('make-settings-loading-message'),
        settingsSuccessMessage: document.getElementById('make-settings-success-message'),
        settingsErrorMessage: document.getElementById('make-settings-error-message'),
        connectionMessages: document.getElementById('make-connection-messages'),
        connectionLoadingMessage: document.getElementById('make-connection-loading-message'),
        connectionSuccessMessage: document.getElementById('make-connection-success-message'),
        connectionErrorMessage: document.getElementById('make-connection-error-message'),
    };

    // Validate localized settings
    if (typeof mapfusion_make_settings === 'undefined') {
        console.error("[MapFusion] mapfusion_make_settings is not defined. Check wp_localize_script in PHP.");
        return;
    }

    // =======================
    // === State Variables ===
    // =======================

    // Tracks whether a process is currently active to prevent duplicate actions
    let isProcessing = false; // Generic flag for ongoing processes
    let isSaving = false;     // Specific flag for save operations
    let isUserInteracting = false; // Tracks whether the user is interacting with the dropdown
    let currentZone = null; // Tracks the currently active zone
    let currentOrganization = ''; // Tracks the currently active organization
    let currentTeam = ''; // Tracks the currently active team
    let currentConnection = ''; // Tracks the currently active connection
    let currentOrganizationID = ''; // Tracks the currently active organizationID
    let currentTeamID = ''; // Tracks the currently active teamID
    let currentConnectionID = ''; // Tracks the currently active connectionID

    // =========================
    // === Utility Functions ===
    // =========================

    /**
     * Log Messages to Developer Console
     *
     * Logs messages to the developer console with consistent formatting, contextual information,
     * and function-specific details to aid in debugging and tracing application behavior.
     *
     * @param {string} level - The log level: 'log', 'info', 'warn', 'error', 'debug'.
     * @param {string} message - The message to log.
     * @param {object|null} context - Additional context to log (optional).
     * @param {string} functionName - The name of the function generating the log.
     */
    function logToDevTools(level, message, context = null, functionName = '') {
        const validLevels = ['log', 'info', 'warn', 'error', 'debug']; // Added 'debug'
        if (!validLevels.includes(level)) {
            console.error(`[MapFusion ERROR] Invalid log level: ${level}`);
            return;
        }

        const formattedMessage = `[MapFusion ${level.toUpperCase()}${functionName ? ' - ' + functionName : ''}] ${message}`;
        if (context) {
            console[level](formattedMessage, context);
        } else {
            console[level](formattedMessage);
        }
    }

    /**
    * Display Message in DOM Element
    *
    * Displays a message in the specified DOM element, allowing for error
    * or success styling based on the message type.
    *
    * @param {HTMLElement} element - The target DOM element.
    * @param {string} message - The message to display.
    * @param {boolean} [isError=false] - Whether the message indicates an error.
    */
    function showMessage(element, message, isError = false) {
        if (element && element instanceof HTMLElement) {
            element.textContent = message;
            element.style.color = isError ? 'red' : 'green';
            element.style.display = 'block';
        } else {
            logToDevTools('warn', 'Target element not found or invalid for showMessage.');
        }
    }

    /**
     * Hide Message in DOM Element
     *
     * Hides the message displayed in the specified DOM element by clearing its content
     * and adjusting its visibility.
     *
     * @param {HTMLElement} element - The target DOM element.
     */
    function hideMessage(element) {
        if (element) {
            element.style.display = 'none';
        } else {
            logToDevTools('warn', 'Target element not found for hideMessage.');
        }
    }

    /**
     * Display Error Message
     *
     * Displays the provided error message in the global error container
     * to notify the user of an issue.
     *
     * @param {string} message - The error message to display.
     */
    function displayErrorMessage(message) {
        if (elements.errorMessage) {
            showMessage(elements.errorMessage, message, true); // Reuse showMessage for error
        } else {
            logToDevTools('warn', 'Error message container not found for displayErrorMessage.');
        }
    }

    /**
     * Hide Global Error Message
     *
     * Clears and hides the global error message container to remove
     * any displayed error notifications.
     */
    function hideErrorMessage() {
        if (elements.errorMessage) {
            hideMessage(elements.errorMessage); // Reuse hideMessage
        } else {
            logToDevTools('warn', 'Error message container not found for hideErrorMessage.');
        }
    }

    /**
     * Toggle Loading Indicator for Button
     *
     * Toggles the visibility of the loading indicator for a specific button.
     * Provides a way to visually indicate ongoing operations tied to the button.
     *
     * @param {string} buttonId - The ID of the button to toggle the loading indicator for.
     * @param {boolean} [state=true] - Whether to show or hide the loading indicator.
     */
    function toggleButtonLoading(buttonId, state = true) {
        const button = document.getElementById(buttonId);
        if (button) {
            if (state) {
                button.classList.add('loading'); // Show the spin
                button.style.pointerEvents = 'none'; // Disable clicks
            } else {
                button.classList.remove('loading'); // Remove the spinner
                button.style.pointerEvents = ''; // Reactivate clicks
            }
        } else {
            console.warn(`[MapFusion] Button with ID "${buttonId}" not found.`);
        }
    }

    // ========================
    // === Token Management ===
    // ========================

    /**
     * Update Save Token Button State
     *
     * Dynamically updates the state of the Save Token button based on the token input value.
     * Disables the button if the token input is empty, and enables it otherwise.
     */
    function updateSaveTokenButtonState() {
        if (!elements.makeTokenInput || !elements.saveTokenButton) {
            logToDevTools('warn', 'Token input field or Save Token button not found.', null, 'updateSaveTokenButtonState');
            return;
        }

        const tokenValue = elements.makeTokenInput.value.trim(); // Get the trimmed token value
        const isDisabled = !tokenValue; // Determine if the button should be disabled

        elements.saveTokenButton.disabled = isDisabled; // Update the button's disabled state

        logToDevTools(
            'info',
            'Save Token button state updated.',
            { isDisabled, tokenValue },
            'updateSaveTokenButtonState'
        );
    }

    /**
     * Fetch and Update Token Field
     *
     * Fetches the current token from the server via an API request and dynamically
     * updates the token input field. Ensures validation, feedback, and proper state management.
     */
    async function makeTokenInput() {
        logToDevTools('info', 'Starting token fetch process.', null, 'makeTokenInput');

        try {
            // Show loading message
            showMessage(elements.tokenLoadingMessage, 'Fetching token...', false);

            // Log AJAX URL and action details
            logToDevTools('debug', 'Fetching token from: ' + mapfusion_make_settings.ajax_url, null, 'makeTokenInput');
            logToDevTools('debug', 'Action: mapfusion_get_token, Nonce: ' + mapfusion_make_settings.nonce, null, 'makeTokenInput');

            const response = await fetch(mapfusion_make_settings.ajax_url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'mapfusion_get_token',
                    nonce: mapfusion_make_settings.nonce,
                }),
            });

            // Log HTTP status and response details
            logToDevTools('debug', 'HTTP status: ' + response.status, null, 'makeTokenInput');

            if (!response.ok) {
                logToDevTools('error', 'HTTP error while fetching token. Status: ' + response.status, null, 'makeTokenInput');
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            const result = await response.json();

            // Log the full API response for debugging
            logToDevTools('debug', 'API response received: ' + JSON.stringify(result), null, 'makeTokenInput');

            if (result.success && result.data && result.data.token) {
                const fetchedToken = result.data.token; // Correctly extract the token
                logToDevTools('info', 'Token fetched successfully: ' + fetchedToken, null, 'makeTokenInput');

                // Dynamically update the token input field
                if (fetchedToken && elements.makeTokenInput) {
                    logToDevTools('debug', 'Updating token input field with token: ' + fetchedToken, null, 'makeTokenInput');
                    elements.makeTokenInput.value = fetchedToken;

                    // Show success message
                    showMessage(elements.tokenSuccessMessage, 'Token fetched successfully!', false);
                } else {
                    logToDevTools('warn', 'Fetched token is empty or token input field not found.', null, 'makeTokenInput');
                    showMessage(elements.tokenErrorMessage, 'Failed to update token input field.', true);
                }
            } else {
                // Log API failure message
                const apiMessage = result.message || 'Unknown error';
                logToDevTools('error', 'API responded with failure or missing data: ' + apiMessage, null, 'makeTokenInput');
                showMessage(elements.tokenErrorMessage, `Error: ${apiMessage}`, true);
            }
        } catch (error) {
            // Log details of the error
            logToDevTools('error', 'Error fetching token: ' + error.message, null, 'makeTokenInput');
            showMessage(elements.tokenErrorMessage, `❌ Error fetching token: ${error.message}`, true);
        } finally {
            // Hide loading message and update Save Token button state
            hideMessage(elements.tokenLoadingMessage);
            updateSaveTokenButtonState();

            // Log indicating the end of the process
            logToDevTools('info', 'Finished token fetch process.', null, 'makeTokenInput');
        }
    }

    /**
     * Save Make Token
     *
     * Sends the token entered by the user to the server for validation and storage.
     * Provides feedback and ensures proper state management throughout the process.
     */
    async function saveToken() {
        const token = elements.makeTokenInput.value.trim();

        // Check if a saving operation is already in progress
        if (isSaving) {
            logToDevTools('warn', 'Save operation already in progress.', null, 'saveToken');
            return;
        }

        if (!token) {
            logToDevTools('warn', 'No token provided by the user.', null, 'saveToken');
            showMessage(elements.tokenErrorMessage, '❌ Please enter a valid token.', true);
            updateSaveTokenButtonState(); // Ensure button reflects the empty field
            return;
        }

        logToDevTools('info', 'Attempting to save token.', { token }, 'saveToken');
        toggleButtonLoading('make-save-token', true);
        hideMessage(elements.tokenErrorMessage); // Hide token-specific errorMessage
        hideMessage(elements.tokenSuccessMessage); // Hide previous success messages

        isSaving = true; // Indicate that saving is in progress

        try {
            const response = await fetch(mapfusion_make_settings.ajax_url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'mapfusion_save_make_token',
                    nonce: mapfusion_make_settings.nonce,
                    token: token,
                }),
            });

            logToDevTools('info', 'AJAX request sent.', { url: mapfusion_make_settings.ajax_url }, 'saveToken');

            if (!response.ok) {
                logToDevTools('error', `HTTP error with status: ${response.status}`, null, 'saveToken');
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            const result = await response.json();
            logToDevTools('info', 'Response received from server.', { result }, 'saveToken');

            if (result && result.success) {
                showMessage(elements.tokenSuccessMessage, '✔ Token saved successfully!', false);
                logToDevTools('info', 'Token saved successfully.', { token }, 'saveToken');
            } else {
                const errorMessage = result.message || 'Unknown error occurred while saving the token.';
                logToDevTools('error', 'Unexpected response structure.', { result }, 'saveToken');
                throw new Error(errorMessage);
            }
        } catch (error) {
            logToDevTools('error', 'Network error occurred while saving token.', { error: error.message }, 'saveToken');
            showMessage(elements.tokenErrorMessage, `❌ Error: ${error.message}`, true);
        } finally {
            logToDevTools('info', 'Finished saveToken process.', null, 'saveToken');
            toggleButtonLoading('make-save-token', false); // Remove the spinner
            updateSaveTokenButtonState(); // Update button state based on current input
            isSaving = false; // Reset save status
        }
    }

    /**
     * Clear Saved Token
     *
     * Sends a request to remove the saved token from the database and updates
     * the user interface accordingly. Ensures proper feedback and state management.
     */
    async function clearToken() {
        logToDevTools('info', 'Clearing saved token.', null, 'clearToken');

        toggleButtonLoading('make-clear-token', true);
        hideMessage(elements.tokenErrorMessage); // Use token-specific error message
        hideMessage(elements.tokenSuccessMessage); // Use token-specific success message

        try {
            const response = await fetch(mapfusion_make_settings.ajax_url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'mapfusion_clear_make_token',
                    nonce: mapfusion_make_settings.nonce,
                }),
            });

            logToDevTools('info', 'AJAX request sent.', { url: mapfusion_make_settings.ajax_url }, 'clearToken');

            if (!response.ok) {
                logToDevTools('error', `HTTP error with status: ${response.status}`, null, 'clearToken');
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            const result = await response.json();
            logToDevTools('info', 'Response received from server.', { result }, 'clearToken');

            if (result && result.success) {
                elements.makeTokenInput.value = ''; // Clear the input field
                showMessage(elements.tokenSuccessMessage, '✔ Token cleared successfully!', false); // Use token-specific success message
                logToDevTools('info', 'Token cleared successfully.', null, 'clearToken');
            } else {
                const errorMessage = result.message || 'Unknown error occurred while clearing the token.';
                logToDevTools('error', 'Unexpected response structure.', { result }, 'clearToken');
                throw new Error(errorMessage);
            }
        } catch (error) {
            logToDevTools('error', 'Network error occurred while clearing token.', { error: error.message }, 'clearToken');
            showMessage(elements.tokenErrorMessage, `✖ Error: ${error.message}`, true); // Use token-specific error message
        } finally {
            // Update Save Token button state based on the cleared token input
            updateSaveTokenButtonState();
            toggleButtonLoading('make-clear-token', false);
            logToDevTools('info', 'Finished clearing token process.', null, 'clearToken');
        }
    }

    /**
     * Delete Saved Make Token
     *
     * Sends a request to delete the saved Make token from the server after user confirmation.
     * Provides feedback and ensures proper state management during the process.
     */
    async function deleteToken() {
        logToDevTools('info', 'Initializing Delete Token functionality.', null, 'deleteToken');

        // Confirmation prompt before proceeding
        if (!confirm('Are you sure you want to delete the token? This action cannot be undone.')) {
            logToDevTools('info', 'Delete Token action canceled by user.', null, 'deleteToken');
            return;
        }

        logToDevTools('info', 'Proceeding with Delete Token request.', null, 'deleteToken');
        toggleButtonLoading('make-delete-token', true);
        hideMessage(elements.tokenErrorMessage); // Use token-specific error message
        hideMessage(elements.tokenSuccessMessage); // Use token-specific success message

        try {
            const response = await fetch(mapfusion_make_settings.ajax_url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'mapfusion_delete_make_token', // Matches the PHP hook
                    nonce: mapfusion_make_settings.nonce, // Security nonce
                }),
            });

            if (!response.ok) {
                logToDevTools('error', `HTTP error: ${response.status}`, null, 'deleteToken');
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            const data = await response.json();
            logToDevTools('info', 'Delete Token response received.', { data }, 'deleteToken');

            if (data.success) {
                logToDevTools('info', 'Token deleted successfully.', null, 'deleteToken');
                showMessage(elements.tokenSuccessMessage, '✔ Token deleted successfully!', false);

                // Clear the token input field
                if (elements.makeTokenInput) {
                    elements.makeTokenInput.value = '';
                    updateSaveTokenButtonState();
                    logToDevTools('info', 'Token input field cleared.', null, 'deleteToken');
                }
            } else {
                const errorMessage = data.message || 'Failed to delete the token.';
                logToDevTools('warn', errorMessage, null, 'deleteToken');
                showMessage(elements.tokenErrorMessage, `✖ ${errorMessage}`, true);
            }
        } catch (error) {
            logToDevTools('error', `Error deleting token: ${error.message}`, null, 'deleteToken');
            showMessage(elements.tokenErrorMessage, `✖ Error: ${error.message}`, true);
        } finally {
            toggleButtonLoading('make-delete-token', false);
            logToDevTools('info', 'Finished Delete Token process.', null, 'deleteToken');
        }
    }

    /**
     * Request and Save New Token
     *
     * Sends a request to the server to generate a new token, updates the user interface,
     * and saves the token. Provides feedback and ensures proper state management during the process.
     */
    async function getNewToken() {
        logToDevTools('info', 'Requesting a new token...', null, 'getNewToken');
        toggleButtonLoading('make-get-new-token', true);
        hideMessage(elements.tokenErrorMessage); // Use token-specific error message
        hideMessage(elements.tokenSuccessMessage); // Use token-specific success message

        try {
            const response = await fetch(mapfusion_make_settings.ajax_url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'mapfusion_get_new_token',
                    nonce: mapfusion_make_settings.nonce,
                }),
            });

            // Log and handle HTTP errors explicitly
            if (!response.ok) {
                const errorText = await response.text(); // Get raw response body
                logToDevTools(
                    'error',
                    `HTTP error: ${response.status} (${response.statusText}). Response: ${errorText}`,
                    null,
                    'getNewToken'
                );
                throw new Error(`HTTP error! Status: ${response.status} (${response.statusText})`);
            }

            const result = await response.json();
            logToDevTools('info', 'Response received from server.', { result }, 'getNewToken');

            // Handle server-side errors
            if (!result || !result.success) {
                const errorMessage = result.message || 'Unknown server error occurred.';
                logToDevTools(
                    'error',
                    `Unexpected response structure or error from server. Response: ${JSON.stringify(result)}`,
                    null,
                    'getNewToken'
                );
                throw new Error(errorMessage);
            }

            // Extract and handle the new token
            const newToken = result.data.token;
            if (!newToken) {
                logToDevTools(
                    'error',
                    'Response did not include a token: ' + JSON.stringify(result),
                    null,
                    'getNewToken'
                );
                throw new Error('Response did not include a valid token.');
            }

            showMessage(elements.tokenSuccessMessage, '✔ New token generated and saved!', false);
            logToDevTools('info', 'New token received: ' + newToken, null, 'getNewToken');

            // Dynamically update the input field and manage button state
            if (elements.makeTokenInput) {
                elements.makeTokenInput.value = newToken;
                updateSaveTokenButtonState();
                logToDevTools('info', 'Token input field updated with new token.', null, 'getNewToken');
            }
        } catch (error) {
            logToDevTools('error', 'Error during token request.', { error: error.message }, 'getNewToken');
            showMessage(elements.tokenErrorMessage, `✖ Error: ${error.message}`, true);
        } finally {
            toggleButtonLoading('make-get-new-token', false);
            logToDevTools('info', 'Finished requesting new token process.', null, 'getNewToken');
        }
    }

    /**
     * Test Saved Token Validity
     *
     * Sends a request to the server to validate the saved token by fetching available tokens
     * from the Make API. Updates the user interface with the validation result and provides feedback.
     */
    async function testToken() {
        logToDevTools('info', 'Testing token validity...', null, 'testToken');
        toggleButtonLoading('make-test-token', true);
        hideMessage(elements.tokenErrorMessage); // Use token-specific error message
        hideMessage(elements.tokenSuccessMessage); // Use token-specific success message

        try {
            const response = await fetch(mapfusion_make_settings.ajax_url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'mapfusion_test_make_token',
                    nonce: mapfusion_make_settings.nonce,
                }),
            });

            if (!response.ok) {
                logToDevTools('error', `HTTP error: ${response.status}`, null, 'testToken');
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            const result = await response.json();
            logToDevTools('info', 'Full response received.', { result }, 'testToken');

            // Retrieve isValid and timestamp from result.data
            const { isValid, timestamp } = result.data || {};
            logToDevTools('info', `Token validity: ${isValid}`, null, 'testToken');
            logToDevTools('info', `Token timestamp: ${timestamp}`, null, 'testToken');

            if (isValid === true) {
                showMessage(elements.tokenSuccessMessage, `✔ Token is valid! Created: ${timestamp}`, false);
                logToDevTools('info', 'Token is valid.', { timestamp }, 'testToken');
            } else if (isValid === false) {
                showMessage(elements.tokenErrorMessage, '✖ Token is invalid.', true);
                logToDevTools('warn', 'Token is invalid.', null, 'testToken');
            } else {
                throw new Error('Unexpected response structure: isValid is not defined.');
            }
        } catch (error) {
            logToDevTools('error', `Error during token validation: ${error.message}`, null, 'testToken');
            showMessage(elements.tokenErrorMessage, `✖ Error: ${error.message}`, true);
        } finally {
            logToDevTools('info', 'Finished token testing process.', null, 'testToken');
            toggleButtonLoading('make-test-token', false);
        }
    }

    // ===========================
    // === Settings Management ===
    // ===========================

    /**
     * Fetch Zone
     *
     * Fetches the list of zones for the dropdown menu.
     */
    async function fetchZone() {
        logToDevTools('info', 'Fetching list of zones for dropdown.', null, 'fetchZone');

        // 1. Check if another operation is in progress
        if (isProcessing) {
            logToDevTools('warn', 'Another operation is already in progress.', null, 'fetchZone');
            return;
        }

        isProcessing = true;

        try {
            // 2. Verify that required elements are present
            if (!elements.zoneDropdown) {
                logToDevTools(
                    'warn',
                    'Required element missing for Fetch Zone.',
                    { zoneDropdown: elements.zoneDropdown },
                    'fetchZone'
                );
                throw new Error('Required element is missing.');
            }

            // 3. Hide any previous messages
            hideMessage(elements.settingsErrorMessage);
            hideMessage(elements.settingsSuccessMessage);

            // 4. Fetch the zones for dropdown from the server
            const response = await fetch(mapfusion_make_settings.ajax_url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'mapfusion_fetch_zone',
                    nonce: mapfusion_make_settings.nonce,
                }),
            });

            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            const result = await response.json();

            // 5. Process the fetched zone data
            if (result.success && result.data && result.data.zones) {
                const zones = result.data.zones;

                // 6. Populate the dropdown with fetched zones
                logToDevTools('info', 'Zones fetched successfully and dropdown updated.', { zones }, 'fetchZone');

                // Clear the dropdown first
                elements.zoneDropdown.innerHTML = '';

                // Add "-- Select Zone --" as the first option
                const defaultOption = document.createElement('option');
                defaultOption.value = '';
                defaultOption.textContent = '-- Select Zone --';
                elements.zoneDropdown.appendChild(defaultOption);

                // Add the rest of the fetched zones
                zones.forEach(zone => {
                    const option = document.createElement('option');
                    option.value = zone;
                    option.textContent = zone.toUpperCase(); // Display the zone name in uppercase
                    elements.zoneDropdown.appendChild(option);
                });

            } else {
                throw new Error(result.message || 'No zones returned by the server.');
            }
        } catch (error) {
            // 7. Show error message if something goes wrong
            showMessage(elements.settingsErrorMessage, `❌ Error: ${error.message}`, true);
            logToDevTools('error', 'Error fetching zones for dropdown.', { error: error.message }, 'fetchZone');
        } finally {
            // 8. Reset the processing flag
            isProcessing = false;
        }
    }

    /**
     * Save Zone
     *
     * Handles the saving of the currently selected zone to the server via an API request.
     * Ensures validation, feedback, and proper state management during the process.
     */
    async function saveZone() {

        logToDevTools('info', 'Initiating zone save process.', null, 'saveZone');

        if (isProcessing) {
            logToDevTools('warn', 'Save operation already in progress.', null, 'saveZone');
            return;
        }

        if (!elements.zoneDropdown) {
            logToDevTools(
                'error',
                'Required element missing for saving the zone.',
                { zoneDropdown: elements.zoneDropdown },
                'saveZone'
            );
            return;
        }

        isProcessing = true;
        hideMessage(elements.settingsErrorMessage);
        hideMessage(elements.settingsSuccessMessage);

        try {
            const selectedZone = elements.zoneDropdown.value;

            if (!selectedZone) {
                logToDevTools('warn', 'No zone selected.', null, 'saveZone');
                showMessage(elements.settingsErrorMessage, '❌ Please select a zone before saving.', true);
                return;
            }

            if (selectedZone === currentZone) {
                logToDevTools(
                    'info',
                    'No changes detected. Current zone matches the selected zone.',
                    { currentZone },
                    'saveZone'
                );
                showMessage(elements.settingsSuccessMessage, '✔ No changes detected.', false);
                return;
            }

            // Send the AJAX request to save the zone
            const response = await fetch(mapfusion_make_settings.ajax_url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'mapfusion_save_zone', // Ensure backend action name matches
                    nonce: mapfusion_make_settings.nonce,
                    zone: selectedZone,
                }),
            });

            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            const result = await response.json();
            logToDevTools('info', 'Server response received.', { result }, 'saveZone');

            if (result.success) {
                currentZone = selectedZone; // Update the current zone

                // Remove any direct display updates for currentZone since tabular data handles it now
                showMessage(elements.settingsSuccessMessage, '✔ Zone saved successfully!', false);
                logToDevTools('info', 'Zone saved successfully.', { currentZone }, 'saveZone');
            } else {
                throw new Error(result.message || 'Failed to save zone.');
            }
        } catch (error) {
            logToDevTools('error', 'Error saving zone.', { error: error.message }, 'saveZone');
            showMessage(elements.settingsErrorMessage, `❌ Error: ${error.message}`, true);
        } finally {
            isProcessing = false;
        }
    }

    /**
     * Fetch Organizations
     *
     * Fetches the saved organizations list from the database and updates the dropdown menu.
     */
    async function fetchOrganization() {
        logToDevTools('info', 'Fetching saved organizations from the database.', null, 'fetchOrganization');

        // 1. Show loading indicator and clear previous messages
        toggleButtonLoading('make-fetch-organization', true);
        hideMessage(elements.settingsErrorMessage);
        hideMessage(elements.settingsSuccessMessage);
        showMessage(elements.settingsLoadingMessage, '⏳ Fetching organizations...', false);

        try {
            // 2. Make an AJAX request to fetch saved organizations from the database
            const response = await fetch(mapfusion_make_settings.ajax_url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'mapfusion_fetch_organizations', // Backend action name
                    nonce: mapfusion_make_settings.nonce,
                }),
            });

            // 3. Handle HTTP errors
            if (!response.ok) {
                const errorText = await response.text(); // Capture raw response body for debugging
                logToDevTools('error', `HTTP Error! Status: ${response.status}`, { errorText }, 'fetchOrganization');
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            // 4. Parse the JSON response
            const result = await response.json();
            logToDevTools('info', 'Response received from server.', { result }, 'fetchOrganization');

            // 5. Ensure the data structure is valid
            if (result && result.success && result.data && Array.isArray(result.data.organizations)) {
                const organizations = result.data.organizations; // Get organizations
                const organizationDropdown = elements.organizationDropdown;

                // 6. Clear existing options
                organizationDropdown.innerHTML = '';

                // 7. Add default option
                const defaultOption = document.createElement('option');
                defaultOption.value = '';
                defaultOption.textContent = '-- Select Organization --';
                organizationDropdown.appendChild(defaultOption);

                // 8. Populate dropdown with organization data
                organizations.forEach((org) => {
                    const name = org.name || 'Unknown Name';
                    const zone = org.zone ? org.zone.toUpperCase() : 'UNKNOWN';
                    const id = org.id || '';

                    if (!name || !zone || !id) {
                        logToDevTools('warn', 'Invalid organization data.', { org }, 'fetchOrganization');
                    }

                    const option = document.createElement('option');
                    option.value = id; // Use ID as the value
                    option.textContent = `${name}, ${zone}`; // Display Name and Zone
                    organizationDropdown.appendChild(option);
                });

                logToDevTools('info', 'Organization dropdown updated from database.', { organizations }, 'fetchOrganization');

                // 9. Verify the currently selected option (if any)
                const selectedOption = organizationDropdown.options[organizationDropdown.selectedIndex];
                logToDevTools(
                    'info',
                    `Currently selected organization: ${selectedOption?.textContent || 'None'} (ID: ${selectedOption?.value || 'None'})`,
                    null,
                    'fetchOrganization'
                );

                // 10. Show success message
                showMessage(elements.settingsSuccessMessage, '✔ Organizations fetched successfully!', false);
            } else {
                const errorMessage = result?.message || 'Unexpected response structure.';
                logToDevTools('error', `Invalid response: ${errorMessage}`, { result }, 'fetchOrganization');
                throw new Error(errorMessage);
            }
        } catch (error) {
            // 11. Log and display errors
            logToDevTools('error', 'Error fetching organizations.', { error: error.message }, 'fetchOrganization');
            showMessage(elements.settingsErrorMessage, `❌ Error: ${error.message}`, true);
        } finally {
            // 12. Hide loading indicator
            toggleButtonLoading('make-fetch-organization', false);
            hideMessage(elements.settingsLoadingMessage);
        }
    }

    /**
     * Save Organization Selection
     *
     * Saves the selected organization to the database and updates the current display.
     */
    async function saveOrganization() {
        // 1. Show loading indicator and clear previous messages
        toggleButtonLoading('make-fetch-organization', true);
        hideMessage(elements.settingsErrorMessage);
        hideMessage(elements.settingsSuccessMessage);
        showMessage(elements.settingsLoadingMessage, '⏳ Saving organization...', false);

        logToDevTools('info', '[saveOrganization] Starting organization save process.');

        // 2. Verify required elements exist
        if (!elements.organizationDropdown) {
            logToDevTools('warn', '[saveOrganization] Required element missing.', {
                organizationDropdown: !!elements.organizationDropdown,
            });
            showMessage(elements.settingsErrorMessage, '❌ Dropdown element is missing. Please reload the page.', true);
            toggleButtonLoading('make-fetch-organization', false);
            return;
        }

        // 3. Fetch the selected option from the dropdown
        const selectedOption = elements.organizationDropdown.options[elements.organizationDropdown.selectedIndex];
        if (!selectedOption || !selectedOption.value) {
            logToDevTools('warn', '[saveOrganization] No organization selected.');
            showMessage(elements.settingsErrorMessage, '❌ Please select an organization.', true);
            toggleButtonLoading('make-fetch-organization', false);
            return;
        }

        // 4. Extract organization details
        const selectedOrgId = selectedOption.value;
        const [selectedOrgName, selectedOrgZone] = selectedOption.textContent.split(',').map(s => s.trim());

        logToDevTools('info', '[saveOrganization] Extracted organization details.', {
            selectedOrgId,
            selectedOrgName,
            selectedOrgZone
        });

        if (selectedOrgId === currentOrganizationID) {
            logToDevTools('info', '[saveOrganization] No changes detected.', { currentOrganizationID });
            showMessage(elements.settingsSuccessMessage, '✔ No changes detected.', false);
            toggleButtonLoading('make-fetch-organization', false);
            return;
        }

        try {
            // 6. Prepare and send AJAX request
            logToDevTools('info', '[saveOrganization] Sending AJAX request.', {
                ajax_url: mapfusion_make_settings.ajax_url,
                selectedOrgId,
                selectedOrgName,
                selectedOrgZone,
                nonce: mapfusion_make_settings.nonce
            });

            const response = await fetch(mapfusion_make_settings.ajax_url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'mapfusion_save_organization',
                    nonce: mapfusion_make_settings.nonce,
                    organization_name: selectedOrgName,
                    organization_zone: selectedOrgZone,
                    organization_id: selectedOrgId
                }),
            });

            // 7. Check HTTP response status
            logToDevTools('info', '[saveOrganization] Response received from server.', {
                status: response.status,
                statusText: response.statusText
            });

            if (!response.ok) {
                const errorText = await response.text();
                logToDevTools('error', '[saveOrganization] HTTP error occurred.', {
                    status: response.status,
                    errorText
                });
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            // 8. Parse JSON response
            const result = await response.json();
            logToDevTools('info', '[saveOrganization] Parsed JSON response.', { result });

            // 9. Handle server response
            if (result.success) {
                currentOrganizationID = selectedOrgId; // Update global variable
                logToDevTools('info', '[saveOrganization] Organization saved successfully.', { selectedOrgId });
                showMessage(elements.settingsSuccessMessage, '✔ Organization saved successfully!', false);
            } else {
                logToDevTools('error', '[saveOrganization] Failed to save organization.', { result });
                showMessage(elements.settingsErrorMessage, `❌ ${result.message || 'Failed to save organization.'}`, true);
                throw new Error(result.message || 'Failed to save organization.');
            }
        } catch (error) {
            // 10. Handle errors
            logToDevTools('error', '[saveOrganization] Error during save operation.', { error: error.message });
            showMessage(elements.settingsErrorMessage, `❌ Error: ${error.message}`, true);
        } finally {
            // 11. Hide loading indicator
            toggleButtonLoading('make-fetch-organization', false);
            hideMessage(elements.settingsLoadingMessage);
        }
    }

    /**
     * Fetch Teams
     *
     * Fetches the saved teams list from the database and updates the dropdown menu.
     */
    async function fetchTeams() {
        logToDevTools('info', '[fetchTeams] Starting team fetch process.');

        // 1. Show loading indicator and clear previous messages
        toggleButtonLoading('make-fetch-teams', true);
        hideMessage(elements.settingsErrorMessage);
        hideMessage(elements.settingsSuccessMessage);
        showMessage(elements.settingsLoadingMessage, '⏳ Fetching teams...', false);

        try {
            // 2. Make an AJAX request to fetch saved teams from the database
            const response = await fetch(mapfusion_make_settings.ajax_url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'mapfusion_fetch_teams', // Backend action name
                    nonce: mapfusion_make_settings.nonce,
                }),
            });

            // 3. Handle HTTP errors
            if (!response.ok) {
                const errorText = await response.text(); // Capture raw response body for debugging
                logToDevTools('error', `HTTP Error! Status: ${response.status}`, { errorText }, 'fetchTeams');
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            // 4. Parse the JSON response
            const result = await response.json();
            logToDevTools('info', 'Response received from server.', { result }, 'fetchTeams');

            // 5. Ensure the data structure is valid
            if (result && result.success && result.data && Array.isArray(result.data.teams)) {
                const teams = result.data.teams; // Get teams
                const teamDropdown = elements.teamDropdown;

                // 6. Clear existing options
                teamDropdown.innerHTML = '';

                // 7. Add default option
                const defaultOption = document.createElement('option');
                defaultOption.value = '';
                defaultOption.textContent = '-- Select Team --';
                teamDropdown.appendChild(defaultOption);

                // 8. Populate dropdown with team data
                teams.forEach((team) => {
                    const name = team.name || 'Unknown Name';
                    const id = team.id || '';

                    if (!name || !id) {
                        logToDevTools('warn', 'Invalid team data.', { team }, 'fetchTeams');
                    }

                    const option = document.createElement('option');
                    option.value = id; // Use ID as the value
                    option.textContent = name; // Display team name
                    teamDropdown.appendChild(option);
                });

                logToDevTools('info', 'Team dropdown updated from database.', { teams }, 'fetchTeams');

                // 9. Verify the currently selected option (if any)
                const selectedOption = teamDropdown.options[teamDropdown.selectedIndex];
                logToDevTools(
                    'info',
                    `Currently selected team: ${selectedOption?.textContent || 'None'} (ID: ${selectedOption?.value || 'None'})`,
                    null,
                    'fetchTeams'
                );

                // 10. Show success message
                showMessage(elements.settingsSuccessMessage, '✔ Teams fetched successfully!', false);
            } else {
                const errorMessage = result?.message || 'Unexpected response structure.';
                logToDevTools('error', `Invalid response: ${errorMessage}`, { result }, 'fetchTeams');
                throw new Error(errorMessage);
            }
        } catch (error) {
            // 11. Log and display errors
            logToDevTools('error', 'Error fetching teams.', { error: error.message }, 'fetchTeams');
            showMessage(elements.settingsErrorMessage, `❌ Error: ${error.message}`, true);
        } finally {
            // 12. Hide loading indicator
            toggleButtonLoading('make-fetch-teams', false);
            hideMessage(elements.settingsLoadingMessage);
        }
    }

    /**
     * Save Team Selection
     *
     * Saves the selected team to the database and updates the current display.
     */
    async function saveTeam() {
        // 1. Show loading indicator and clear previous messages
        toggleButtonLoading('make-fetch-teams', true);
        hideMessage(elements.settingsErrorMessage);
        hideMessage(elements.settingsSuccessMessage);
        showMessage(elements.settingsLoadingMessage, '⏳ Saving team...', false);

        logToDevTools('info', '[saveTeam] Starting team save process.');

        // 2. Verify required elements exist
        if (!elements.teamDropdown) {
            logToDevTools('warn', '[saveTeam] Required element missing.', {
                teamDropdown: !!elements.teamDropdown,
            });
            showMessage(elements.settingsErrorMessage, '❌ Dropdown element is missing. Please reload the page.', true);
            toggleButtonLoading('make-fetch-teams', false); // Ensure button is reset
            return;
        }

        // 3. Fetch the selected option from the dropdown
        const selectedOption = elements.teamDropdown.options[elements.teamDropdown.selectedIndex];
        if (!selectedOption || !selectedOption.value) {
            logToDevTools('warn', '[saveTeam] No team selected.');
            showMessage(elements.settingsErrorMessage, '❌ Please select a team.', true);
            toggleButtonLoading('make-fetch-teams', false); // Ensure button is reset
            return;
        }

        // 4. Extract team details
        const selectedTeamId = selectedOption.value;
        const selectedTeamName = selectedOption.textContent.trim();

        logToDevTools('info', '[saveTeam] Extracted team details.', {
            selectedTeamId,
            selectedTeamName
        });

        // 5. Check if the selected value matches the current team
        if (selectedTeamId === currentTeamID) {
            logToDevTools('info', '[saveTeam] No changes detected.', { currentTeamID });
            showMessage(elements.settingsSuccessMessage, '✔ No changes detected.', false);
            toggleButtonLoading('make-fetch-teams', false);
            return;
        }

        try {
            // 6. Prepare and send AJAX request
            logToDevTools('info', '[saveTeam] Sending AJAX request.', {
                ajax_url: mapfusion_make_settings.ajax_url,
                selectedTeamId,
                selectedTeamName,
                nonce: mapfusion_make_settings.nonce
            });

            const response = await fetch(mapfusion_make_settings.ajax_url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'mapfusion_save_team',
                    nonce: mapfusion_make_settings.nonce,
                    team_name: selectedTeamName,
                    team_id: selectedTeamId
                }),
            });

            // 7. Check HTTP response status
            logToDevTools('info', '[saveTeam] Response received from server.', {
                status: response.status,
                statusText: response.statusText
            });

            if (!response.ok) {
                const errorText = await response.text();
                logToDevTools('error', '[saveTeam] HTTP error occurred.', { status: response.status, errorText });
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            // 7. Parse JSON response
            const result = await response.json();
            logToDevTools('info', '[saveTeam] Parsed JSON response.', { result });

            // 9. Handle server response
            if (result.success) {
                currentTeamID = selectedTeamId; // Update global variable
                logToDevTools('info', '[saveTeam] Team saved successfully.', { selectedTeamId });
                showMessage(elements.settingsSuccessMessage, '✔ Team saved successfully!', false);
            } else {
                logToDevTools('error', '[saveTeam] Failed to save team.', { result });
                showMessage(elements.settingsErrorMessage, `❌ ${result.message || 'Failed to save team.'}`, true);
                throw new Error(result.message || 'Failed to save team.');
            }
        } catch (error) {
            // 10. Handle errors
            logToDevTools('error', '[saveTeam] Error during save operation.', { error: error.message });
            showMessage(elements.settingsErrorMessage, `❌ Error: ${error.message}`, true);
        } finally {
            // 11. Hide loading indicator
            toggleButtonLoading('make-fetch-teams', false);
            hideMessage(elements.settingsLoadingMessage);
        }
    }

    /**
     * Fetch Connections
     *
     * Fetches the saved connections list from the database and updates the dropdown menu.
     */
    async function fetchConnections() {
        logToDevTools('info', '[fetchConnections] Starting connection fetch process.');

        // 1. Show loading indicator and clear previous messages
        toggleButtonLoading('make-fetch-connections', true);
        hideMessage(elements.settingsErrorMessage);
        hideMessage(elements.settingsSuccessMessage);
        showMessage(elements.settingsLoadingMessage, '⏳ Fetching connections...', false);

        try {
            // 2. Make an AJAX request to fetch saved connections from the database
            const response = await fetch(mapfusion_make_settings.ajax_url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'mapfusion_fetch_connections', // Backend action name
                    nonce: mapfusion_make_settings.nonce,
                }),
            });

            // 3. Handle HTTP errors
            if (!response.ok) {
                const errorText = await response.text(); // Capture raw response body for debugging
                logToDevTools('error', `HTTP Error! Status: ${response.status}`, { errorText }, 'fetchConnections');
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            // 4. Parse the JSON response
            const result = await response.json();
            logToDevTools('info', 'Response received from server.', { result }, 'fetchConnections');

            // 5. Ensure the data structure is valid
            if (result && result.success && result.data && Array.isArray(result.data.connections)) {
                const connections = result.data.connections; // Get connections
                const connectionDropdown = elements.connectionDropdown;

                // 6. Clear existing options
                connectionDropdown.innerHTML = '';

                // 7. Add default option
                const defaultOption = document.createElement('option');
                defaultOption.value = '';
                defaultOption.textContent = '-- Select Connection --';
                connectionDropdown.appendChild(defaultOption);

                // 8. Populate dropdown with connection data
                connections.forEach((connection) => {
                    const name = connection.name || 'Unknown Name';
                    const id = connection.id || '';

                    if (!name || !id) {
                        logToDevTools('warn', 'Invalid connection data.', { connection }, 'fetchConnections');
                    }

                    const option = document.createElement('option');
                    option.value = id; // Use ID as the value
                    option.textContent = name; // Display connection name
                    connectionDropdown.appendChild(option);
                });

                logToDevTools('info', 'Connection dropdown updated from database.', { connections }, 'fetchConnections');

                // 9. Verify the currently selected option (if any)
                const selectedOption = connectionDropdown.options[connectionDropdown.selectedIndex];
                logToDevTools(
                    'info',
                    `Currently selected connection: ${selectedOption?.textContent || 'None'} (ID: ${selectedOption?.value || 'None'})`,
                    null,
                    'fetchConnections'
                );

                // 10. Show success message
                showMessage(elements.settingsSuccessMessage, '✔ Connections fetched successfully!', false);
            } else {
                const errorMessage = result?.message || 'Unexpected response structure.';
                logToDevTools('error', `Invalid response: ${errorMessage}`, { result }, 'fetchConnections');
                throw new Error(errorMessage);
            }
        } catch (error) {
            // 11. Log and display errors
            logToDevTools('error', 'Error fetching connections.', { error: error.message }, 'fetchConnections');
            showMessage(elements.settingsErrorMessage, `❌ Error: ${error.message}`, true);
        } finally {
            // 12. Hide loading indicator
            toggleButtonLoading('make-fetch-connections', false);
            hideMessage(elements.settingsLoadingMessage);
        }
    }

    /**
     * Save Connection Selection
     *
     * Saves the selected connection to the database and updates the current display.
     */
    async function saveConnection() {
        // 1. Show loading indicator and clear previous messages
        toggleButtonLoading('make-fetch-connections', true);
        hideMessage(elements.settingsErrorMessage);
        hideMessage(elements.settingsSuccessMessage);
        showMessage(elements.settingsLoadingMessage, '⏳ Saving connection...', false);

        logToDevTools('info', '[saveConnection] Starting connection save process.');

        // 2. Verify required elements exist
        if (!elements.connectionDropdown) {
            logToDevTools('warn', '[saveConnection] Required element missing.', {
                connectionDropdown: !!elements.connectionDropdown,
            });
            showMessage(elements.settingsErrorMessage, '❌ Dropdown element is missing. Please reload the page.', true);
            toggleButtonLoading('make-fetch-connections', false); // Ensure button is reset
            return;
        }

        // 3. Fetch the selected option from the dropdown
        const selectedOption = elements.connectionDropdown.options[elements.connectionDropdown.selectedIndex];
        if (!selectedOption || !selectedOption.value) {
            logToDevTools('warn', '[saveConnection] No connection selected.');
            showMessage(elements.settingsErrorMessage, '❌ Please select a connection.', true);
            toggleButtonLoading('make-fetch-connections', false); // Ensure button is reset
            return;
        }

        // 4. Extract connection details
        const selectedConnectionId = selectedOption.value;
        const selectedConnectionName = selectedOption.textContent.trim();

        logToDevTools('info', '[saveConnection] Extracted connection details.', {
            selectedConnectionId,
            selectedConnectionName
        });

        try {
            // 5. Prepare and send AJAX request
            logToDevTools('info', '[saveConnection] Sending AJAX request.', {
                ajax_url: mapfusion_make_settings.ajax_url,
                selectedConnectionId,
                selectedConnectionName,
                nonce: mapfusion_make_settings.nonce
            });

            const response = await fetch(mapfusion_make_settings.ajax_url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'mapfusion_save_connection',
                    nonce: mapfusion_make_settings.nonce,
                    connection_name: selectedConnectionName,
                    connection_id: selectedConnectionId
                }),
            });

            // 6. Check if the selected value matches the current connection
            if (selectedConnectionId === currentConnectionID) {
                logToDevTools('info', '[saveConnection] No changes detected.', { currentConnectionID });
                showMessage(elements.settingsSuccessMessage, '✔ No changes detected.', false);
                toggleButtonLoading('make-fetch-connections', false);
                return;
            }

            // 7. Check HTTP response status
            logToDevTools('info', '[saveConnection] Response received from server.', {
                status: response.status,
                statusText: response.statusText
            });

            if (!response.ok) {
                const errorText = await response.text();
                logToDevTools('error', '[saveConnection] HTTP error occurred.', { status: response.status, errorText });
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            // 8. Parse JSON response
            const result = await response.json();
            logToDevTools('info', '[saveConnection] Parsed JSON response.', { result });

            // 9. Handle server response
            if (result.success) {
                currentConnectionID = selectedConnectionId; // Update global variable
                logToDevTools('info', '[saveConnection] Connection saved successfully.', { selectedConnectionId });
                showMessage(elements.settingsSuccessMessage, '✔ Connection saved successfully!', false);
            } else {
                logToDevTools('error', '[saveConnection] Failed to save connection.', { result });
                showMessage(elements.settingsErrorMessage, `❌ ${result.message || 'Failed to save connection.'}`, true);
                throw new Error(result.message || 'Failed to save connection.');
            }

        } catch (error) {
            // 10. Handle errors
            logToDevTools('error', '[saveConnection] Error during save operation.', { error: error.message });
            showMessage(elements.settingsErrorMessage, `❌ Error: ${error.message}`, true);

        } finally {
            // 11. Hide loading indicator
            toggleButtonLoading('make-fetch-connections', false);
            hideMessage(elements.settingsLoadingMessage);
        }
    }

    // =============================
    // === Connection Management ===
    // =============================

    /**
     * Fetch Current Settings
     *
     * Fetches current settings (zone, organization, team, connection) from the backend.
     */
    async function fetchCurrent() {
        logToDevTools('info', '[fetchCurrent] Starting to fetch current settings.', null, 'fetchCurrent');

        // Show loading message and clear previous messages
        toggleButtonLoading('make-test-connection', true);
        hideMessage(elements.connectionErrorMessage);
        hideMessage(elements.connectionSuccessMessage);
        showMessage(elements.connectionLoadingMessage, '⏳ Fetching current settings...', false);

        try {
            // Prepare and send AJAX request
            const response = await fetch(mapfusion_make_settings.ajax_url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'mapfusion_fetch_current', // Backend action name
                    nonce: mapfusion_make_settings.nonce,
                }),
            });

            // Check HTTP response status
            if (!response.ok) {
                const errorText = await response.text();
                logToDevTools('error', '[fetchCurrent] HTTP error occurred.', { status: response.status, errorText }, 'fetchCurrent');
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            // Parse the JSON response
            const result = await response.json();
            logToDevTools('info', '[fetchCurrent] Parsed JSON response.', { result }, 'fetchCurrent');

            // Handle server response
            if (result.success) {
                logToDevTools('info', '[fetchCurrent] Successfully fetched current settings.', result.data);

                // Set all the IDs in global variables
                currentZone = result.data.zone || ''; // Assign the current zone
                currentOrganization = result.data.organization || ''; // Assign the organization
                currentTeam = result.data.team || ''; // Assign the team
                currentConnection = result.data.connection || ''; // Assign the connection
                currentOrganizationID = result.data.organization_id || ''; // Assign the organization ID
                currentTeamID = result.data.team_id || ''; // Assign the team ID
                currentConnectionID = result.data.connection_id || ''; // Assign the connection ID

                // Optionally log the values of the IDs
                console.log("Current IDs:", { currentZone, currentOrganizationID, currentTeamID, currentConnectionID });

                // Dynamically update the values in the table
                elements.currentZone.textContent = (result.data.zone || '--').toUpperCase();
                elements.currentOrganization.textContent = result.data.organization || '--';
                elements.currentTeam.textContent = result.data.team || '--';
                elements.currentConnection.textContent = result.data.connection || '--';

                showMessage(elements.connectionSuccessMessage, '✔ Current settings fetched successfully!', false);
            } else {
                logToDevTools('error', '[fetchCurrent] Failed to fetch current settings.', result);
                showMessage(elements.connectionErrorMessage, `❌ ${result.message || 'Failed to fetch current settings.'}`, true);
                throw new Error(result.message || 'Failed to fetch current settings.');
            }
        } catch (error) {
            // Handle errors
            logToDevTools('error', '[fetchCurrent] Error during fetch operation.', { error: error.message }, 'fetchCurrent');
            showMessage(elements.connectionErrorMessage, `❌ Error: ${error.message}`, true);
        } finally {
            // Hide loading message and reset button
            toggleButtonLoading('make-test-connection', false);
            hideMessage(elements.connectionLoadingMessage);
        }
    }

    /**
     * Test Connection
     *
     * Sends a test request to the Make API for the currently selected connection and updates results dynamically.
     */
    async function testConnection() {
        // Check if a test operation is already in progress
        if (isProcessing) {
            logToDevTools('warn', 'Test operation already in progress.', null, 'testConnection');
            return;
        }

        logToDevTools('info', '[testConnection] Starting connection test.');

        // Set processing state
        isProcessing = true;

        // Show loading message
        toggleButtonLoading('make-test-connection', true);
        hideMessage(elements.connectionErrorMessage);
        hideMessage(elements.connectionSuccessMessage);
        showMessage(elements.connectionLoadingMessage, '⏳ Testing connection...', false);

        try {
            // Prepare and send AJAX request
            logToDevTools('info', '[testConnection] Sending AJAX request.', null, 'testConnection');

            const response = await fetch(mapfusion_make_settings.ajax_url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'mapfusion_test_connection', // Backend action name
                    nonce: mapfusion_make_settings.nonce,
                }),
            });

            // Check HTTP response status
            if (!response.ok) {
                const errorText = await response.text(); // Capture raw response body for debugging
                logToDevTools('error', '[testConnection] HTTP error occurred.', {
                    status: response.status,
                    errorText,
                }, 'testConnection');
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            // Parse the JSON response
            const result = await response.json();
            logToDevTools('info', '[testConnection] Parsed JSON response.', { result }, 'testConnection');

            // Handle server response
            if (result.success) {
                logToDevTools('info', '[testConnection] Connection test successful.', result.data);
                showMessage(elements.connectionSuccessMessage, '✔ Connection test successful!', false);

                // Update connectionAPIResult dynamically
                elements.connectionAPIResult.textContent = `${result.data.message}, ${result.data.status}`;
                logToDevTools('info', '[testConnection] API result updated.', {
                    message: result.data.message,
                    status: result.data.status,
                }, 'testConnection');

                // Update connectionAPIStatus dynamically based on verification result
                elements.connectionAPIStatus.textContent = result.data.verified ? 'Active' : 'Inactive';

                // Update text color based on verification status
                if (result.data.verified) {
                    // Active status
                    elements.connectionAPIStatus.classList.add('text-green');  // Add green class for Active
                    elements.connectionAPIStatus.classList.remove('text-red'); // Remove red class if present
                } else {
                    // Inactive status
                    elements.connectionAPIStatus.classList.add('text-red');    // Add red class for Inactive
                    elements.connectionAPIStatus.classList.remove('text-green'); // Remove green class if present
                }

                logToDevTools('info', '[testConnection] API status updated based on verification.', {
                    verified: result.data.verified,
                }, 'testConnection');

            } else {
                // Handle API failure
                logToDevTools('error', '[testConnection] Connection test failed.', result);

                // Show error message
                showMessage(elements.connectionErrorMessage, `❌ ${result.data.message || 'Connection test failed.'}`, true);

                // Update connectionAPIResult dynamically with error information
                elements.connectionAPIResult.textContent = `Error: ${result.data.message || 'Connection test failed.'} Detail: ${result.data.detail || 'No additional details available.'} Code: ${result.data.code || 'Unknown error code'} Status: ${result.data.status || 'Unknown status'}`;

                logToDevTools('info', '[testConnection] API result updated with error.', {
                    message: result.data.message || 'Connection test failed.',
                    detail: result.data.detail || 'No additional details available.',
                    code: result.data.code || 'Unknown error code',
                    status: result.data.status || 'Unknown status',
                }, 'testConnection');

                // Update connectionAPIStatus dynamically with result.data.statusText
                elements.connectionAPIStatus.textContent = result.data.statusText || 'Error';  // Use result.data.statusText, fallback to 'Error' if not available

                // Log the statusText for debugging
                logToDevTools('info', '[testConnection] connectionAPIStatus updated with statusText.', {
                    statusText: result.data.statusText || 'Error',  // Fallback to 'Error' if statusText is missing
                }, 'testConnection');

                // Add red class for error status
                elements.connectionAPIStatus.classList.add('text-red');
                elements.connectionAPIStatus.classList.remove('text-green');

                logToDevTools('info', '[testConnection] API status updated to inactive due to failure.', {
                    verified: false,
                }, 'testConnection');
            }
        } catch (error) {
            // Handle errors
            logToDevTools('error', '[testConnection] Error during connection test.', { error: error.message }, 'testConnection');
            showMessage(elements.connectionErrorMessage, `❌ Error: ${error.message}`, true);
        } finally {
            // Reset processing state and hide loading message
            isProcessing = false;
            toggleButtonLoading('make-test-connection', false);
            hideMessage(elements.connectionLoadingMessage);
        }
    }

    // ==============================
    // === Interaction Management ===
    // ==============================

    /**
     * Add event listeners for all buttons.
     * Iterates over elements and assigns the appropriate event handlers to each button.
     */
    function addEventListeners() {
        return new Promise((resolve, reject) => {
            logToDevTools('info', 'Adding event listeners...', null, 'addEventListeners');

            if (!Object.keys(elements).length) {
                logToDevTools('error', 'No elements found to add event listeners. Ensure elements object is defined.', null, 'addEventListeners');
                return reject(new Error('No elements found.'));
            }

            try {
                Object.keys(elements).forEach((key) => {
                    const element = elements[key];
                    if (!element) {
                        logToDevTools('warn', `No element found for key "${key}". Skipping...`, null, 'addEventListeners');
                        return;
                    }

                    switch (key) {
                        case 'saveTokenButton':
                            element.addEventListener('click', saveToken);
                            break;

                        case 'clearTokenButton':
                            element.addEventListener('click', clearToken);
                            break;

                        case 'deleteTokenButton':
                            element.addEventListener('click', deleteToken);
                            break;

                        case 'getNewTokenButton':
                            element.addEventListener('click', getNewToken);
                            break;

                        case 'testTokenButton':
                            element.addEventListener('click', testToken);
                            break;

                        case 'zoneDropdown':
                            element.addEventListener('change', () => {
                                isUserInteracting = true; // Mark that the user is interacting
                                logToDevTools('info', 'User changed zone via dropdown.', { selectedZone: element.value }, 'addEventListeners');

                                // Call saveZone to save the new selection
                                saveZone().finally(() => {
                                    isUserInteracting = false; // Reset the flag after save
                                });
                            });
                            logToDevTools('info', `Event listener added for "${key}".`, null, 'addEventListeners');
                            break;

                        case 'organizationDropdown':
                            element.addEventListener('change', () => {
                                isUserInteracting = true; // Mark that the user is interacting
                                const selectedOption = element.options[element.selectedIndex];

                                logToDevTools('info', 'User changed organization via dropdown.', {
                                    selectedOrganization: selectedOption ? selectedOption.textContent : 'None',
                                    selectedID: selectedOption ? selectedOption.value : 'None',
                                }, 'addEventListeners');

                                // Call saveOrganization to save the new selection
                                saveOrganization().finally(() => {
                                    isUserInteracting = false; // Reset the flag after save
                                });
                            });
                            logToDevTools('info', `Event listener added for "${key}".`, null, 'addEventListeners');
                            break;

                        case 'fetchOrganizationsButton':
                            element.addEventListener('click', () => fetchOrganization(true));
                            break;

                        case 'teamDropdown':
                            element.addEventListener('change', () => {
                                isUserInteracting = true; // Mark that the user is interacting
                                const selectedOption = element.options[element.selectedIndex];

                                logToDevTools('info', 'User changed team via dropdown.', {
                                    selectedTeam: selectedOption ? selectedOption.textContent : 'None',
                                    selectedID: selectedOption ? selectedOption.value : 'None',
                                }, 'addEventListeners');

                                // Call saveTeam to save the new selection
                                saveTeam().finally(() => {
                                    isUserInteracting = false; // Reset the flag after save
                                });
                            });
                            logToDevTools('info', `Event listener added for "${key}".`, null, 'addEventListeners');
                            break;

                        case 'fetchTeamsButton':
                            element.addEventListener('click', () => fetchTeams(true));
                            logToDevTools('info', `Event listener added for "${key}" with force update enabled.`, null, 'addEventListeners');
                            break;

                        case 'connectionDropdown':
                            element.addEventListener('change', () => {
                                isUserInteracting = true; // Mark that the user is interacting
                                const selectedOption = element.options[element.selectedIndex];

                                logToDevTools('info', 'User changed connection via dropdown.', {
                                    selectedConnection: selectedOption ? selectedOption.textContent : 'None',
                                    selectedID: selectedOption ? selectedOption.value : 'None',
                                }, 'addEventListeners');

                                // Call saveConnection to save the new selection
                                saveConnection().finally(() => {
                                    isUserInteracting = false; // Reset the flag after save
                                });
                            });
                            logToDevTools('info', `Event listener added for "${key}".`, null, 'addEventListeners');
                            break;

                        case 'fetchConnectionsButton':
                            element.addEventListener('click', () => fetchConnections(true));
                            logToDevTools('info', `Event listener added for "${key}" with force update enabled.`, null, 'addEventListeners');
                            break;

                        case 'connectionAPIButton':
                            element.addEventListener('click', testConnection);
                            break;
                    }
                });

                // All event listeners were added successfully, resolve the promise
                resolve();
            } catch (error) {
                // If an error occurs, reject the promise with an error message
                reject(new Error('Error while adding event listeners: ' + error.message));
            }
        });
    }

    /**
     * Initialize Make API management on page load.
     * Sets up event listeners, zone settings, and organization settings.
     */
    function initializeMakeAPIManagement() {
        logToDevTools('info', 'Running Make API management initialization.', null, 'initializeMakeAPIManagement');

        // 1. Initialize all event listeners
        logToDevTools('info', '1. Initializing event listeners...', null, 'initializeMakeAPIManagement');
        addEventListeners()
            .then(() => logToDevTools('info', '1. Event listeners initialized successfully.', null, 'initializeMakeAPIManagement'))
            .catch((error) => logToDevTools('error', '1. Error during addEventListeners initialization: ' + error.message, null, 'initializeMakeAPIManagement'))

            // 2. Fetch and initialize token input
            .then(() => {
                logToDevTools('info', '2. Initializing token input...', null, 'initializeMakeAPIManagement');
                return makeTokenInput();
            })
            .then(() => logToDevTools('info', '2. Token input initialized successfully.', null, 'initializeMakeAPIManagement'))
            .catch((error) => logToDevTools('error', '2. Error during makeTokenInput initialization: ' + error.message, null, 'initializeMakeAPIManagement'))

            // 3. Set initial state of Save Token button and add related listeners
            .then(() => {
                logToDevTools('info', '3. Setting initial state for Save Token button...', null, 'initializeMakeAPIManagement');
                updateSaveTokenButtonState();

                if (elements.makeTokenInput) {
                    elements.makeTokenInput.addEventListener('input', updateSaveTokenButtonState);
                    logToDevTools('info', '3. Input event listener added for token input field.', null, 'initializeMakeAPIManagement');
                } else {
                    logToDevTools('warn', '3. Token input field is missing. Skipping listener setup.', null, 'initializeMakeAPIManagement');
                }
            })
            .catch((error) => logToDevTools('error', '3. Error during Save Token button state initialization: ' + error.message, null, 'initializeMakeAPIManagement'))

            // 4. Fetch and display the zones dropdown
            .then(() => {
                logToDevTools('info', '4. Initializing Fetch Zone...', null, 'initializeMakeAPIManagement');

                // Verify that the required element exists before calling fetchZone
                if (!elements.zoneDropdown) {
                    logToDevTools('warn', '4. Required element missing for Fetch Zone. Initialization skipped.',
                        { zoneDropdown: elements.zoneDropdown },
                        'initializeMakeAPIManagement');
                    return Promise.reject();
                }

                // Call fetchZone() to populate the dropdown
                return fetchZone();
            })
            .then(() => logToDevTools('info', '4. Zones dropdown populated successfully.', null, 'initializeMakeAPIManagement'))
            .catch((error) => logToDevTools('error', '4. Error during Fetch Zone initialization: ' + error.message, null, 'initializeMakeAPIManagement'))

            // 5. Fetch and display the organizations dropdown
            .then(() => {
                logToDevTools('info', '5. Initializing Fetch Organization...', null, 'initializeMakeAPIManagement');

                // Verify that the required element exists before calling fetchOrganization
                if (!elements.organizationDropdown) {
                    logToDevTools('warn', '5. Required element missing for Fetch Organization. Initialization skipped.',
                        { organizationDropdown: elements.organizationDropdown },
                        'initializeMakeAPIManagement');
                    return Promise.reject();
                }

                // Call fetchOrganization() to populate the dropdown
                return fetchOrganization();
            })
            .then(() => logToDevTools('info', '5. Organizations dropdown populated successfully.', null, 'initializeMakeAPIManagement'))
            .catch((error) => logToDevTools('error', '5. Error during Fetch Organization initialization: ' + error.message, null, 'initializeMakeAPIManagement'))

            // 6. Fetch and display the teams dropdown
            .then(() => {
                logToDevTools('info', '6. Initializing Fetch Teams...', null, 'initializeMakeAPIManagement');

                // Verify that the required element exists before calling fetchTeams
                if (!elements.teamDropdown) {
                    logToDevTools('warn', '6. Required element missing for Fetch Teams. Initialization skipped.',
                        { teamDropdown: elements.teamDropdown },
                        'initializeMakeAPIManagement');
                    return Promise.reject();
                }

                // Call fetchTeams() to populate the dropdown
                return fetchTeams();
            })
            .then(() => logToDevTools('info', '6. Teams dropdown populated successfully.', null, 'initializeMakeAPIManagement'))
            .catch((error) => logToDevTools('error', '6. Error during Fetch Teams initialization: ' + error.message, null, 'initializeMakeAPIManagement'))

            // 7. Fetch and display the connections dropdown
            .then(() => {
                logToDevTools('info', '7. Initializing Fetch Connections...', null, 'initializeMakeAPIManagement');

                // Verify that the required element exists before calling fetchConnections
                if (!elements.connectionDropdown) {
                    logToDevTools('warn', '7. Required element missing for Fetch Connections. Initialization skipped.',
                        { connectionDropdown: elements.connectionDropdown },
                        'initializeMakeAPIManagement');
                    return Promise.reject();
                }

                // Call fetchConnections() to populate the dropdown
                return fetchConnections();
            })
            .then(() => logToDevTools('info', '7. Connections dropdown populated successfully.', null, 'initializeMakeAPIManagement'))
            .catch((error) => logToDevTools('error', '7. Error during Fetch Connections initialization: ' + error.message, null, 'initializeMakeAPIManagement'))

            // 8. Fetch and display the current settings in the table and run "Test Connection"
            .then(() => {
                logToDevTools('info', '8. Initializing current settings table...', null, 'initializeMakeAPIManagement');

                // Verify that the required elements exist before populating the table
                if (!elements.currentZone || !elements.currentOrganization || !elements.currentTeam || !elements.currentConnection) {
                    logToDevTools('warn', '8. Required elements missing for current settings table. Initialization skipped.',
                        {
                            currentZone: elements.currentZone,
                            currentOrganization: elements.currentOrganization,
                            currentTeam: elements.currentTeam,
                            currentConnection: elements.currentConnection,
                        },
                        'initializeMakeAPIManagement');
                    return Promise.reject();
                }

                // Call fetchCurrent() to populate the table with the current values
                return fetchCurrent().then(() => {
                    // Call testConnection after fetchCurrent is completed
                    return testConnection();
                });
            })
            .then(() => logToDevTools('info', '8. Test Connection executed successfully.', null, 'initializeMakeAPIManagement'))
            .catch((error) => logToDevTools('error', '8. Error during Test Connection execution: ' + error.message, null, 'initializeMakeAPIManagement'));
    }


    // Call the initialization function
    initializeMakeAPIManagement();
});