// File: debug-settings.js

/**
 * MapFusion Debug Settings
 * Handles enabling/disabling debug logging and saving/debugging settings.
 */

document.addEventListener('DOMContentLoaded', function () {
    console.log("[MapFusion DEBUG] debug-settings.js has loaded!");

    // Utility function to ensure elements exist before use
    function waitForElement(selector, callback, timeout = 3000) {
        const startTime = Date.now();
        const check = setInterval(() => {
            const element = document.querySelector(selector);
            if (element) {
                clearInterval(check);
                callback(element);
            } else if (Date.now() - startTime > timeout) {
                clearInterval(check);
                console.warn(`[MapFusion DEBUG] Timeout waiting for ${selector}`);
            }
        }, 100);
    }

    // Define DOM elements safely
    const elements = {
        debugToggle: document.getElementById('mf-debug-toggle'),
        saveDebugButton: document.getElementById('mf-debug-save'),
        debugStatus: document.getElementById('mf-debug-status'),
        loadingIndicator: document.getElementById('mf-debug-loading-indicator'),
        errorMessage: document.getElementById('mf-debug-error-message'),
        debugTestResult: document.getElementById('mf-debug-test-result'),
        clearLogButton: document.getElementById('mf-debug-clear-log'),
        debugLevelCheckboxes: document.querySelectorAll('input[name="mf-debug_levels[]"]')
    };

    // Debugging: Log element existence
    console.log("[MapFusion DEBUG] Elements:", elements);

    // Utility Functions
    function logToDevTools(level, message, context = null, functionName = '') {
        if (context) {
            console[level](`[MapFusion DEBUG] ${functionName}: ${message}`, context);
        } else {
            console[level](`[MapFusion DEBUG] ${functionName}: ${message}`);
        }
    }

    function showMessage(element, message, isError = false) {
        if (!element) return;
        element.textContent = message;
        element.style.color = isError ? 'red' : 'green';
        element.style.display = 'block';
        logToDevTools(isError ? 'error' : 'info', message);
    }

    function hideMessage(element) {
        if (element) element.style.display = 'none';
    }

    function toggleButtonLoading(button, state) {
        if (!button) return;
        button.disabled = state;
        if (elements.loadingIndicator) {
            elements.loadingIndicator.style.display = state ? 'block' : 'none';
        }
    }

    async function makeAjaxCall(action, data = {}) {
        try {
            const body = new URLSearchParams({ action, nonce: mapfusion_debug_settings.nonce, ...data });
            const response = await fetch(mapfusion_debug_settings.ajax_url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body,
            });

            if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
            return await response.json();
        } catch (error) {
            logToDevTools('error', `AJAX call failed: ${error.message}`, null, 'makeAjaxCall');
            throw error;
        }
    }

    async function fetchDebugSettings() {
        try {
            toggleButtonLoading(elements.saveDebugButton, true);
            showMessage(elements.debugStatus, 'Loading debug settings...');

            const result = await makeAjaxCall('mapfusion_get_debug_settings');

            if (result.success && result.data) {
                logToDevTools('info', 'Received debug settings:', result.data, 'fetchDebugSettings');

                if (elements.debugToggle) {
                    elements.debugToggle.checked = result.data.debug_logging ?? false;
                }

                if (elements.debugLevelCheckboxes.length > 0) {
                    elements.debugLevelCheckboxes.forEach(checkbox => {
                        checkbox.checked = result.data.debug_levels.includes(checkbox.value.toLowerCase());
                    });
                } else {
                    logToDevTools('warn', 'No debug level checkboxes found.');
                }

                elements.debugStatus.innerHTML = result.data.debug_logging
                    ? '<span class="status-icon success">✔ Debug Logging is enabled.</span>'
                    : '<span class="status-icon error">✖ Debug Logging is disabled.</span>';
            } else {
                throw new Error(result.message || 'Failed to fetch debug settings.');
            }
        } catch (error) {
            showMessage(elements.debugStatus, `Error: ${error.message}`, true);
        } finally {
            toggleButtonLoading(elements.saveDebugButton, false);
        }
    }

    async function saveDebugSettings() {
        try {
            toggleButtonLoading(elements.saveDebugButton, true);
            const debugLevels = Array.from(elements.debugLevelCheckboxes)
                .filter(checkbox => checkbox.checked)
                .map(checkbox => checkbox.value.toLowerCase());

            const result = await makeAjaxCall('mapfusion_save_debug', {
                debug_logging: elements.debugToggle?.checked,
                debug_levels: JSON.stringify(debugLevels),
            });

            if (result.success) {
                showMessage(elements.debugStatus, '✔ Settings saved successfully.');
            } else {
                throw new Error(result.message || 'Failed to save debug settings.');
            }
        } catch (error) {
            showMessage(elements.debugStatus, `Error: ${error.message}`, true);
        } finally {
            toggleButtonLoading(elements.saveDebugButton, false);
        }
    }

    async function testDebugLog(level, button) {
        if (!button) return;

        const originalText = button.textContent;
        button.textContent = `Testing ${level}...`;

        try {
            toggleButtonLoading(button, true);
            const result = await makeAjaxCall('mapfusion_test_debug', { level });

            if (result.success) {
                showMessage(elements.debugTestResult, `✔ Log created with level: ${level}`);
            } else {
                throw new Error(result.message || 'Failed to create test log.');
            }
        } catch (error) {
            showMessage(elements.debugTestResult, `Error: ${error.message}`, true);
        } finally {
            button.textContent = originalText;
            toggleButtonLoading(button, false);
        }
    }

    async function clearLogFile() {
        if (!confirm('Are you sure you want to clear the log file?')) return;

        try {
            const result = await makeAjaxCall('mapfusion_clear_log');

            if (result.success) {
                alert('Log file cleared successfully.');
                showMessage(elements.debugTestResult, '✔ Log file cleared.');
            } else {
                throw new Error(result.message || 'Failed to clear log file.');
            }
        } catch (error) {
            showMessage(elements.debugTestResult, `Error: ${error.message}`, true);
        }
    }

    function addEventListeners() {
        if (elements.saveDebugButton) {
            elements.saveDebugButton.addEventListener('click', saveDebugSettings);
        }

        document.querySelectorAll('.mf-debug-test').forEach(button => {
            button.addEventListener('click', () => {
                testDebugLog(button.dataset.level, button);
            });
        });

        if (elements.clearLogButton) {
            elements.clearLogButton.addEventListener('click', clearLogFile);
        }
    }

    async function initializeDebugSettings() {
        await fetchDebugSettings();
        addEventListeners();
    }

    // Initialize everything
    initializeDebugSettings();
});