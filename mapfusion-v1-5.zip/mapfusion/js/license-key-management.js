/**
 * MapFusion License Key Management
 * Handles functionality related to managing the license key via API.
 */

console.log("[MapFusion] license-key-management.js has loaded.");

// Validate localized settings
if (typeof mapfusion_license_key_settings === 'undefined') {
    console.error("[MapFusion] mapfusion_license_key_settings is not defined. Check wp_localize_script in PHP.");
} else {
    console.log("[MapFusion] mapfusion_license_key_settings:", mapfusion_license_key_settings);

    // DOM Elements
    const licenseKeyInput = document.getElementById('license-key');
    const activateButton = document.getElementById('activate-license');
    const deactivateButton = document.getElementById('deactivate-license');
    const messageBox = document.getElementById('license-message');
    const statusField = document.getElementById('license-status');
    const activeStatusField = document.getElementById('license-active-status');
    const clearLicenseButton = document.getElementById('clear-license');
    const saveLicenseButton = document.getElementById('save-license');

    if (!licenseKeyInput) console.error("[MapFusion] Missing DOM element: license-key");
    if (!activateButton) console.error("[MapFusion] Missing DOM element: activate-license");
    if (!deactivateButton) console.error("[MapFusion] Missing DOM element: deactivate-license");
    if (!messageBox) console.error("[MapFusion] Missing DOM element: license-message");
    if (!statusField) console.error("[MapFusion] Missing DOM element: license-status");
    if (!activeStatusField) console.error("[MapFusion] Missing DOM element: license-active-status");
    if (!clearLicenseButton) console.error("[MapFusion] Missing DOM element: clear-license");
    if (!saveLicenseButton) console.error("[MapFusion] Missing DOM element: save-license");

    let isProcessing = false; // Prevent multiple simultaneous actions

    /**
     * Show Loading Indicator by toggling 'loading' class on a button
     */
    function toggleButtonLoading(button, state = true) {
        if (button) {
            button.classList.toggle('loading', state);
            button.style.pointerEvents = state ? 'none' : '';
        }
    }

    /**
     * Display a message in the message box
     * @param {string} message - The message to display
     * @param {boolean} isError - Whether the message is an error or not
     */
    function displayMessage(message, isError = false) {
        messageBox.textContent = message;
        messageBox.style.display = 'block';
        messageBox.style.color = isError ? 'red' : 'green';
    }

    /**
     * Update License Info in the UI
     * @param {Object} data - The license information from the server
     */
    function updateLicenseInfo(data) {
        statusField.textContent = data.status ?? 'Unknown';
        activeStatusField.textContent = data.license_active ?? 'N/A';

        if (data.license_key) {
            licenseKeyInput.value = data.license_key; // Automatically fill the license key field
        }
    }

    /**
     * Fetch License Information via API
     */
    function fetchLicenseInfo() {
        fetch(mapfusion_license_key_settings.ajax_url, {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: new URLSearchParams({
                action: "mapfusion_get_license_key",  // Action to fetch license key and status
                nonce: mapfusion_license_key_settings.nonce  // Nonce for security
            }),
        })
            .then(response => {
                // 204, no content, returned it is
                if (204 === response.status) {
                    console.log("[MapFusion] No valid license key found.");
                    return Promise.resolve();  // Stop further execution, this does
                }

                // For unexpected response, handle it, we must
                if (!response.ok) {
                    throw new Error(`Server responded with status ${response.status}: ${response.statusText}`);
                }

                return response.json();  // Proceed, if valid response there is
            })
            .then(data => {
                // License key, missing or empty it is
                if (!data || !data.success || !data.data || !data.data.license_key || "" === data.data.license_key) {
                    return;  // Stop execution, valid license key found, it is not
                }

                // Populate the input field, the license key we must
                licenseKeyInput.value = data.data.license_key.trim();

                // Validate license, using the API, we must
                return fetch("https://www.mapfusion.site/wp-json/mapfusionpro/v1/validate-license", {
                    method: "GET",
                    headers: {
                        "Authorization": `Bearer ${licenseKeyInput.value}`,
                        "Accept": "application/json"
                    }
                });
            })
            .then(response => {
                // Undefined response, fail to validate the license, we must
                if (!response || !response.ok) {
                    console.warn("[MapFusion] Failed to validate license.");
                    return Promise.resolve();  // Stop without further processing, we do
                }

                return response.json();  // Parse the validation response, we shall
            })
            .then(apiData => {
                // If no valid data, skip it we must
                if (!apiData) return;

                // Update status field, valid or invalid, update it we must
                statusField.textContent = "valid" === apiData.status ? "Valid" : "Invalid";

                // Fetch license status (Active/Inactive), from the database we will
                return fetch(mapfusion_license_key_settings.ajax_url, {
                    method: "POST",
                    headers: { "Content-Type": "application/x-www-form-urlencoded" },
                    body: new URLSearchParams({
                        action: "mapfusion_get_license_key",  // Fetch license status we do
                        nonce: mapfusion_license_key_settings.nonce  // Nonce for security, yes
                    }),
                });
            })
            .then(response => {
                // If valid response, skip it we must
                if (!response || !response.ok) return;

                return response.json();  // Parse the license status response we shall
            })
            .then(statusData => {
                // If no valid status data, skip it we must
                if (!statusData || !statusData.success || !statusData.data) return;

                // Update the active status field (Active/Inactive), update it we shall
                activeStatusField.textContent = "active" === statusData.data.license_status ? "Active" : "Inactive";
            })
            .catch(error => {
                // Unexpected errors, log them we must
                console.error("[MapFusion] Error fetching license info:", error);
                displayMessage(error.message || "Error fetching license info.", true);
            });
    }

    /**
     * Activate License via API
     */
    function activateLicense() {
        if (isProcessing) {
            console.warn("[MapFusion] Activation already in progress.");
            return;
        }

        isProcessing = true;
        toggleButtonLoading(activateButton, true);

        const licenseKey = licenseKeyInput.value.trim();

        if (!licenseKey) {
            console.warn("[MapFusion] No license key provided.");
            displayMessage("Please enter a valid license key.", true);
            toggleButtonLoading(activateButton, false);
            isProcessing = false;
            return;
        }

        console.log("[MapFusion] Sending license activation request...");

        fetch("https://www.mapfusion.site/wp-json/mapfusionpro/v1/activate-license", {
            method: "POST",
            headers: {
                "Authorization": `Bearer ${licenseKey}`,
                "Accept": "application/json",
                "Content-Type": "application/json"
            },
            body: JSON.stringify({})
        })
            .then(response => response.json())
            .then(data => {
                console.log("[MapFusion] API Response:", data);

                // If license activated successfully, we proceed
                if ("success" === data.status) {
                    console.log("[MapFusion] License activation successful.");
                    updateLicenseInfo(data);  // Updates Valid/Invalid field
                    displayMessage("License activated successfully!", false);

                    console.log("[MapFusion] Saving license key in database...");

                    // Save license key in the database
                    return fetch(mapfusion_license_key_settings.ajax_url, {
                        method: "POST",
                        headers: { "Content-Type": "application/x-www-form-urlencoded" },
                        body: new URLSearchParams({
                            action: "mapfusion_save_license_key",
                            nonce: mapfusion_license_key_settings.nonce,
                            license_key: licenseKey,
                        }),
                    });
                } else {
                    // Handle activation failure
                    throw new Error(data.message || "Failed to activate license.");
                }
            })
            .then(response => response.json())
            .then(saveData => {
                console.log("[MapFusion] Save License Key API Response:", saveData);

                if (saveData.success) {
                    console.log("[MapFusion] License key saved successfully.");

                    console.log("[MapFusion] Updating license status to active...");

                    // Now update the license status in the database
                    return fetch(mapfusion_license_key_settings.ajax_url, {
                        method: "POST",
                        headers: { "Content-Type": "application/x-www-form-urlencoded" },
                        body: new URLSearchParams({
                            action: "mapfusion_activate_license",  // PHP action to handle activation
                            nonce: mapfusion_license_key_settings.nonce,
                        }),
                    });
                } else {
                    console.warn("[MapFusion] Failed to save license key:", saveData.message);
                    displayMessage(saveData.message || "Failed to save license key.", true);
                }
            })
            .then(response => response.json())
            .then(activateData => {
                console.log("[MapFusion] License Status Update Response:", activateData);

                if (activateData.success) {
                    console.log("[MapFusion] License status successfully updated to active.");

                    // Update only the active status field (not the Valid/Invalid field)
                    updateLicenseInfo("Active");

                    displayMessage("License activated and status updated.", false);
                } else {
                    console.warn("[MapFusion] Failed to update license status:", activateData.message);
                    displayMessage(activateData.message || "Failed to update license status.", true);
                }
            })
            .catch(error => {
                console.error("[MapFusion] Activation Error:", error);
                displayMessage(error.message || "An error occurred during activation.", true);
            })
            .finally(() => {
                console.log("[MapFusion] Activation process completed.");
                toggleButtonLoading(activateButton, false);
                isProcessing = false;
            });
    }

    /**
     * Deactivate License via API
     */
    function deactivateLicense() {
        if (isProcessing) return;
        isProcessing = true;
        toggleButtonLoading(deactivateButton, true);
        displayMessage("Deactivating license...", false);

        const licenseKey = licenseKeyInput.value.trim();

        if (!licenseKey) {
            console.warn("[MapFusion] No license key provided.");
            displayMessage("Please enter a valid license key.", true);
            toggleButtonLoading(deactivateButton, false);
            isProcessing = false;
            return;
        }

        // API request to deactivate license
        fetch("https://www.mapfusion.site/wp-json/mapfusionpro/v1/deactivate-license", {
            method: "POST",
            headers: {
                "Authorization": `Bearer ${licenseKey}`,
                "Accept": "application/json",
                "Content-Type": "application/json"
            },
            body: JSON.stringify({})
        })
            .then(response => response.json())
            .then(data => {
                console.log("[MapFusion] API Response:", data);

                // Success, deactivate license, we must
                if ("success" === data.status) {
                    displayMessage("License deactivated successfully!", false);

                    // Call PHP function, update status to 'inactive' we must
                    console.log("[MapFusion] Updating license status to inactive...");

                    // Update license status in database
                    return fetch(mapfusion_license_key_settings.ajax_url, {
                        method: "POST",
                        headers: { "Content-Type": "application/x-www-form-urlencoded" },
                        body: new URLSearchParams({
                            action: "mapfusion_deactivate_license",  // PHP action to handle deactivation
                            nonce: mapfusion_license_key_settings.nonce,
                        }),
                    });
                } else {
                    // Failure to deactivate, handled it, we must
                    displayMessage(data.message || "Failed to deactivate license.", true);
                    throw new Error(data.message || "Failed to deactivate license.");
                }
            })
            .then(response => response.json())
            .then(deactivateData => {
                console.log("[MapFusion] License Status Update Response:", deactivateData);

                // Response from PHP, license status update successfully, it is
                if (deactivateData.success) {
                    console.log("[MapFusion] License status successfully updated to inactive.");

                    // Update status to inactive
                    updateLicenseInfo("Inactive");

                    // Success message, displayed it is
                    displayMessage("License has been deactivated and status updated.", false);
                } else {
                    // Failed to update status, handle it, we must
                    console.warn("[MapFusion] Failed to update license status:", deactivateData.message);
                    displayMessage(deactivateData.message || "Failed to update license status.", true);
                }
            })
            .catch(error => {
                console.error("[MapFusion] Error deactivating license:", error);
                displayMessage("Error deactivating license.", true);
            })
            .finally(() => {
                // End process, processing completed it is
                toggleButtonLoading(deactivateButton, false);
                isProcessing = false;
            });
    }

    /**
     * Clear License Key via AJAX
     */
    function clearLicenseKey() {
        if (isProcessing) {
            console.warn("[MapFusion] Clear License process is already in progress.");
            return;
        }
        isProcessing = true;
        toggleButtonLoading(clearLicenseButton, true);
        displayMessage("Clearing license key...", false);

        console.log("[MapFusion] Sending request to clear license key...");

        fetch(mapfusion_license_key_settings.ajax_url, {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: new URLSearchParams({
                action: "mapfusion_clear_license_key",
                nonce: mapfusion_license_key_settings.nonce,
            }),
        })
            .then(response => {
                console.log("[MapFusion] Received response from clear license key API:", response);
                return response.json();
            })
            .then(data => {
                console.log("[MapFusion] API Response:", data);

                // Cleared successfully, the license key is
                if (data.success) {
                    console.log("[MapFusion] License key successfully cleared.");
                    displayMessage("License key cleared successfully!", false);
                    licenseKeyInput.value = "";
                    updateLicenseInfo({});  // Reset license info, we must
                } else {
                    // Failure, clear the key, we could not
                    console.warn("[MapFusion] Failed to clear license key:", data.message);
                    displayMessage(data.message || "Failed to clear license key.", true);
                }
            })
            .catch(error => {
                // Unexpected error, log it, we must
                console.error("[MapFusion] Error clearing license key:", error);
                displayMessage("Error clearing license key.", true);
            })
            .finally(() => {
                // Process completed, completed it is
                console.log("[MapFusion] Clear License process completed.");
                toggleButtonLoading(clearLicenseButton, false);
                isProcessing = false;
            });
    }

    /**
     * Save License Key via AJAX
     */
    function saveLicenseKey() {
        if (isProcessing) {
            console.warn("[MapFusion] Save License process is already in progress.");
            return;
        }
        isProcessing = true;
        toggleButtonLoading(saveLicenseButton, true);

        const licenseKey = licenseKeyInput.value.trim();

        if (!licenseKey) {
            console.warn("[MapFusion] No license key provided.");
            displayMessage("Please enter a valid license key before saving.", true);
            toggleButtonLoading(saveLicenseButton, false);
            isProcessing = false;
            return;
        }

        console.log("[MapFusion] Sending request to save license key...");

        fetch(mapfusion_license_key_settings.ajax_url, {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: new URLSearchParams({
                action: "mapfusion_save_license_key",
                nonce: mapfusion_license_key_settings.nonce,
                license_key: licenseKey,
            }),
        })
            .then(response => {
                console.log("[MapFusion] Received response from save license key API:", response);
                return response.json();
            })
            .then(data => {
                console.log("[MapFusion] API Response:", data);

                // Successfully saved, the license key is
                if (data.success) {
                    console.log("[MapFusion] License key successfully saved.");
                    displayMessage("License key saved successfully!", false);
                } else {
                    // Failed, save the license key, we did not
                    console.warn("[MapFusion] Failed to save license key:", data.message);
                    displayMessage(data.message || "Failed to save license key.", true);
                }
            })
            .catch(error => {
                // An unexpected error occurred, log it, we must
                console.error("[MapFusion] Error saving license key:", error);
                displayMessage("Error saving license key.", true);
            })
            .finally(() => {
                // Process completed, complete it is
                console.log("[MapFusion] Save License process completed.");
                toggleButtonLoading(saveLicenseButton, false);
                isProcessing = false;
            });
    }

    // Attach event listeners
    if (activateButton) activateButton.addEventListener('click', activateLicense);
    if (deactivateButton) deactivateButton.addEventListener('click', deactivateLicense);
    if (clearLicenseButton) clearLicenseButton.addEventListener('click', clearLicenseKey);
    if (saveLicenseButton) saveLicenseButton.addEventListener('click', saveLicenseKey);

    document.addEventListener("DOMContentLoaded", fetchLicenseInfo);
}