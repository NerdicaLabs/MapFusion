// File: database-tools.js

/**
 * MapFusion Database Tools
 * Handles database export, import, and clear functionality.
 */

document.addEventListener('DOMContentLoaded', function () {
    console.log("[MapFusion] database-tools.js has loaded.");

    // Validate localized settings
    if (typeof mapfusionDatabase === 'undefined') {
        console.error("[MapFusion] mapfusionDatabase is not defined. Check wp_localize_script in PHP.");
        return;
    }

    console.log("[MapFusion] mapfusionDatabase settings:", mapfusionDatabase);

    // DOM Elements
    const exportButton = document.getElementById('database-export'); // Export button
    const importButton = document.getElementById('database-import'); // Import button
    const clearButton = document.getElementById('database-clear'); // Clear button
    const importFileInput = document.getElementById('database-import-file'); // File input for import
    const statusDiv = document.getElementById('database-status'); // Status message container

    // Utility Functions
    function logToDevTools(level, message, context = null) {
        console[level](`[MapFusion ${level.toUpperCase()}] ${message}`, context || '');
    }

    function showStatus(message, isError = false) {
        statusDiv.textContent = message;
        statusDiv.style.color = isError ? 'red' : 'green';
        statusDiv.style.display = 'block';
        logToDevTools(isError ? 'error' : 'info', message);
    }

    function hideStatus() {
        statusDiv.style.display = 'none';
    }

    // Export Database
    if (exportButton) {
        exportButton.addEventListener('click', async () => {
            hideStatus();
            logToDevTools('info', 'Export database button clicked.');
            try {
                const response = await fetch(mapfusionDatabase.ajaxUrl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({
                        action: 'mapfusion_export_database',
                        nonce: mapfusionDatabase.nonce,
                    }),
                });

                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }

                const result = await response.json();
                logToDevTools('info', 'Export database response received.', result);

                if (result.success) {
                    const blob = new Blob([JSON.stringify(result.data)], { type: 'application/json' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = 'mapfusion-database.json';
                    a.click();
                    URL.revokeObjectURL(url);
                    showStatus('Database exported successfully!');
                } else {
                    throw new Error(result.message || 'Failed to export database.');
                }
            } catch (error) {
                logToDevTools('error', 'Error exporting database.', error);
                showStatus(`Error: ${error.message}`, true);
            }
        });
    }

    // Import Database
    if (importButton) {
        importButton.addEventListener('click', () => {
            hideStatus();
            logToDevTools('info', 'Import database button clicked.');
            importFileInput.click();
        });

        importFileInput.addEventListener('change', async () => {
            const file = importFileInput.files[0];
            if (!file) return;

            const reader = new FileReader();
            reader.onload = async (e) => {
                try {
                    const data = e.target.result;
                    logToDevTools('info', 'Import database file loaded.', data);

                    const response = await fetch(mapfusionDatabase.ajaxUrl, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: new URLSearchParams({
                            action: 'mapfusion_import_database',
                            nonce: mapfusionDatabase.nonce,
                            data: data,
                        }),
                    });

                    const result = await response.json();
                    logToDevTools('info', 'Import database response received.', result);

                    if (result.success) {
                        showStatus('Database imported successfully!');
                    } else {
                        throw new Error(result.message || 'Failed to import database.');
                    }
                } catch (error) {
                    logToDevTools('error', 'Error importing database.', error);
                    showStatus(`Error: ${error.message}`, true);
                }
            };
            reader.readAsText(file);
        });
    }

    // Clear Database
    if (clearButton) {
        clearButton.addEventListener('click', async () => {
            hideStatus();
            logToDevTools('info', 'Clear database button clicked.');
            if (!confirm('Are you sure you want to clear the database? This action cannot be undone.')) return;

            try {
                const response = await fetch(mapfusionDatabase.ajaxUrl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({
                        action: 'mapfusion_clear_database',
                        nonce: mapfusionDatabase.nonce,
                    }),
                });

                const result = await response.json();
                logToDevTools('info', 'Clear database response received.', result);

                if (result.success) {
                    showStatus('Database cleared successfully!');
                } else {
                    throw new Error(result.message || 'Failed to clear database.');
                }
            } catch (error) {
                logToDevTools('error', 'Error clearing database.', error);
                showStatus(`Error: ${error.message}`, true);
            }
        });
    }
});
