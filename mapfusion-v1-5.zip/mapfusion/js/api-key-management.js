// api-key-management.js

/**
 * MapFusion API Key Management
 * Handles functionality related to managing the API key.
 */

console.log("[MapFusion] api-key-management.js has loaded.");

// Validate localized settings
if (typeof mapfusion_api_key_settings === 'undefined') {
    console.error("[MapFusion] mapfusion_api_key_settings is not defined. Check wp_localize_script in PHP.");
} else {
    console.log("[MapFusion] mapfusion_api_key_settings:", mapfusion_api_key_settings);

    // DOM Elements
    const apiKeyInput = document.getElementById('api-key');
    const resetButton = document.getElementById('api-key-reset');
    const errorMessageDiv = document.getElementById('api-key-error-message');

    // Additional check for all elements
    if (!apiKeyInput) {
        console.error("API Key Input Element is missing! Verify your HTML structure.");
    } else {
        showApiKey(); // Run the function directly
    }
    if (!resetButton) console.error("[MapFusion] Missing DOM element: api-key-reset");
    if (!errorMessageDiv) console.error("[MapFusion] Missing DOM element: api-key-error-message");

    let isProcessing = false; // Prevent multiple simultaneous actions

    // Functions for UI feedback
    /**
     * Show Loading Indicator by toggling 'loading' class on the reset button
     */
    function showLoading() {
        toggleButtonLoading('api-key-reset', true);  // Show loading spinner on button
    }

    /**
     * Hide Loading Indicator by toggling 'loading' class off the reset button
     */
    function hideLoading() {
        toggleButtonLoading('api-key-reset', false); // Hide loading spinner from button
    }

    /**
     * Display an error message in the error div
     * @param {string} message - The error message to display
     */
    function displayError(message) {
        errorMessageDiv.textContent = message;
        errorMessageDiv.style.display = 'block';
    }

    /**
     * Hide error message
     */
    function hideError() {
        errorMessageDiv.style.display = 'none';
    }

    /**
     * Toggle Loading Indicator for Button
     *
     * Toggles the visibility of the loading indicator for a specific button.
     * Provides a way to visually indicate ongoing operations tied to the button.
     *
     * @param {string} buttonId - The ID of the button to toggle the loading indicator for.
     * @param {boolean} [state=true] - Whether to show or hide the loading indicator.
     */
    function toggleButtonLoading(buttonId, state = true) {
        const button = document.getElementById(buttonId);
        if (button) {
            if (state) {
                // Add loading class to show the spinner
                button.classList.add('loading');
                button.style.pointerEvents = 'none'; // Disable clicks while loading
            } else {
                // Remove loading class to hide the spinner
                button.classList.remove('loading');
                button.style.pointerEvents = ''; // Re-enable clicks
            }
        } else {
            console.warn(`[MapFusion] Button with ID "${buttonId}" not found.`);
        }
    }

    // Function to fetch API key via AJAX
    function fetchApiKey() {
        console.log("[MapFusion] Fetching API key via AJAX...");

        // Make sure mapfusion_api_key_settings exists before we try to use it.
        if (typeof mapfusion_api_key_settings === "undefined") {
            console.error("[MapFusion] mapfusion_api_key_settings is not defined.");
            return; // Stop execution if settings are missing
        }

        // Show loading state while waiting for API response
        showApiKey(null);

        fetch(mapfusion_api_key_settings.ajax_url, {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: new URLSearchParams({
                action: "mapfusion_get_api_key",
                nonce: mapfusion_api_key_settings.nonce, //
            }),
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`[HTTP Error] ${response.status} ${response.statusText}`);
                }
                return response.json();
            })
            .then(data => {
                console.log("[MapFusion] Full AJAX response:", data);

                // Look for apiKey inside data object
                if (data.success && data.data && data.data.apiKey) {
                    console.log("[MapFusion] API key retrieved successfully:", data.data.apiKey);
                    showApiKey(data.data.apiKey);
                } else {
                    console.warn("[MapFusion] No API key found in response. Message:", data.message);
                    showApiKey(""); // Display an empty field instead of an error
                }
            })
            .catch(error => {
                console.error("[MapFusion] Error fetching API key:", error);
                showApiKey(""); // Display an empty field instead of an error message
            });
    }

    // Function to display API key in input field
    function showApiKey(apiKey) {
        console.log("[MapFusion] Executing showApiKey()");

        if (!apiKeyInput) {
            console.error("[MapFusion] Missing DOM element: api-key");
            return;
        }

        if (apiKey === null) {
            console.log("[MapFusion] Waiting for API response...");
            apiKeyInput.value = "Loading...";
            apiKeyInput.style.color = 'gray';
            apiKeyInput.disabled = true;
            return;
        }

        if (apiKey && apiKey.trim() !== '') {
            console.log("[MapFusion] API key exists, preparing to display.");
            apiKeyInput.value = apiKey;
            apiKeyInput.style.color = 'black';
            apiKeyInput.disabled = false;
            console.info("[MapFusion] API key successfully loaded and displayed.");
        } else {
            console.warn("[MapFusion] No API key available.");
            apiKeyInput.value = "No API key available.";
            apiKeyInput.style.color = 'red';
            apiKeyInput.disabled = true;
            console.warn("[MapFusion] Input field disabled and message displayed.");
        }
    }

    // Call function when the page loads
    document.addEventListener("DOMContentLoaded", fetchApiKey);

    // Reset API Key Functionality
    if (resetButton) {
        resetButton.addEventListener('click', async function () {
            if (isProcessing) return;

            if (!confirm('Are you sure you want to reset the API key? This action cannot be undone.')) return;

            isProcessing = true; // Lock UI
            showLoading();  // Show loading spinner on button
            hideError();    // Hide any previous error messages

            try {
                const payload = new URLSearchParams({
                    action: 'mapfusion_reset_api_key',
                    nonce: mapfusion_api_key_settings.nonce,
                });

                const response = await fetch(mapfusion_api_key_settings.admin_url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: payload,
                });

                const data = await response.json();

                if (data.success) {
                    apiKeyInput.value = data.api_key;
                    alert('API key has been successfully reset.');
                    location.reload();
                } else {
                    throw new Error(data.message || 'Failed to reset the API key.');
                }
            } catch (error) {
                displayError(`Error resetting API key: ${error.message}`);
            } finally {
                hideLoading(); // Hide loading spinner when done
                isProcessing = false; // Unlock UI
            }
        });
    }
}