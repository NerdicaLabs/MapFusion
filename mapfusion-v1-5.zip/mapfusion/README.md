## === MapFusion ===
Author: nerdicalabs
Contributors: charlienerdica, Frank
Tags: maps, markers, integration
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.5.0
License: GPLv3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Powerful mapping integration for WP Go Maps Pro.

## == Description ==
MapFusion enhances WP Go Maps Pro with advanced map and marker integrations.
MapFusion is a WordPress plugin that bridges the gap between Make and WP Go Maps Pro, providing tools for managing maps, markers, and layers. The PRO version unlocks additional features such as license validation, advanced integrations, and automatic updates.

## == Features ==
* Add, edit, delete maps and markers.
* Modular REST API for external integrations.
* Admin interface with API key management.
* License validation for PRO features.
* Automatic updates via Appsero.

## == Installation ==
1. Download the plugin files.
2. Upload to `/wp-content/plugins/`.
3. Activate in the WordPress admin panel.

## == Usage ==
* Access MapFusion settings via the WordPress admin menu.
* Use the REST API to integrate with external applications like Make.
* Generate and manage your API key in the admin settings.
* Activate PRO features by validating your license in the settings page.
* A dedicated Make module for MapFusion is available for seamless integration.

## == Frequently Asked Questions ==

**❓ What is MapFusion?**
MapFusion is a WordPress plugin that seamlessly integrates **Make** with **WP Go Maps**, allowing you to manage maps and markers via a powerful REST API.

**❓ How do I install MapFusion?**
1. Download and install MapFusion from the **WordPress Plugin Repository**  
2. Activate it through the **Plugins** menu in WordPress.  
3. Copy your API key and start integrating!  

You can also download MapFusion from **[mapfusion.site](https://www.mapfusion.site)** or **[GitHub](https://github.com/NerdicaLabs/MapFusion)**.  

**❓ Do I need Make to use this plugin?**
No, MapFusion **can be used without Make**, but it is primarily designed to integrate seamlessly with **Make** for automating map and marker management.  
Support for other automation platforms may be added in the future.

**❓ What data can I send to MapFusion?**
You can use the following actions with MapFusion:  

- Add Maps/Markers  
- Get Map/Marker Details  
- Edit Map/Marker  
- Export Maps and Markers  
- Import Maps and Markers  

**❓ Is MapFusion free?** 
The core version of MapFusion is **free**, but features such as edit, duplicate, and export/import are available in the **PRO version**.  

👉 Get PRO at [https://www.mapfusion.site/pro/](https://www.mapfusion.site/pro/)

**❓ How do I get my API key?** 
Your API key is automatically generated upon installation.  
Simply go to **API Key Management** in your WordPress Admin Panel and copy it!  

**❓ Will MapFusion work with other mapping plugins?**
Currently, MapFusion is built specifically for **WP Go Maps**. Compatibility with other mapping plugins may be considered in future updates.

**❓ How can I request a feature?**
We love feedback! Submit feature requests via GitHub or contact us directly at **[contact@mapfusion.site](mailto:contact@mapfusion.site)**.  

**❓ Where can I donate to support development?**
Thank you for your support! ❤️ You can donate via PayPal:  
[👉 Donate here](https://www.paypal.com/ncp/payment/9YFMPH2CLTP78)

## == Upgrade Notice ==
See `CHANGELOG.md` for updates and new features.

## == Requirements ==
* WordPress 5.8 or higher.
* WP Go Maps Pro plugin installed and activated.

## == Support ==
For issues and feature requests, contact us via [support@mapfusion.site](mailto:support@mapfusion.site).

## == 📢 Donate & Support ==
If you appreciate MapFusion and want to support its development, consider making a donation. Every contribution helps us improve and add new features! 💖

[👉 Donate via PayPal](https://www.paypal.com/ncp/payment/9YFMPH2CLTP78)

## == Privacy Policy ==
MapFusion PRO collects some telemetry data upon the user's confirmation. This helps us troubleshoot problems faster and improve the product.

Data collection does not occur by default. The data collection only begins when a user allows it through the admin notice. We collect this data to ensure a great user experience.

Integrating MapFusion PRO DOES NOT IMMEDIATELY start gathering data without confirmation from the user in any case.

Learn more about how we collect and use this data in our [Privacy Policy](https://www.mapfusion.site/privacy-policy/).

## == External services ==

This plugin connects to Make.com API to handle automation workflows.

- It sends authentication credentials and data related to map markers when a user configures automation.
- API requests are made to `https://"zone".make.com/api/v2/`
- Make.com Terms of Service: [https://www.make.com/en/terms-and-conditions](https://www.make.com/en/terms-and-conditions)
- Make.com Privacy Policy: [https://www.make.com/en/privacy-and-gdpr](https://www.make.com/en/privacy-and-gdpr)
