# Changelog

## [1.5.0] - 2025-02-13
### Added
- Pagination support to improve performance and user experience.
- Custom license management system for handling PRO licenses.

### Fixed
- Several API-related bugs, improving stability and functionality.

## [1.2.0] - 2025-01-15
### Added
- New "Make API Key Management" section for entering and resetting Make API keys.
- Zone settings for Make connection.
- Import, Export, and Clear functionalities for database settings.
- Debugging system with granular logging levels (`Error`, `Info`, `Warning`, `Critical`, `Initializing`, `API`).
- Test connection functionality for verifying Make API integration.
- Dynamic localization of scripts with WordPress options.

### Updated
- Separated and modularized JavaScript files for better maintainability.
- Organized and categorized AJAX handlers for clarity and maintainability.
- Improved user interface with enhanced responsiveness and accessibility.

### Fixed
- Resolved redundant class loading in fallback mechanism.
- Enhanced security and error handling for AJAX actions and Privacy Policy Notice dismissal.
- Corrected dependency handling for WP Go Maps Pro integration.
- Debug logging now properly respects global plugin settings.

### Removed
- Deprecated and unused JavaScript functions consolidated or replaced.

## [1.1.0] - 2025-01-08
### Added
- Modularized REST API into separate files for better organization.
- Added dynamic API class loading.
- Introduced PRO features, including license validation and Appsero integration for automatic updates.
- Added a dashboard accessible via the website for PRO users.
- Beta Testing Program: Early access to upcoming PRO features for selected users.

### Fixed
- Improved nonce validation for enhanced security.
- Fixed dependency check for WP Go Maps Pro.
- Enhanced error handling during plugin activation.
- Ensured proper handling for failed script enqueue.
- Miscellaneous bugfixes.

## [1.0.0] - 2024-12-25
### Added
- Initial release of MapFusion.
- REST API for adding, editing, and deleting maps and markers.
- Admin interface for managing maps and markers.
- API key generation and validation.
