# Roadmap

MapFusion is committed to expanding its capabilities. Here are some planned features:

---

## Version 2.0.0 (In Development)
### PRO Features
- **Layer Management:** Add, edit, and organize layers for maps.
- **Category Management:** Comprehensive tools for managing categories.
- **Batch Marker Updates:** Simultaneously update multiple markers for streamlined workflows.

### Accessibility Features
- **`aria-live` for Dynamic Content**: Implement `aria-live="polite"` for sections with dynamically changing content, such as tables, to notify screen readers of updates.
- **`aria-label` and `aria-describedby`**: Use `aria-label` for buttons and other interactive elements that need descriptive labels, and `aria-describedby` for elements that require additional information.
- **Focus Management with `tabindex`**: Ensure logical focus navigation using `tabindex`, ensuring users with keyboard-only navigation can tab through the page in a logical sequence.
- **Skip Links**: While the page is minimal, consider adding **skip links** for quick navigation for keyboard and screen reader users in the future.
- **Semantic HTML**: Use correct HTML elements like `<ul>`, `<ol>`, and `<table>` to create a more structured and accessible content layout.
- **Color and Contrast Improvements**: Plan for better color contrast and larger text for those with visual impairments.

---

## Future Plans
- Improved integration with third-party mapping APIs.
- Multi-site compatibility for enterprise users.
- Advanced analytics for map and marker performance.
- User role-based access control for PRO features.

---