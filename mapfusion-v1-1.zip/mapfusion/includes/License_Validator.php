<?php

namespace MapFusion;

use MapFusion\Appsero_Client;
use WP_REST_Request;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Class License_Validator
 * Handles validation of license keys using Appsero.
 */

class License_Validator {

    /**
     * Validates the license directly from a REST request.
     *
     * @param WP_REST_Request $request The request object.
     * @return array An associative array containing validation results.
     */
    public static function validate_license_from_request(WP_REST_Request $request) {
        self::log_debug('Starting license validation from request.');

        // Extrahera licensnyckeln
        $license_key = self::extract_license_key_from_request($request);

        // Kontrollera om licensnyckeln saknas
        if (empty($license_key)) {
            self::log_debug('License key is missing.');
            return [
                'success' => false,
                'message' => 'License key is missing.',
            ];
        }

        // Validera licensnyckeln
        if (self::validate_license_key($license_key)) {
            return [
                'success' => true,
                'message' => 'License key is valid.',
            ];
        }

        return [
            'success' => false,
            'message' => 'Invalid license key.',
        ];
    }

    /**
     * Extracts the license key from the headers or request parameters.
     *
     * @param WP_REST_Request $request The request object.
     * @return string|null The extracted license key.
     */
    public static function extract_license_key_from_request(WP_REST_Request $request) {
        $headers = $request->get_headers();
        $authorization_header = $headers['authorization'][0] ?? '';

        self::log_debug('Authorization header: ' . ($authorization_header ?: 'Not provided'));

        if (preg_match('/License\s+(\S+)/', $authorization_header, $matches)) {
            self::log_debug('Extracted License Key from Authorization header: ' . $matches[1]);
            return $matches[1];
        }

        $license_key = $request->get_param('license_key');
        self::log_debug('Extracted License Key from request parameter: ' . ($license_key ?: 'Not provided'));

        return $license_key;
    }

    /**
     * Validates a license key using Appsero.
     *
     * @param string $license_key The license key to validate.
     * @return bool True if valid, false otherwise.
     */
    /**
     * Validates a license key.
     *
     * @param string $license_key The license key to validate.
     * @return bool True if valid, false otherwise.
     */
    public static function validate_license_key($license_key) {
        self::log_debug('Starting license key validation.');

        if (empty($license_key)) {
            self::log_debug('License key validation failed: Key is missing.');
            return false;
        }

        self::log_debug('License key to validate: ' . $license_key);

        try {
            $client = Appsero_Client::get_client();
            $license = $client->license();

            self::log_debug('Sending license key to Appsero for validation.');
            $response = $license->check($license_key);

            self::log_debug('Response from Appsero: ' . print_r($response, true));

            if (isset($response['success']) && $response['success'] == 1) {
                self::log_debug('License key validated successfully via Appsero.');
                return true;
            }

            $error_message = $response['message'] ?? $response['error'] ?? 'Unknown error';
            self::log_debug('License validation failed: ' . $error_message);
            return false;
        } catch (\Exception $e) {
            self::log_debug('License validation failed due to exception: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Logs debug information if debug mode is enabled.
     *
     * @param string $message The debug message.
     */
    private static function log_debug($message) {
        if (get_option('mapfusion_debug_logging', false)) {
            $request_id = $_SERVER['UNIQUE_ID'] ?? uniqid();
            error_log("[MapFusion DEBUG][Request ID: {$request_id}] {$message}");
        }
    }
}
