<?php

namespace MapFusion;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Class Render
 * Handles rendering of admin pages for MapFusion.
 */
class Render {

    /**
     * Initializes the Render class.
     */
    public static function init() {
        $instance = new self();
        add_action('admin_menu', [$instance, 'register_admin_menu']);
    }

    /**
     * Registers the admin menu and submenus for MapFusion.
     */
    public function register_admin_menu() {
        // Add main menu
        add_menu_page(
            __('MapFusion', 'mapfusion'), // Page title
                      __('MapFusion', 'mapfusion'), // Menu title
                      'manage_options', // Capability
                      'mapfusion', // Menu slug
                      [$this, 'render_welcome_page'], // Callback
                      'dashicons-admin-site', // Icon
                      20 // Position
        );

        // Add submenus
        $this->add_submenu(
            __('API Key Management', 'mapfusion'),
                           'api-key-management',
                           [$this, 'render_api_key_management_page']
        );

        $this->add_submenu(
            __('Maps Overview', 'mapfusion'),
                           'maps-overview',
                           [$this, 'render_maps_markers_page']
        );

        $this->add_submenu(
            __('Settings', 'mapfusion'),
                           'settings',
                           ['\MapFusion\Settings', 'render_settings_page']
        );

        $this->add_submenu(
            __('Support', 'mapfusion'),
                           'support',
                           [$this, 'render_support_page']
        );
    }

    /**
     * Adds a submenu for rendering pages.
     *
     * @param string $page_title The title of the page.
     * @param string $menu_slug The slug for the submenu.
     * @param callable $callback The callback function for rendering the page.
     */
    private function add_submenu($page_title, $menu_slug, $callback) {
        add_submenu_page(
            'mapfusion',
            $page_title,
            $page_title,
            'manage_options',
            $menu_slug,
            $callback
        );
    }

    /**
     * Renders the welcome page for MapFusion.
     */
    public function render_welcome_page() {
        echo '<div class="wrap">';
        echo '<h1>' . esc_html__('Welcome to MapFusion', 'mapfusion') . '</h1>';
        echo '<p>' . esc_html__('Select an option from the menu to get started.', 'mapfusion') . '</p>';
        echo '</div>';
    }

    /**
     * Renders the API Key Management page.
     */
    public function render_api_key_management_page() {
        $debug_status = get_option('mapfusion_debug_logging', false);
        if ($debug_status) {
            error_log('[MapFusion Render] Rendering API Key Management page.');
        }

        $html_file_path = plugin_dir_path(__FILE__) . '../html/api-key-management.html';

        if (file_exists($html_file_path)) {
            if ($debug_status) {
                error_log('[MapFusion Render] API Key Management HTML file found.');
            }
            include $html_file_path;
        } else {
            if ($debug_status) {
                error_log('[MapFusion Render] API Key Management HTML file NOT found.');
            }
            $this->render_error_message(
                __('API Key Management page file not found.', 'mapfusion')
            );
        }
    }

    /**
     * Renders the Maps Overview page.
     */
    public function render_maps_markers_page() {
        $debug_status = get_option('mapfusion_debug_logging', false);
        if ($debug_status) {
            error_log('[MapFusion Render] Rendering Maps Overview page.');
        }

        global $wpdb;

        $maps = $wpdb->get_results("SELECT id, map_title, map_start_lat, map_start_lng, map_width, map_height FROM {$wpdb->prefix}wpgmza_maps", ARRAY_A);

        $markers = $wpdb->get_results("SELECT id, map_id, title, lat, lng, address, description FROM {$wpdb->prefix}wpgmza", ARRAY_A);

        $html_file_path = plugin_dir_path(__FILE__) . '../html/maps-overview.html';

        if (file_exists($html_file_path)) {
            if ($debug_status) {
                error_log('[MapFusion Render] Maps Overview HTML file found.');
            }

            ob_start();
            include $html_file_path;
            $html_content = ob_get_clean();
            echo $html_content;
        } else {
            if ($debug_status) {
                error_log('[MapFusion Render] Maps Overview HTML file NOT found.');
            }
            $this->render_error_message(
                __('Maps Overview page file not found.', 'mapfusion')
            );
        }
    }

    /**
     * Renders the Support page.
     */
    public function render_support_page() {
        $debug_status = get_option('mapfusion_debug_logging', false);
        if ($debug_status) {
            error_log('[MapFusion Render] Rendering Support page.');
        }

        $html_file_path = plugin_dir_path(__FILE__) . '../html/support-documentation.html';

        if (file_exists($html_file_path)) {
            if ($debug_status) {
                error_log('[MapFusion Render] Support HTML file found.');
            }
            include $html_file_path;
        } else {
            if ($debug_status) {
                error_log('[MapFusion Render] Support HTML file NOT found.');
            }
            $this->render_error_message(
                __('Support page file not found.', 'mapfusion')
            );
        }
    }

    /**
     * Renders an error message.
     *
     * @param string $message The error message to display.
     */
    private function render_error_message($message) {
        echo '<div class="notice notice-error"><p>' . esc_html($message) . '</p></div>';
    }
}

// Hook to initialize the menu
if (class_exists('\MapFusion\Render')) {
    $debug_status = get_option('mapfusion_debug_logging', false);
    if ($debug_status) {
        error_log('[MapFusion Render] Initializing Render class.');
    }
    add_action('plugins_loaded', ['\MapFusion\Render', 'init']);
} else {
    error_log('[MapFusion Render] Render class not found!');
}
