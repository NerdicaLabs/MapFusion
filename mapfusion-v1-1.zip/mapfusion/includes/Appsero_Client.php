<?php

namespace MapFusion;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Class for initializing and handling Appsero client.
 */
class Appsero_Client {
    private static $client;

    /**
     * Initialize the Appsero client.
     */
    public static function init() {
        if (!class_exists('Appsero\Client')) {
            require_once plugin_dir_path(__FILE__) . '../vendor/appsero/client/src/Client.php';
        }

        if (!self::$client) {
            self::$client = new \Appsero\Client(
                'a6910bd7-4052-4af0-865b-a566aa472ef6', // Replace with your Appsero ID
                'MapFusion',
                __FILE__
            );

            // Initialize insights
            self::$client->insights()->init();

            // Initialize updater
            if (!class_exists('Appsero\Updater')) {
                require_once plugin_dir_path(__FILE__) . '../vendor/appsero/updater/src/Updater.php';
            }
            new \Appsero\Updater(self::$client);

            // Initialize license settings as a submenu
            $args = array(
                'type'        => 'submenu',
                'menu_title'  => 'License Settings',
                'page_title'  => 'License Settings',
                'menu_slug'   => 'mapfusion_license',
                'parent_slug' => 'mapfusion', // This should match the main menu slug
            );
            self::$client->license()->add_settings_page($args);
        }
    }

    /**
     * Get the Appsero client instance.
     *
     * @return \Appsero\Client
     */
    public static function get_client() {
        if (!self::$client) {
            self::init();
        }
        return self::$client;
    }
}

// Initialize the Appsero client on plugin load
add_action('plugins_loaded', ['\\MapFusion\\Appsero_Client', 'init']);
