<?php

namespace MapFusion;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Class Settings
 * Handles plugin settings and AJAX interactions.
 */
class Settings {

    /**
     * Initialize hooks for settings management.
     */
    public static function init() {
        add_action('admin_init', [__CLASS__, 'register_settings']);
        add_action('admin_menu', [__CLASS__, 'add_settings_page']);
        add_action('wp_ajax_test_connection', [__CLASS__, 'handle_test_connection']);
        add_action('wp_ajax_reset_api_key', [__CLASS__, 'handle_reset_api_key']);
        add_action('wp_ajax_save_api_key', [__CLASS__, 'save_api_key']);
        add_action('wp_ajax_update_debug_logging', [__CLASS__, 'update_debug_logging']);
    }

    /**
     * Register settings in WordPress.
     */
    public static function register_settings() {
        register_setting('mapfusion_settings_group', 'mapfusion_api_key');
        register_setting('mapfusion_settings_group', 'mapfusion_debug_logging');
    }

    /**
     * Adds the settings page to the WordPress admin menu.
     */
    public static function add_settings_page() {
        add_options_page(
            __('MapFusion Settings', 'mapfusion'),
                         __('MapFusion', 'mapfusion'),
                         'manage_options',
                         'mapfusion_settings',
                         [self::class, 'render_settings_page']
        );
    }

    /**
     * Updates the debug logging status via AJAX.
     */
    public static function update_debug_logging() {
        $received_nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';
        error_log("[MapFusion] Received nonce: {$received_nonce}");

        if (!check_ajax_referer('mapfusion_debug_nonce', 'nonce', false)) {
            error_log('[MapFusion] Invalid or expired nonce.');
            wp_send_json_error(['message' => 'Invalid or expired nonce']);
        }

        if (!current_user_can('manage_options')) {
            error_log('[MapFusion] User lacks required permissions.');
            wp_send_json_error(['message' => 'Unauthorized action']);
        }

        $debug_logging = isset($_POST['debug_logging']) ? filter_var($_POST['debug_logging'], FILTER_VALIDATE_BOOLEAN) : false;

        // Check if the value is already correct
        $current_value = get_option('mapfusion_debug_logging');
        if ($current_value === $debug_logging) {
            error_log('[MapFusion] Debug logging value already set to requested value.');
            wp_send_json_success(['debug' => $debug_logging]);
        }

        // Update and manage results
        $update_result = update_option('mapfusion_debug_logging', $debug_logging);

        if ($update_result) {
            error_log('[MapFusion] Debug logging updated successfully.');
            wp_send_json_success(['debug' => $debug_logging]);
        } else {
            error_log('[MapFusion] Failed to update debug logging.');
            // wp_send_json_error(['message' => 'Failed to update debug logging']);
        }
    }

    /**
     * Handle AJAX request to test API connection.
     */
    public static function handle_test_connection() {
        error_log('[MapFusion Settings] Received AJAX request for connection test.');

        if (!check_ajax_referer('mapfusion_settings_nonce', 'nonce', false)) {
            error_log('[MapFusion Settings] Invalid nonce.');
            wp_send_json_error(['message' => __('Invalid nonce.', 'mapfusion')]);
        }

        $api_key = get_option('mapfusion_api_key', '');
        if (empty($api_key)) {
            error_log('[MapFusion Settings] API key is missing.');
            wp_send_json_error(['message' => __('API key is missing.', 'mapfusion')]);
        }

        // Simulate API connection check (replace with real API call)
        $success = true; // Placeholder for actual API success flag
        $message = __('Connection successful.', 'mapfusion');

        if ($success) {
            error_log('[MapFusion Settings] Connection test successful.');
            wp_send_json_success(['message' => $message]);
        } else {
            error_log('[MapFusion Settings] Connection test failed.');
            wp_send_json_error(['message' => __('Connection failed.', 'mapfusion')]);
        }
    }

    /**
     * Handle AJAX request to reset API key.
     */
    public static function handle_reset_api_key() {
        error_log('[MapFusion Settings] Received AJAX request to reset API key.');

        if (!check_ajax_referer('mapfusion_settings_nonce', 'nonce', false)) {
            error_log('[MapFusion Settings] Invalid nonce.');
            wp_send_json_error(['message' => __('Invalid nonce.', 'mapfusion')]);
        }

        $new_api_key = wp_generate_password(40, false, false);
        update_option('mapfusion_api_key', $new_api_key);

        error_log('[MapFusion Settings] API key reset successfully.');
        wp_send_json_success(['message' => __('API key has been reset.', 'mapfusion'), 'api_key' => $new_api_key]);
    }

    /**
     * Saves the API Key via AJAX.
     */
    public static function save_api_key() {
        error_log('[MapFusion] Saving API key.');

        if (!current_user_can('manage_options') || !check_ajax_referer('mapfusion_settings_nonce', 'nonce', false)) {
            error_log('[MapFusion] Unauthorized action or invalid nonce.');
            wp_send_json_error(['message' => 'Unauthorized action']);
        }

        $api_key = isset($_POST['api_key']) ? sanitize_text_field($_POST['api_key']) : '';

        if (update_option('mapfusion_api_key', $api_key)) {
            error_log('[MapFusion] API key saved successfully.');
            wp_send_json_success(['api_key' => $api_key]);
        } else {
            error_log('[MapFusion] Failed to save API key.');
            wp_send_json_error(['message' => 'Failed to save API Key']);
        }
    }

    /**
     * Renders the settings page.
     */
    public static function render_settings_page() {
        $html_file_path = plugin_dir_path(__FILE__) . '../html/settings.html';

        if (file_exists($html_file_path)) {
            ob_start();
            include $html_file_path;
            $html_content = ob_get_clean();

            $nonce = wp_create_nonce('mapfusion_debug_nonce');
            $debug_status = esc_html(get_option('mapfusion_debug_logging') ? 'On' : 'Off');
            $api_key = esc_attr(get_option('mapfusion_api_key', ''));

            $html_content = str_replace(
                ['{{debug_status}}', '{{api_key}}', '{{nonce}}'],
                [$debug_status, $api_key, $nonce],
                $html_content
            );

            error_log("[MapFusion] Generated nonce for settings page: {$nonce}");

            echo $html_content;
        } else {
            echo '<div class="notice notice-error"><p>' . esc_html__('Settings page file not found.', 'mapfusion') . '</p></div>';
        }
    }
}

// Initialize the settings class
Settings::init();
