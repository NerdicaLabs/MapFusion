<?php

namespace MapFusion\Api\Pro;

use MapFusion\Rest_API;
use WP_REST_Response;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Handles PRO Maps REST API routes for MapFusion.
 */
class Maps_Pro_API {

    /**
     * Registers PRO Maps REST API routes.
     */
    public function register_routes() {
        register_rest_route('mapfusion/v1', '/edit-map/(?P<id>\d+)', [
            'methods'             => 'PUT',
            'callback'            => [$this, 'edit_map_callback'],
            'permission_callback' => [Rest_API::class, 'validate_permissions'],
        ]);

        register_rest_route('mapfusion/v1', '/delete-map/(?P<id>\d+)', [
            'methods'             => 'DELETE',
            'callback'            => [$this, 'delete_map_callback'],
            'permission_callback' => [Rest_API::class, 'validate_permissions'],
        ]);

        register_rest_route('mapfusion/v1', '/duplicate-map/(?P<id>\d+)', [
            'methods'             => 'POST',
            'callback'            => [$this, 'duplicate_map_callback'],
            'permission_callback' => [Rest_API::class, 'validate_permissions'],
        ]);
    }

    /**
     * Edits an existing map.
     */
    public function edit_map_callback($request) {
        global $wpdb;

        // Log request för debugging
        $this->log_debug('Received edit-map request. ID: ' . intval($request['id']));

        // Validera och hämta kart-ID
        $map_id = intval($request['id']);
        if (!$map_id) {
            $this->log_debug('Invalid map ID.');
            return new WP_REST_Response(['success' => false, 'message' => 'Invalid map ID.'], 400);
        }

        // Hämta inkommande data
        $params = $request->get_json_params();
        $table_name = $wpdb->prefix . 'wpgmza_maps';

        // Förbered uppdateringsdata
        $update_data = array_filter([
            'map_title'     => isset($params['map_title']) ? sanitize_text_field($params['map_title']) : null,
                                    'map_start_lat' => isset($params['map_start_lat']) ? sanitize_text_field($params['map_start_lat']) : null,
                                    'map_start_lng' => isset($params['map_start_lng']) ? sanitize_text_field($params['map_start_lng']) : null,
                                    'map_width'     => isset($params['map_width']) ? sanitize_text_field($params['map_width']) : null,
                                    'map_height'    => isset($params['map_height']) ? sanitize_text_field($params['map_height']) : null,
        ]);

        // Kontrollera att det finns fält att uppdatera
        if (empty($update_data)) {
            $this->log_debug('No fields to update for map ID: ' . $map_id);
            return new WP_REST_Response(['success' => false, 'message' => 'No fields to update.'], 400);
        }

        // Försök uppdatera kartan
        $updated = $wpdb->update(
            $table_name,
            $update_data,
            ['id' => $map_id],
            array_fill(0, count($update_data), '%s'),
                                 ['%d']
        );

        if ($updated === false) {
            $this->log_debug('Failed to update map ID: ' . $map_id);
            return new WP_REST_Response(['success' => false, 'message' => 'Failed to update map.'], 500);
        }

        // Logga framgång och returnera svar
        $this->log_debug('Map updated successfully. ID: ' . $map_id);
        return new WP_REST_Response(['success' => true, 'message' => 'Map updated successfully.'], 200);
    }

    /**
     * Deletes a map.
     */
    public function delete_map_callback($request) {
        global $wpdb;

        $map_id = intval($request['id']);
        $table_name = $wpdb->prefix . 'wpgmza_maps';

        $deleted = $wpdb->delete($table_name, ['id' => $map_id], ['%d']);

        if ($deleted === false) {
            return new WP_REST_Response(['success' => false, 'message' => 'Failed to delete map.'], 500);
        }

        return new WP_REST_Response(['success' => true, 'message' => 'Map deleted successfully.'], 200);
    }

    /**
     * Duplicates a map.
     */
    public function duplicate_map_callback($request) {
        global $wpdb;

        $map_id = intval($request['id']);
        $table_name = $wpdb->prefix . 'wpgmza_maps';

        // Fetch map data
        $map = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} WHERE id = %d", $map_id), ARRAY_A);

        if (!$map) {
            Rest_API::log_debug("Map not found for duplication: ID {$map_id}");
            return new WP_REST_Response(['success' => false, 'message' => 'Map not found.'], 404);
        }

        unset($map['id']); // Remove ID to create a new record

        // Duplicate the map
        $duplicated = $wpdb->insert($table_name, $map);

        if ($duplicated === false) {
            Rest_API::log_debug("Failed to duplicate map: ID {$map_id}");
            return new WP_REST_Response(['success' => false, 'message' => 'Failed to duplicate map.'], 500);
        }

        $new_id = $wpdb->insert_id;
        Rest_API::log_debug("Map duplicated successfully. New ID: {$new_id}");

        return new WP_REST_Response([
            'success' => true,
            'message' => 'Map duplicated successfully.',
            'data'    => ['new_map_id' => $new_id],
        ], 200);
    }

    /**
     * Logs debug information if debug mode is enabled.
     *
     * @param string $message The message to log.
     */
    private static function log_debug($message) {
        if (get_option('mapfusion_debug_logging', false)) {
            error_log('[MapFusion DEBUG] ' . $message);
        }
    }
}

    /**
    * Registers the routes for Maps_Pro_API with fallback logic.
    */
    /**
    * Registers the routes for Maps_Pro_API with fallback logic.
    */
    function mapfusion_register_maps_pro_api_routes() {
        if (class_exists('\\MapFusion\\Api\\Pro\\Maps_Pro_API')) {
            error_log('Initializing Maps_Pro_API class.');
            $maps_pro_api = new \MapFusion\Api\Pro\Maps_Pro_API();
            $maps_pro_api->register_routes();
        } else {
            error_log('Maps_Pro_API class not found. Attempting fallback...');
            $fallback_file = __DIR__ . '/class-maps-pro-api.php';

            if (file_exists($fallback_file)) {
                require_once $fallback_file;
                error_log('Fallback file loaded: ' . $fallback_file);

                if (class_exists('\\MapFusion\\Api\\Pro\\Maps_Pro_API')) {
                    error_log('Fallback succeeded. Initializing Maps_Pro_API class.');
                    $maps_pro_api = new \MapFusion\Api\Pro\Maps_Pro_API();
                    $maps_pro_api->register_routes();
                } else {
                    error_log('Failed to initialize Maps_Pro_API class even after including fallback.');
                }
            } else {
                error_log('Fallback file not found: ' . $fallback_file);
            }
        }
    }
add_action('rest_api_init', '\\MapFusion\\Api\\Pro\\mapfusion_register_maps_pro_api_routes');
