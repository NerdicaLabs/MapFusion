<?php

namespace MapFusion\Api\Pro;

use MapFusion\Rest_API;
use WP_REST_Response;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Handles PRO Markers REST API routes for MapFusion.
 */
class Markers_Pro_API {

    /**
     * Registers PRO Markers REST API routes.
     */
    public function register_routes() {
        // Edit Marker
        register_rest_route('mapfusion/v1', '/edit-marker/(?P<id>\d+)', [
            'methods'             => 'PUT',
            'callback'            => [$this, 'edit_marker_callback'],
            'permission_callback' => [Rest_API::class, 'validate_permissions'],
        ]);

        // Delete Marker
        register_rest_route('mapfusion/v1', '/delete-marker/(?P<id>\d+)', [
            'methods'             => 'DELETE',
            'callback'            => [$this, 'delete_marker_callback'],
            'permission_callback' => [Rest_API::class, 'validate_permissions'],
        ]);

        // Duplicate Marker
        register_rest_route('mapfusion/v1', '/duplicate-marker/(?P<id>\d+)', [
            'methods'             => 'POST',
            'callback'            => [$this, 'duplicate_marker_callback'],
            'permission_callback' => [Rest_API::class, 'validate_permissions'],
        ]);
    }

    /**
     * Callback to update a marker's details.
     *
     * @param WP_REST_Request $request The incoming REST API request.
     * @return WP_REST_Response The response indicating success or failure.
     */
    public function edit_marker_callback($request) {
        global $wpdb;

        // Retrieve marker ID and parameters
        $marker_id = intval($request['id']);
        $params = $request->get_json_params();
        $table_name = $wpdb->prefix . 'wpgmza';

        // Prepare fields for update
        $update_data = array_filter([
            'title'       => sanitize_text_field($params['title'] ?? null),
                                    'lat'         => sanitize_text_field($params['lat'] ?? null),
                                    'lng'         => sanitize_text_field($params['lng'] ?? null),
                                    'address'     => sanitize_text_field($params['address'] ?? null),
                                    'description' => sanitize_text_field($params['description'] ?? null),
                                    'icon'        => esc_url_raw($params['icon'] ?? null),
                                    'category'    => sanitize_text_field($params['category'] ?? null),
                                    'pic'         => esc_url_raw($params['pic'] ?? null),
        ]);

        // Check if any fields are provided
        if (empty($update_data)) {
            self::log_debug("No fields provided for updating marker ID: {$marker_id}");
            return new WP_REST_Response(['success' => false, 'message' => 'No fields to update.'], 400);
        }

        // Attempt to update the marker
        $updated = $wpdb->update(
            $table_name,
            $update_data,
            ['id' => $marker_id],
            array_fill(0, count($update_data), '%s'),
                                 ['%d']
        );

        // Handle update failure
        if ($updated === false) {
            self::log_debug("Failed to update marker ID: {$marker_id}");
            return new WP_REST_Response(['success' => false, 'message' => 'Failed to update marker.'], 500);
        }

        // Log successful update
        self::log_debug("Marker ID: {$marker_id} updated successfully.");
        return new WP_REST_Response(['success' => true, 'message' => 'Marker updated successfully.'], 200);
    }

    /**
     * Callback to delete a marker.
     *
     * @param WP_REST_Request $request The incoming REST API request.
     * @return WP_REST_Response The response indicating success or failure.
     */
    public function delete_marker_callback($request) {
        global $wpdb;

        $marker_id = intval($request['id']);
        $table_name = $wpdb->prefix . 'wpgmza';

        $deleted = $wpdb->delete($table_name, ['id' => $marker_id], ['%d']);

        if ($deleted === false) {
            self::log_debug("Failed to delete marker ID: {$marker_id}");
            return new WP_REST_Response(['success' => false, 'message' => 'Failed to delete marker.'], 500);
        }

        self::log_debug("Marker ID: {$marker_id} deleted successfully.");
        return new WP_REST_Response(['success' => true, 'message' => 'Marker deleted successfully.'], 200);
    }

    /**
     * Callback to duplicate a marker.
     *
     * @param WP_REST_Request $request The incoming REST API request.
     * @return WP_REST_Response The response indicating success or failure.
     */
    public function duplicate_marker_callback($request) {
        global $wpdb;

        $marker_id = intval($request['id']);
        $table_name = $wpdb->prefix . 'wpgmza';

        // Retrieve the existing marker
        $marker = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} WHERE id = %d", $marker_id), ARRAY_A);

        if (!$marker) {
            self::log_debug("Marker ID: {$marker_id} not found for duplication.");
            return new WP_REST_Response(['success' => false, 'message' => 'Marker not found.'], 404);
        }

        // Duplicate the marker
        unset($marker['id']);
        $duplicated = $wpdb->insert($table_name, $marker);

        if ($duplicated === false) {
            self::log_debug("Failed to duplicate marker ID: {$marker_id}");
            return new WP_REST_Response(['success' => false, 'message' => 'Failed to duplicate marker.'], 500);
        }

        $new_id = $wpdb->insert_id;
        self::log_debug("Marker ID: {$marker_id} duplicated successfully. New ID: {$new_id}");
        return new WP_REST_Response(['success' => true, 'message' => 'Marker duplicated successfully.', 'new_id' => $new_id], 200);
    }

    /**
     * Logs debug information if debug mode is enabled.
     *
     * @param string $message The message to log.
     */
    private static function log_debug($message) {
        if (get_option('mapfusion_debug_logging', false)) {
            error_log('[MapFusion DEBUG] ' . $message);
        }
    }
}

    /**
    * Registers the routes for Markers_Pro_API with fallback logic.
    */
    /**
    * Registers the routes for Markers_Pro_API with fallback logic.
    */
    function mapfusion_register_markers_pro_api_routes() {
        if (class_exists('\\MapFusion\\Api\\Pro\\Markers_Pro_API')) {
            error_log('Initializing Markers_Pro_API class.');
            $markers_pro_api = new \MapFusion\Api\Pro\Markers_Pro_API();
            $markers_pro_api->register_routes();
        } else {
            error_log('Markers_Pro_API class not found. Attempting fallback...');
            $fallback_file = __DIR__ . '/class-markers-pro-api.php';

            if (file_exists($fallback_file)) {
                require_once $fallback_file;
                error_log('Fallback file loaded: ' . $fallback_file);

                if (class_exists('\\MapFusion\\Api\\Pro\\Markers_Pro_API')) {
                    error_log('Fallback succeeded. Initializing Markers_Pro_API class.');
                    $markers_pro_api = new \MapFusion\Api\Pro\Markers_Pro_API();
                    $markers_pro_api->register_routes();
                } else {
                    error_log('Failed to initialize Markers_Pro_API class even after including fallback.');
                }
            } else {
                error_log('Fallback file not found: ' . $fallback_file);
            }
        }
    }
    add_action('rest_api_init', '\\MapFusion\\Api\\Pro\\mapfusion_register_markers_pro_api_routes');
