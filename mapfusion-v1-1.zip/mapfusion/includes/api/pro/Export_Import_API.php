<?php

namespace MapFusion\Api\Pro;

use MapFusion\Rest_API;
use WP_REST_Response;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Handles Export and Import REST API routes for MapFusion PRO.
 */
class Export_Import_API {

    /**
     * Registers Export/Import REST API routes.
     */
    public function register_routes() {
        register_rest_route('mapfusion/v1', '/export', [
            'methods'             => 'POST',
            'callback'            => [$this, 'export_callback'],
            'permission_callback' => [Rest_API::class, 'validate_permissions'],
        ]);

        register_rest_route('mapfusion/v1', '/import', [
            'methods'             => 'POST',
            'callback'            => [$this, 'import_callback'],
            'permission_callback' => [Rest_API::class, 'validate_permissions'],
        ]);
    }

    /**
     * Handles data export.
     *
     * @param WP_REST_Request $request The incoming REST request.
     * @return WP_REST_Response The REST response with the export result.
     */
    public function export_callback($request) {
        global $wpdb;

        $params = $request->get_json_params();
        $format = strtoupper(sanitize_text_field($params['format'] ?? ''));
        $map_id = isset($params['map_id']) ? intval($params['map_id']) : null;

        self::log_debug('Export requested. Format: ' . $format . ', Map ID: ' . ($map_id ?? 'All'));

        if (!in_array($format, ['JSON', 'CSV'])) {
            self::log_debug('Invalid export format: ' . $format);
            return new WP_REST_Response(['success' => false, 'message' => 'Invalid format. Use "JSON" or "CSV".'], 400);
        }

        $maps_table = $wpdb->prefix . 'wpgmza_maps';
        $markers_table = $wpdb->prefix . 'wpgmza';

        $maps_query = "SELECT * FROM {$maps_table}";
        $markers_query = "SELECT * FROM {$markers_table}";

        if ($map_id) {
            $maps_query .= $wpdb->prepare(" WHERE id = %d", $map_id);
            $markers_query .= $wpdb->prepare(" WHERE map_id = %d", $map_id);
        }

        $maps = $wpdb->get_results($maps_query, ARRAY_A);
        $markers = $wpdb->get_results($markers_query, ARRAY_A);

        self::log_debug('Export fetched ' . count($maps) . ' maps and ' . count($markers) . ' markers.');

        return $format === 'JSON'
        ? $this->export_as_json($maps, $markers)
        : $this->export_as_csv($maps, $markers);
    }

    /**
     * Exports data as JSON.
     *
     * @param array $maps The maps data.
     * @param array $markers The markers data.
     * @return WP_REST_Response The REST response with the JSON file URL.
     */
    private function export_as_json($maps, $markers) {
        if (empty($maps) && empty($markers)) {
            self::log_debug('No data available for JSON export.');
            return new WP_REST_Response(['success' => false, 'message' => 'No data available.'], 404);
        }

        $data = ['maps' => $maps, 'markers' => $markers];
        $filename = 'export-' . date('Y-m-d_H-i-s') . '.json';
        $file_path = WP_CONTENT_DIR . '/uploads/' . $filename;

        if (!file_put_contents($file_path, json_encode($data, JSON_PRETTY_PRINT))) {
            self::log_debug('Failed to write JSON export file.');
            return new WP_REST_Response(['success' => false, 'message' => 'Failed to create JSON file.'], 500);
        }

        self::log_debug('JSON export created successfully: ' . $file_path);
        return new WP_REST_Response([
            'success' => true,
            'file_url' => content_url('/uploads/' . $filename),
        ], 200);
    }

    /**
     * Exports data as CSV.
     *
     * @param array $maps The maps data.
     * @param array $markers The markers data.
     * @return WP_REST_Response The REST response with the CSV file URL.
     */
    private function export_as_csv($maps, $markers) {
        $filename = 'export-' . date('Y-m-d_H-i-s') . '.csv';
        $file_path = WP_CONTENT_DIR . '/uploads/' . $filename;

        $file = fopen($file_path, 'w');
        if (!$file) {
            self::log_debug('Failed to open file for CSV export.');
            return new WP_REST_Response(['success' => false, 'message' => 'Failed to create CSV file.'], 500);
        }

        fputcsv($file, ['Type', 'ID', 'Map ID', 'Name', 'Latitude', 'Longitude', 'Address', 'Description']);
        foreach ($maps as $map) {
            fputcsv($file, ['Map', $map['id'], '', $map['map_title'], '', '', '', '']);
        }
        foreach ($markers as $marker) {
            fputcsv($file, ['Marker', $marker['id'], $marker['map_id'], $marker['title'], $marker['lat'], $marker['lng'], $marker['address'], $marker['description']]);
        }

        fclose($file);
        self::log_debug('CSV export created successfully: ' . $file_path);

        return new WP_REST_Response([
            'success' => true,
            'file_url' => content_url('/uploads/' . $filename),
        ], 200);
    }

    /**
     * Handles data import.
     *
     * @param WP_REST_Request $request The incoming REST request.
     * @return WP_REST_Response The REST response with the import result.
     */
    public function import_callback($request) {
        global $wpdb;

        $file_url = sanitize_text_field($request->get_param('file_url'));
        $uploaded_file = !empty($_FILES['file']) ? $_FILES['file'] : null;

        self::log_debug('Import started. File URL: ' . $file_url);

        $file_content = $this->get_file_content($file_url, $uploaded_file);

        if (!$file_content) {
            self::log_debug('No file provided or unsupported upload method.');
            return new WP_REST_Response(['success' => false, 'message' => 'No file provided or unsupported upload method.'], 400);
        }

        $file_type = $this->detect_file_type($file_content);

        if ($file_type === 'application/json') {
            return $this->import_json($file_content);
        } elseif ($file_type === 'text/csv') {
            return $this->import_csv($file_content);
        }

        self::log_debug('Unsupported file type detected.');
        return new WP_REST_Response(['success' => false, 'message' => 'Unsupported file type.'], 400);
    }

    /**
     * Fetches file content from a URL or uploaded file.
     */
    private function get_file_content($file_url, $uploaded_file) {
        if (!empty($file_url)) {
            return file_get_contents($file_url);
        } elseif ($uploaded_file && $uploaded_file['error'] === UPLOAD_ERR_OK) {
            return file_get_contents($uploaded_file['tmp_name']);
        }
        return null;
    }

    /**
     * Detects the file type based on its content.
     */
    private function detect_file_type($content) {
        return json_decode($content, true) !== null ? 'application/json' : 'text/csv';
    }

    /**
     * Imports JSON data.
     */
    private function import_json($content) {
        $data = json_decode($content, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            self::log_debug('Invalid JSON file. Error: ' . json_last_error_msg());
            return new WP_REST_Response(['success' => false, 'message' => 'Invalid JSON file.'], 400);
        }

        // Add your import logic here for JSON

        return new WP_REST_Response(['success' => true, 'message' => 'JSON import successful.'], 200);
    }

    /**
     * Imports CSV data.
     */
    private function import_csv($content) {
        $file_handle = fopen('php://temp', 'r+');
        fwrite($file_handle, $content);
        rewind($file_handle);

        $header = fgetcsv($file_handle);

        while ($row = fgetcsv($file_handle)) {
            $data = array_combine($header, $row);
            // Add your import logic here for CSV
        }

        fclose($file_handle);

        return new WP_REST_Response(['success' => true, 'message' => 'CSV import successful.'], 200);
    }

    /**
     * Logs debug information if debug mode is enabled.
     */
    private static function log_debug($message) {
        if (get_option('mapfusion_debug_logging', false)) {
            error_log('[MapFusion DEBUG] ' . $message);
        }
    }
}

    /**
    * Registers the routes for Export_Import_API with fallback logic.
    */
    /**
    * Registers the routes for Export_Import_API with fallback logic.
    */
    function mapfusion_register_export_import_api_routes() {
        if (class_exists('\\MapFusion\\Api\\Pro\\Export_Import_API')) {
            error_log('Initializing Export_Import_API class.');
            $export_import_api = new \MapFusion\Api\Pro\Export_Import_API();
            $export_import_api->register_routes();
        } else {
            error_log('Export_Import_API class not found. Attempting fallback...');
            $fallback_file = __DIR__ . '/class-maps-pro-api.php';

            if (file_exists($fallback_file)) {
                require_once $fallback_file;
                error_log('Fallback file loaded: ' . $fallback_file);

                if (class_exists('\\MapFusion\\Api\\Pro\\Export_Import_API')) {
                    error_log('Fallback succeeded. Initializing Export_Import_API class.');
                    $export_import_api = new \MapFusion\Api\Pro\Export_Import_API();
                    $export_import_api->register_routes();
                } else {
                    error_log('Failed to initialize Export_Import_API class even after including fallback.');
                }
            } else {
                error_log('Fallback file not found: ' . $fallback_file);
            }
        }
    }
add_action('rest_api_init', '\\MapFusion\\Api\\Pro\\mapfusion_register_export_import_api_routes');
