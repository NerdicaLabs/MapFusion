<?php

namespace MapFusion\Api;

use MapFusion\License_Validator;
use MapFusion\Rest_API;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Handles miscellaneous REST API routes for MapFusion.
 */
class Other_API {

    /**
     * Registers miscellaneous REST API routes.
     */
    public function register_routes() {
        $this->log_debug('Registering routes for Other_API');

        register_rest_route('mapfusion/v1', '/verify-key', [
            'methods'             => 'GET',
            'callback'            => [$this, 'verify_key_callback'],
            'permission_callback' => [Rest_API::class, 'verify_bearer_token'],
        ]);
        $this->log_debug('Registered route: /mapfusion/v1/verify-key');

        register_rest_route('mapfusion/v1', '/reset-api-key', [
            'methods'             => 'POST',
            'callback'            => [$this, 'reset_api_key_callback'],
            'permission_callback' => '__return_true',
        ]);
        $this->log_debug('Registered route: /mapfusion/v1/reset-api-key');

        register_rest_route('mapfusion/v1', '/validate-license', [
            'methods'             => 'POST',
            'callback'            => [License_Validator::class, 'validate_license_from_request'],
            'permission_callback' => [Rest_API::class, 'verify_bearer_token'],
        ]);
        $this->log_debug('Registered route: /mapfusion/v1/validate-license');
    }

    /**
     * Logs debug information if debug mode is enabled.
     *
     * @param string $message The debug message.
     */
    private function log_debug($message) {
        if (get_option('mapfusion_debug_logging', false)) {
            $request_id = $_SERVER['UNIQUE_ID'] ?? uniqid();
            error_log("[MapFusion DEBUG][Request ID: {$request_id}] {$message}");
        }
    }

    /**
     * Callback for verifying the API key.
     *
     * @param \WP_REST_Request $request The request object.
     * @return \WP_REST_Response The response object.
     */
    public function verify_key_callback($request) {
        $this->log_debug('Received verify-key request.');
        return new \WP_REST_Response(['success' => true, 'message' => 'API key is valid.'], 200);
    }

    /**
     * Callback for resetting the API key.
     *
     * @return \WP_REST_Response The response object.
     */
    public function reset_api_key_callback() {
        $new_key = wp_generate_password(40, false, false);

        if (update_option('mapfusion_api_key', $new_key)) {
            $this->log_debug('API key reset successfully.');
            return new \WP_REST_Response(['success' => true, 'api_key' => $new_key], 200);
        }

        $this->log_debug('Failed to reset API key.');
        return new \WP_REST_Response(['success' => false, 'message' => 'Failed to reset API key.'], 500);
    }

    public function validate_license_callback($request) {
        $this->log_debug('Received validate-license request.');

        // Extract license key from the request
        $license_key = License_Validator::extract_license_key_from_request($request);

        // Validate the license key
        if (License_Validator::validate_license_key($license_key)) {
            return new \WP_REST_Response(['success' => true, 'message' => 'License key is valid.'], 200);
        }

        return new \WP_REST_Response(['success' => false, 'message' => 'Invalid license key.'], 403);
    }
}

/**
 * Registers the routes for Other_API with fallback logic.
 */
function mapfusion_register_other_api_routes() {
    if (class_exists(Other_API::class)) {
        error_log('Initializing Other_API class.');
        $other_api = new Other_API();
        $other_api->register_routes();
    } else {
        error_log('Other_API class not found. Attempting fallback...');
        $fallback_file = __DIR__ . '/class-other-api.php';

        if (file_exists($fallback_file)) {
            require_once $fallback_file;
            error_log('Fallback file loaded: ' . $fallback_file);

            if (class_exists(Other_API::class)) {
                error_log('Fallback succeeded. Initializing Other_API class.');
                $other_api = new Other_API();
                $other_api->register_routes();
            } else {
                error_log('Failed to initialize Other_API class even after including fallback.');
            }
        } else {
            error_log('Fallback file not found: ' . $fallback_file);
        }
    }
}
add_action('rest_api_init', __NAMESPACE__ . '\\mapfusion_register_other_api_routes');
