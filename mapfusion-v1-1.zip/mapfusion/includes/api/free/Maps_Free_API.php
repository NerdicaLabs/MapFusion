<?php

namespace MapFusion\Api\Free;

use MapFusion\Rest_API;
use WP_REST_Response;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Handles Free Maps REST API routes for MapFusion.
 */
class Maps_Free_API {

    /**
     * Registers Free Maps REST API routes.
     */
    public function register_routes() {
        register_rest_route('mapfusion/v1', '/list-maps', [
            'methods'             => 'GET',
            'callback'            => [$this, 'list_maps_callback'],
            'permission_callback' => [\MapFusion\Rest_API::class, 'verify_bearer_token'],
        ]);

        register_rest_route('mapfusion/v1', '/add-map', [
            'methods'             => 'POST',
            'callback'            => [$this, 'add_map_callback'],
            'permission_callback' => [\MapFusion\Rest_API::class, 'verify_bearer_token'],
        ]);

        register_rest_route('mapfusion/v1', '/search-maps', [
            'methods'             => 'GET',
            'callback'            => [$this, 'search_maps_callback'],
            'permission_callback' => [\MapFusion\Rest_API::class, 'verify_bearer_token'],
        ]);

        register_rest_route('mapfusion/v1', '/get-map-details/(?P<id>\d+)', [
            'methods'             => 'GET',
            'callback'            => [$this, 'get_map_details_callback'],
            'permission_callback' => [\MapFusion\Rest_API::class, 'verify_bearer_token'],
        ]);
    }

    /**
     * Lists all maps.
     */
    public function list_maps_callback($request) {
        global $wpdb;

        $table_name = $wpdb->prefix . 'wpgmza_maps';
        $maps = $wpdb->get_results("SELECT id, map_title, map_start_lat, map_start_lng, map_width, map_height FROM {$table_name}", ARRAY_A);

        if (empty($maps)) {
            self::log_debug('No maps found in the database.');
            return new WP_REST_Response(['success' => false, 'message' => 'No maps found.'], 404);
        }

        self::log_debug('Retrieved ' . count($maps) . ' maps from the database.');
        return new WP_REST_Response(['success' => true, 'data' => $maps], 200);
    }

    /**
     * Searches maps based on a query string.
     */
    public function search_maps_callback($request) {
        global $wpdb;

        $query = sanitize_text_field($request->get_param('query') ?? '');
        $limit = intval($request->get_param('limit') ?? 10); // Standardvärde för limit
        $offset = intval($request->get_param('offset') ?? 0); // Standardvärde för offset
        $table_name = $wpdb->prefix . 'wpgmza_maps';

        if ($limit <= 0) {
            $limit = 10; // Fallback för ogiltiga värden
        }

        $maps = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, map_title, map_start_lat, map_start_lng, map_width, map_height
                FROM {$table_name}
                WHERE map_title LIKE %s
                LIMIT %d OFFSET %d",
                '%' . $wpdb->esc_like($query) . '%',
                           $limit,
                           $offset
            ),
            ARRAY_A
        );

        if (empty($maps)) {
            self::log_debug('No maps found for query: ' . $query . ' with limit: ' . $limit . ' and offset: ' . $offset);
            return new WP_REST_Response(['success' => false, 'message' => 'No maps found.'], 404);
        }

        self::log_debug('Found ' . count($maps) . ' maps for query: ' . $query . ' with limit: ' . $limit . ' and offset: ' . $offset);
        return new WP_REST_Response(['success' => true, 'data' => $maps], 200);
    }

    /**
     * Retrieves details of a specific map.
     */
    public function get_map_details_callback($request) {
        global $wpdb;

        $map_id = intval($request['id']);
        $table_name = $wpdb->prefix . 'wpgmza_maps';

        $map = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} WHERE id = %d", $map_id), ARRAY_A);

        if (!$map) {
            self::log_debug('Map not found: ID ' . $map_id);
            return new WP_REST_Response(['success' => false, 'message' => 'Map not found.'], 404);
        }

        self::log_debug('Retrieved map details for ID ' . $map_id);
        return new WP_REST_Response(['success' => true, 'data' => $map], 200);
    }

    /**
     * Adds a new map.
     */
    public function add_marker_callback($request) {
        global $wpdb;

        // Retrieve and sanitize JSON parameters from the request
        $params = $request->get_json_params();
        $map_id = intval($params['map_id'] ?? 0);
        $title = sanitize_text_field($params['title'] ?? '');
        $lat = sanitize_text_field($params['lat'] ?? '');
        $lng = sanitize_text_field($params['lng'] ?? '');
        $address = sanitize_text_field($params['address'] ?? '');
        $description = sanitize_text_field($params['description'] ?? '');

        // Validate required parameters
        if (empty($map_id) || empty($title) || empty($lat) || empty($lng)) {
            if (get_option('mapfusion_debug_logging', false)) {
                self::log_debug('Failed to add marker: Missing required parameters. Provided data: ' . json_encode($params));
            }
            return new WP_REST_Response(['success' => false, 'message' => 'Missing required parameters.'], 400);
        }

        $table_name = $wpdb->prefix . 'wpgmza';

        // Attempt to insert the marker into the database
        $inserted = $wpdb->insert(
            $table_name,
            [
                'map_id'      => $map_id,
                'title'       => $title,
                'lat'         => $lat,
                'lng'         => $lng,
                'address'     => $address,
                'description' => $description,
            ],
            ['%d', '%s', '%s', '%s', '%s', '%s']
        );

        // Handle database insertion failure
        if ($inserted === false) {
            if (get_option('mapfusion_debug_logging', false)) {
                self::log_debug('Failed to add marker: Database insertion error. Query: ' . $wpdb->last_query);
            }
            return new WP_REST_Response(['success' => false, 'message' => 'Failed to add marker.'], 500);
        }

        // Log successful marker addition
        if (get_option('mapfusion_debug_logging', false)) {
            self::log_debug('Marker added successfully. ID: ' . $wpdb->insert_id . '. Data: ' . json_encode([
                'map_id'      => $map_id,
                'title'       => $title,
                'lat'         => $lat,
                'lng'         => $lng,
                'address'     => $address,
                'description' => $description,
            ]));
        }

        // Return a success response with the inserted marker details
        return new WP_REST_Response([
            'success' => true,
            'message' => 'Marker added successfully!',
            'data'    => [
                'id'          => $wpdb->insert_id,
                'map_id'      => $map_id,
                'title'       => $title,
                'lat'         => $lat,
                'lng'         => $lng,
                'address'     => $address,
                'description' => $description,
            ],
        ], 200);
    }

    /**
     * Logs debug information if debug mode is enabled.
     */
    private static function log_debug($message) {
        if (get_option('mapfusion_debug_logging', false)) {
            error_log('[MapFusion DEBUG] ' . $message);
        }
    }
}
    /**
    * Registers the routes for Maps_Free_API with fallback logic.
    */
    /**
    * Registers the routes for Maps_Free_API with fallback logic.
    */
    function mapfusion_register_maps_free_api_routes() {
        if (class_exists('\\MapFusion\\Api\\Free\\Maps_Free_API')) {
            error_log('Initializing Maps_Free_API class.');
            $maps_free_api = new \MapFusion\Api\Free\Maps_Free_API();
            $maps_free_api->register_routes();
        } else {
            error_log('Maps_Free_API class not found. Attempting fallback...');
            $fallback_file = __DIR__ . '/class-maps-free-api.php';

            if (file_exists($fallback_file)) {
                require_once $fallback_file;
                error_log('Fallback file loaded: ' . $fallback_file);

                if (class_exists('\\MapFusion\\Api\\Free\\Maps_Free_API')) {
                    error_log('Fallback succeeded. Initializing Maps_Free_API class.');
                    $maps_free_api = new \MapFusion\Api\Free\Maps_Free_API();
                    $maps_free_api->register_routes();
                } else {
                    error_log('Failed to initialize Maps_Free_API class even after including fallback.');
                }
            } else {
                error_log('Fallback file not found: ' . $fallback_file);
            }
        }
    }
    add_action('rest_api_init', '\\MapFusion\\Api\\Free\\mapfusion_register_maps_free_api_routes');
