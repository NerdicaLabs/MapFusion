<?php

namespace MapFusion\Api\Free;

use WP_REST_Response;
use MapFusion\Rest_API;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Handles Free Markers REST API routes for MapFusion.
 */
class Markers_Free_API {

    /**
     * Registers Free Markers REST API routes.
     */
    public function register_routes() {
        $this->log_debug('Registering routes for Markers_Free_API');

        register_rest_route('mapfusion/v1', '/list-markers', [
            'methods'             => 'GET',
            'callback'            => [$this, 'list_markers_callback'],
            'args'                => [
                'map_id' => [
                    'required'          => false,
                    'validate_callback' => function ($param) {
                        return is_numeric($param) && $param > 0;
                    },
                    'description'       => 'Optional Map ID to filter markers.'
                ],
            ],
            'permission_callback' => [\MapFusion\Rest_API::class, 'verify_bearer_token'],
        ]);

        $this->log_debug('Registered route: /mapfusion/v1/list-markers');

        register_rest_route('mapfusion/v1', '/add-marker', [
            'methods'             => 'POST',
            'callback'            => [$this, 'add_marker_callback'],
            'permission_callback' => [\MapFusion\Rest_API::class, 'verify_bearer_token'],
        ]);

        $this->log_debug('Registered route: /mapfusion/v1/add-marker');

        register_rest_route('mapfusion/v1', '/search-markers', [
            'methods'             => 'GET',
            'callback'            => [$this, 'search_markers_callback'],
            'args'                => [
                'term' => [
                    'required'          => false,
                    'validate_callback' => function ($param) {
                        return is_string($param);
                    },
                    'description'       => 'Search term to filter markers.',
                ],
                'limit' => [
                    'required'          => false,
                    'validate_callback' => function ($param) {
                        return is_numeric($param) && $param > 0;
                    },
                    'description'       => 'Number of results to return.',
                ],
                'offset' => [
                    'required'          => false,
                    'validate_callback' => function ($param) {
                        return is_numeric($param) && $param >= 0;
                    },
                    'description'       => 'Offset for pagination.',
                ],
            ],
            'permission_callback' => [\MapFusion\Rest_API::class, 'verify_bearer_token'],
        ]);

        $this->log_debug('Registered route: /mapfusion/v1/search-markers');

        register_rest_route('mapfusion/v1', '/get-marker-details/(?P<id>\d+)', [
            'methods'             => 'GET',
            'callback'            => [$this, 'get_marker_details_callback'],
            'permission_callback' => [\MapFusion\Rest_API::class, 'verify_bearer_token'],
        ]);

        $this->log_debug('Registered route: /mapfusion/v1/get-marker-details');
    }

    /**
     * Logs debug information if debug mode is enabled.
     *
     * @param string $message The debug message.
     */
    private function log_debug($message) {
        if (get_option('mapfusion_debug_logging', false)) {
            $request_id = $_SERVER['UNIQUE_ID'] ?? uniqid();
            error_log("[MapFusion DEBUG][Request ID: {$request_id}] {$message}");
        }
    }

    /**
     * Lists all markers.
     */
    public function list_markers_callback($request) {
        global $wpdb;

        $map_id = $request->get_param('map_id');
        $table_name = $wpdb->prefix . 'wpgmza';

        if (!empty($map_id)) {
            $query = $wpdb->prepare(
                "SELECT id, map_id, title, lat, lng, address, description FROM {$table_name} WHERE map_id = %d",
                $map_id
            );
        } else {
            $query = "SELECT id, map_id, title, lat, lng, address, description FROM {$table_name}";
        }

        $markers = $wpdb->get_results($query, ARRAY_A);

        $this->log_debug('Executed query: ' . $query);
        if (empty($markers)) {
            $this->log_debug('No markers found in the database.');
            return new \WP_REST_Response(['success' => false, 'message' => 'No markers found.'], 404);
        }

        $this->log_debug('Retrieved ' . count($markers) . ' markers from the database.');
        return new \WP_REST_Response(['success' => true, 'data' => $markers], 200);
    }

    /**
     * Searches for markers based on a query string.
     */
    public function search_markers_callback($request) {
        global $wpdb;

        $term = sanitize_text_field($request->get_param('term') ?? '');
        $map_id = intval($request->get_param('map_id') ?? 0);
        $limit = intval($request->get_param('limit') ?? 10);
        $offset = intval($request->get_param('offset') ?? 0);

        $table_name = $wpdb->prefix . 'wpgmza';
        $query = "SELECT id, map_id, title, lat, lng, address, description FROM {$table_name} WHERE 1=1";

        if (!empty($term)) {
            $query .= " AND (title LIKE %s OR address LIKE %s OR description LIKE %s)";
            $like_term = '%' . $wpdb->esc_like($term) . '%';
            $query_params[] = $like_term;
            $query_params[] = $like_term;
            $query_params[] = $like_term;
        }

        if (!empty($map_id)) {
            $query .= " AND map_id = %d";
            $query_params[] = $map_id;
        }

        $query .= " LIMIT %d OFFSET %d";
        $query_params[] = $limit;
        $query_params[] = $offset;

        $prepared_query = $wpdb->prepare($query, $query_params);
        $markers = $wpdb->get_results($prepared_query, ARRAY_A);

        $this->log_debug('Executed query: ' . $prepared_query);

        if (empty($markers)) {
            $this->log_debug('No markers found for the given parameters.');
            return new \WP_REST_Response(['success' => false, 'message' => 'No markers found.'], 404);
        }

        $this->log_debug('Found ' . count($markers) . ' markers for the given parameters.');
        return new \WP_REST_Response(['success' => true, 'data' => $markers], 200);
    }

    /**
     * Retrieves details of a specific marker.
     */
    public function get_marker_details_callback($request) {
        global $wpdb;

        $marker_id = intval($request['id']);
        $table_name = $wpdb->prefix . 'wpgmza';

        $marker = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$table_name} WHERE id = %d", $marker_id),
                                 ARRAY_A
        );

        if (!$marker) {
            $this->log_debug('Marker not found: ID ' . $marker_id);
            return new \WP_REST_Response(['success' => false, 'message' => 'Marker not found.'], 404);
        }

        $this->log_debug('Retrieved marker details for ID ' . $marker_id);
        return new \WP_REST_Response(['success' => true, 'data' => $marker], 200);
    }

    /**
     * Adds a new marker.
     */
    public function add_marker_callback($request) {
        global $wpdb;

        $params = $request->get_json_params();
        $map_id = intval($params['map_id'] ?? 0);
        $title = sanitize_text_field($params['title'] ?? '');
        $lat = sanitize_text_field($params['lat'] ?? '');
        $lng = sanitize_text_field($params['lng'] ?? '');
        $address = sanitize_text_field($params['address'] ?? '');
        $description = sanitize_text_field($params['description'] ?? '');

        if (empty($map_id) || empty($title) || empty($lat) || empty($lng)) {
            $this->log_debug('Failed to add marker: Missing required parameters.');
            return new \WP_REST_Response(['success' => false, 'message' => 'Missing required parameters.'], 400);
        }

        $table_name = $wpdb->prefix . 'wpgmza';
        $inserted = $wpdb->insert(
            $table_name,
            [
                'map_id'      => $map_id,
                'title'       => $title,
                'lat'         => $lat,
                'lng'         => $lng,
                'address'     => $address,
                'description' => $description,
            ],
            ['%d', '%s', '%s', '%s', '%s', '%s']
        );

        if ($inserted === false) {
            $this->log_debug('Failed to add marker: Database insertion error.');
            return new \WP_REST_Response(['success' => false, 'message' => 'Failed to add marker.'], 500);
        }

        $this->log_debug('Marker added successfully: ID ' . $wpdb->insert_id);
        return new \WP_REST_Response([
            'success' => true,
            'message' => 'Marker added successfully!',
            'data'    => [
                'id'          => $wpdb->insert_id,
                'map_id'      => $map_id,
                'title'       => $title,
                'lat'         => $lat,
                'lng'         => $lng,
                'address'     => $address,
                'description' => $description,
            ],
        ], 200);
    }
}

/**
 * Registers the routes for Markers_Free_API with fallback logic.
 */
/**
 * Registers the routes for Markers_Free_API with fallback logic.
 */
function mapfusion_register_markers_free_api_routes() {
    if (class_exists('\\MapFusion\\Api\\Free\\Markers_Free_API')) {
        error_log('Initializing Markers_Free_API class.');
        $markers_free_api = new \MapFusion\Api\Free\Markers_Free_API();
        $markers_free_api->register_routes();
    } else {
        error_log('Markers_Free_API class not found. Attempting fallback...');
        $fallback_file = __DIR__ . '/class-markers-free-api.php';

        if (file_exists($fallback_file)) {
            require_once $fallback_file;
            error_log('Fallback file loaded: ' . $fallback_file);

            if (class_exists('\\MapFusion\\Api\\Free\\Markers_Free_API')) {
                error_log('Fallback succeeded. Initializing Markers_Free_API class.');
                $markers_free_api = new \MapFusion\Api\Free\Markers_Free_API();
                $markers_free_api->register_routes();
            } else {
                error_log('Failed to initialize Markers_Free_API class even after including fallback.');
            }
        } else {
            error_log('Fallback file not found: ' . $fallback_file);
        }
    }
}
add_action('rest_api_init', '\\MapFusion\\Api\\Free\\mapfusion_register_markers_free_api_routes');
