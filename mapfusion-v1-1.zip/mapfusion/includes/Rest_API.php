<?php

namespace MapFusion;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Class for handling REST API initialization and authorization for MapFusion.
 */
class Rest_API {

    /**
     * Load and initialize all required API classes and utilities for MapFusion.
     */
    public static function load_api_classes() {
        try {
            self::log_debug('Starting to load all required API classes and utilities...');

            // Define all class files to be loaded
            $api_classes = [
                \MapFusion\Api\Free\Maps_Free_API::class,
                \MapFusion\Api\Free\Markers_Free_API::class,
                \MapFusion\Api\Pro\Maps_Pro_API::class,
                \MapFusion\Api\Pro\Markers_Pro_API::class,
                \MapFusion\Api\Pro\Export_Import_API::class,
                \MapFusion\Api\Other_API::class,
                \MapFusion\License_Validator::class,
                \MapFusion\Settings::class,
                \MapFusion\Privacy_Policy_Notice::class,
                \MapFusion\Render::class,
                \MapFusion\Rest_API::class,
                \MapFusion\Appsero_Client::class,
                \MapFusion\WPGM_Integration::class,
            ];

            foreach ($api_classes as $api_class) {
                if (class_exists($api_class)) {
                    self::log_debug("Found class: {$api_class}");

                    $class_instance = new $api_class();
                    if (method_exists($class_instance, 'register_routes')) {
                        $class_instance->register_routes();
                        self::log_debug("Routes registered for class: {$api_class}");
                    } else {
                        self::log_debug("Class {$api_class} does not have a 'register_routes' method.");
                    }
                } else {
                    self::log_debug("Class {$api_class} not found. Attempting to load fallback file...");

                    // Map namespace to file path with correct structure
                    $relative_path = str_replace(['\\'], DIRECTORY_SEPARATOR, $api_class);
                    $relative_path = preg_replace('/^MapFusion\\\\/', '', $relative_path);

                    $class_file = __DIR__ . DIRECTORY_SEPARATOR . $relative_path . '.php';

                    if (file_exists($class_file)) {
                        require_once $class_file;
                        if (class_exists($api_class)) {
                            self::log_debug("Class {$api_class} loaded successfully from fallback file.");
                            $class_instance = new $api_class();
                            if (method_exists($class_instance, 'register_routes')) {
                                $class_instance->register_routes();
                                self::log_debug("Routes registered for class: {$api_class}");
                            } else {
                                self::log_debug("Class {$api_class} does not have a 'register_routes' method.");
                            }
                        } else {
                            self::log_debug("Class {$api_class} could not be found even after including fallback file.");
                        }
                    } else {
                        self::log_debug("Fallback file for class {$api_class} not found: {$class_file}");
                    }
                }
            }

            self::log_debug('All classes have been loaded and initialized successfully.');
        } catch (\Exception $e) {
            self::log_debug('Error loading API classes: ' . $e->getMessage());
        }
    }

    /**
     * Verify the Bearer token for API key validation.
     *
     * @param \WP_REST_Request $request The incoming REST API request.
     * @return true|\WP_Error True if valid, otherwise WP_Error.
     */
    public static function verify_bearer_token($request) {
        self::log_debug('Starting Bearer token verification...');

        $headers = $request->get_headers();
        $authorization_header = $headers['authorization'][0] ?? null;

        if (!$authorization_header) {
            self::log_debug('Authorization header is missing.');
            return new \WP_Error('unauthorized', __('Authorization header is missing.', 'mapfusion'), ['status' => 401]);
        }

        if (preg_match('/Bearer\s+(\S+)/', $authorization_header, $matches)) {
            $bearer_token = $matches[1];
            $saved_token = get_option('mapfusion_api_key', '');

            self::log_debug("Comparing tokens: Provided={$bearer_token} | Saved={$saved_token}");

            if (hash_equals($saved_token, $bearer_token)) {
                self::log_debug('Bearer token validated successfully.');
                return true;
            }

            self::log_debug('Bearer token validation failed.');
            return new \WP_Error('unauthorized', __('Invalid API Key.', 'mapfusion'), ['status' => 401]);
        }

        self::log_debug('Bearer token is malformed or missing.');
        return new \WP_Error('unauthorized', __('Bearer token is malformed or missing.', 'mapfusion'), ['status' => 401]);
    }

    /**
     * Validates permissions, including API key and license key.
     *
     * @param \WP_REST_Request $request The incoming REST API request.
     * @return true|\WP_Error True if valid, otherwise WP_Error.
     */
    public static function validate_permissions($request) {
        // Validate API key using Bearer token
        $api_validation = self::verify_bearer_token($request);
        if (is_wp_error($api_validation)) {
            return $api_validation; // Return error if API key validation fails
        }

        // Validate license key
        $license_validation = License_Validator::validate_license_from_request($request);
        if (!$license_validation['success']) {
            return new \WP_Error('unauthorized', $license_validation['message'], ['status' => 403]);
        }

        return true;
    }

    /**
     * Utility function to log debug messages if debugging is enabled.
     *
     * @param string $message The debug message.
     */
    public static function log_debug($message) {
        if (get_option('mapfusion_debug_logging', false)) {
            $request_id = $_SERVER['UNIQUE_ID'] ?? uniqid();
            error_log("[MapFusion DEBUG][Request ID: {$request_id}] {$message}");
        }
    }
}

// Hook into REST API initialization
add_action('rest_api_init', function () {
    error_log('Attempting to initialize MapFusion Rest_API class...');

    // Check if the class already exists
    if (class_exists('\\MapFusion\\Rest_API')) {
        error_log('MapFusion Rest_API class found. Initializing...');
        \MapFusion\Rest_API::load_api_classes();
        return;
    }

    // If the class is not found, attempt to include the fallback file
    error_log('MapFusion Rest_API class not found! Including fallback file...');
    $fallback_file = __DIR__ . '/includes/class-mapfusion-rest-api.php';

    if (file_exists($fallback_file)) {
        require_once $fallback_file;
        error_log('Fallback file included: ' . $fallback_file);
    } else {
        error_log('Fallback file not found: ' . $fallback_file);
        return;
    }

    // Check if the class is loaded after including the fallback
    if (class_exists('\\MapFusion\\Rest_API')) {
        error_log('Fallback succeeded. Initializing MapFusion Rest_API class...');
        \MapFusion\Rest_API::load_api_classes();
    } else {
        error_log('Failed to initialize MapFusion Rest_API class even after including fallback.');
    }
});
