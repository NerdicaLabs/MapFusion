<?php

namespace MapFusion;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Class Privacy_Policy_Notice
 * Handles the display and dismissal of the privacy policy notice.
 */
class Privacy_Policy_Notice {

    /**
     * Initialize hooks for privacy policy notice.
     */
    public static function init() {
        add_action('admin_notices', [__CLASS__, 'show_privacy_policy_notice']);
        add_action('wp_ajax_mapfusion_dismiss_notice', [__CLASS__, 'dismiss_privacy_notice']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue_dismiss_script']);
    }

    /**
     * Show the privacy policy notice.
     */
    public static function show_privacy_policy_notice() {
        if (!get_user_meta(get_current_user_id(), 'mapfusion_privacy_notice_dismissed', true)) {
            echo '<div class="notice notice-info is-dismissible" data-notice="mapfusion-privacy-notice">';
            echo '<p>';
            echo __(
                'MapFusion uses Appsero to collect telemetry data with your consent. This data helps improve the plugin. Read our <a href="https://appsero.com/privacy-policy/" target="_blank">Privacy Policy</a>.',
                'mapfusion'
            );
            echo '</p>';
            echo '</div>';
        }
    }

    /**
     * Handle AJAX request to dismiss the privacy notice.
     */
    public static function dismiss_privacy_notice() {
        if (!current_user_can('manage_options') || !isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'mapfusion_dismiss_notice')) {
            wp_send_json_error(['message' => __('Invalid request.', 'mapfusion')]);
        }

        update_user_meta(get_current_user_id(), 'mapfusion_privacy_notice_dismissed', true);
        wp_send_json_success(['message' => __('Notice dismissed.', 'mapfusion')]);
    }

    /**
     * Enqueue script for dismissing the privacy notice.
     *
     * @param string $hook The current admin page hook.
     */
    public static function enqueue_dismiss_script($hook) {
        if ($hook === 'plugins.php') {
            wp_enqueue_script(
                'mapfusion-dismiss-notice',
                plugin_dir_url(__FILE__) . '../js/mapfusion-dismiss-notice.js',
                              ['jquery'],
                              MAPFUSION_VERSION,
                              true
            );

            wp_localize_script('mapfusion-dismiss-notice', 'mapfusionDismiss', [
                'ajax_url' => admin_url('admin-ajax.php'),
                               'nonce'    => wp_create_nonce('mapfusion_dismiss_notice'),
            ]);
        }
    }
}

// Hämta debug-inställning
$debug_status = get_option('mapfusion_debug_logging', false);

// Kontrollera och initialisera klassen om den finns
if (class_exists('\MapFusion\Privacy_Policy_Notice')) {
    if ($debug_status) {
        error_log('[MapFusion] Initializing Privacy_Policy_Notice class.');
    }
    \MapFusion\Privacy_Policy_Notice::init();
} else {
    if ($debug_status) {
        error_log('[MapFusion] Privacy_Policy_Notice class not found!');
    }
}
