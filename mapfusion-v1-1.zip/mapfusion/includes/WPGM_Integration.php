<?php

namespace MapFusion;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Handles integration with WP Go Maps.
 */
class WPGM_Integration {

    /**
     * Logs debug messages if debug logging is enabled.
     *
     * @param string|array $message The message to log.
     */
    private static function debug_log($message) {
        if (get_option('mapfusion_debug_logging', false)) {
            if (is_array($message) || is_object($message)) {
                $message = print_r($message, true);
            }
            $request_id = $_SERVER['UNIQUE_ID'] ?? uniqid();
            error_log("[MapFusion DEBUG][Request ID: {$request_id}] {$message}");
        }
    }

    /**
     * Adds a marker to a specific map.
     *
     * @param int $map_id The ID of the map to add the marker to.
     * @param array $marker_data The data for the new marker (title, description, lat, lng, etc.).
     * @return bool True on success, false on failure.
     */
    public static function add_marker($map_id, $marker_data) {
        global $wpdb;

        // Table for storing markers
        $table_name = $wpdb->prefix . 'wpgmza';

        // Prepare data for insertion
        $data = [
            'map_id'      => intval($map_id),
            'title'       => sanitize_text_field($marker_data['title'] ?? ''),
            'description' => sanitize_textarea_field($marker_data['description'] ?? ''),
            'lat'         => sanitize_text_field($marker_data['lat'] ?? ''),
            'lng'         => sanitize_text_field($marker_data['lng'] ?? ''),
            'address'     => sanitize_text_field($marker_data['address'] ?? ''),
            'icon'        => sanitize_text_field($marker_data['icon'] ?? ''),
            'pic'         => sanitize_text_field($marker_data['pic'] ?? ''),
        ];

        self::debug_log("Adding marker to map ID: {$map_id}");
        self::debug_log("Marker data: " . print_r($data, true));

        // Insert marker data into the database
        $inserted = $wpdb->insert($table_name, $data, [
            '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s'
        ]);

        self::debug_log($inserted !== false ? "Marker added successfully." : "Failed to add marker.");
        return $inserted !== false;
    }

    /**
     * Deletes a marker from a specific map.
     *
     * @param int $marker_id The ID of the marker to delete.
     * @return bool True on success, false on failure.
     */
    public static function delete_marker($marker_id) {
        global $wpdb;

        // Table for storing markers
        $table_name = $wpdb->prefix . 'wpgmza';

        self::debug_log("Deleting marker ID: {$marker_id}");

        // Delete the marker from the database
        $deleted = $wpdb->delete($table_name, ['id' => intval($marker_id)], ['%d']);

        self::debug_log($deleted !== false ? "Marker deleted successfully." : "Failed to delete marker.");
        return $deleted !== false;
    }

    /**
     * Updates an existing marker.
     *
     * @param int $marker_id The ID of the marker to update.
     * @param array $marker_data The updated data for the marker.
     * @return bool True on success, false on failure.
     */
    public static function update_marker($marker_id, $marker_data) {
        global $wpdb;

        // Table for storing markers
        $table_name = $wpdb->prefix . 'wpgmza';

        // Prepare data for updating
        $data = [];
        $allowed_fields = ['title', 'description', 'lat', 'lng', 'address', 'icon', 'pic'];

        foreach ($allowed_fields as $field) {
            if (isset($marker_data[$field])) {
                $data[$field] = sanitize_text_field($marker_data[$field]);
            }
        }

        self::debug_log("Updating marker ID: {$marker_id}");
        self::debug_log("Updated marker data: " . print_r($data, true));

        // Update the marker in the database
        $updated = $wpdb->update(
            $table_name,
            $data,
            ['id' => intval($marker_id)],
                                 array_fill(0, count($data), '%s'),
                                 ['%d']
        );

        self::debug_log($updated !== false ? "Marker updated successfully." : "Failed to update marker.");
        return $updated !== false;
    }

    /**
     * Retrieves all markers for a specific map.
     *
     * @param int $map_id The ID of the map.
     * @return array List of markers, or an empty array if none are found.
     */
    public static function get_markers_by_map($map_id) {
        global $wpdb;

        // Table for storing markers
        $table_name = $wpdb->prefix . 'wpgmza';

        self::debug_log("Fetching markers for map ID: {$map_id}");

        // Query markers for the specified map
        $query = $wpdb->prepare("SELECT * FROM {$table_name} WHERE map_id = %d", intval($map_id));
        $markers = $wpdb->get_results($query, ARRAY_A);

        self::debug_log("Markers fetched: " . print_r($markers, true));
        return $markers ?: [];
    }
}
