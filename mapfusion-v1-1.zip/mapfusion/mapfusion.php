<?php

/*
 * Plugin Name: MapFusion
 * Plugin URI: https://www.mapfusion.site
 * Description: Advanced mapping plugin for WordPress.
 * Version: 1.1.0
 * Author: Charlie the Nerdica
 * Text Domain: mapfusion
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

define('MAPFUSION_VERSION', '1.1.0');

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Load Composer's autoload file
require_once __DIR__ . '/vendor/autoload.php';

// Fallback includes for critical classes
$critical_classes = [
    'MapFusion\\Settings' => '/includes/class-settings.php',
    'MapFusion\\Privacy_Policy_Notice' => '/includes/class-privacy-policy-notice.php',
    'MapFusion\\Render' => '/includes/class-render.php',
    'MapFusion\\Rest_API' => '/includes/class-rest-api.php',
    'MapFusion\\License_Validator' => '/includes/class-license-validator.php',
    'MapFusion\\Appsero_Client' => '/includes/class-appsero-client.php',
    'MapFusion\\WPGM_Integration' => '/includes/class-wpgm-integration.php'
];

foreach ($critical_classes as $class => $path) {
    if (!class_exists($class)) {
        $fallback_file = __DIR__ . $path;
        if (file_exists($fallback_file)) {
            require_once $fallback_file;
            error_log("[MapFusion] Fallback: Loaded {$class} manually.");
        } else {
            error_log("[MapFusion] Fallback file not found for {$class}: {$fallback_file}");
        }
    }
}

/**
 * Main class for the MapFusion plugin.
 */
class MapFusion {

    /**
     * Constructor.
     */
    public function __construct() {
        $this->log_debug('Constructor called.');
        // Check for required dependencies
        add_action('admin_init', [$this, 'check_wp_go_maps_pro']);

        // Initialize WordPress hooks
        $this->initialize_hooks();
    }

    /**
     * Check if WP Go Maps Pro Add-on is installed and active.
     */
    public function check_wp_go_maps_pro() {
        $this->log_debug('Checking WP Go Maps Pro.');
        if (!function_exists('is_plugin_active')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        if (!is_plugin_active('wp-google-maps-pro/wp-google-maps-pro.php')) {
            add_action('admin_notices', function () {
                printf(
                    '<div class="notice notice-error"><p>%s</p></div>',
                    __(
                        'MapFusion requires WP Go Maps - Pro Add-on to function properly. Please <a href="https://www.wpgmaps.com" target="_blank">install and activate the plugin</a>.',
                       'mapfusion'
                    )
                );
            });
        }
    }

    /**
     * Initialize WordPress hooks.
     */
    private function initialize_hooks() {
        $this->log_debug('Initializing hooks.');
        add_action('plugins_loaded', ['MapFusion\\Settings', 'init']); // Initialize settings
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_scripts']); // Enqueue admin assets
        add_action('rest_api_init', [$this, 'initialize_rest_api']);
        add_action('init', [$this, 'initialize_privacy_policy']);
    }

    /**
     * Initialize REST API.
     */
    public function initialize_rest_api() {
        $this->log_debug('Initializing REST API.');
        if (class_exists('MapFusion\\Rest_API')) {
            MapFusion\Rest_API::load_api_classes();
        } else {
            error_log('[MapFusion] Rest_API class not found!');
        }
    }

    /**
     * Initialize privacy policy notice.
     */
    public function initialize_privacy_policy() {
        $this->log_debug('Initializing Privacy Policy Notice.');
        if (class_exists('MapFusion\\Privacy_Policy_Notice')) {
            MapFusion\Privacy_Policy_Notice::init();
        } else {
            error_log('[MapFusion] Privacy_Policy_Notice class not found!');
        }
    }

    /**
     * Enqueue admin scripts and styles.
     *
     * @param string $hook The current admin page hook.
     */
    public function enqueue_admin_scripts($hook) {
        $this->log_debug("enqueue_admin_scripts function called with hook: {$hook}");

        // API Key Management Page
        if ($hook === 'mapfusion_page_api-key-management') {
            wp_register_script(
                'mapfusion-api-key-management-js',
                plugin_dir_url(__FILE__) . 'js/api-key-management.js',
                               ['jquery'], // Dependencies
                               MAPFUSION_VERSION,
                               true // Load in footer
            );

            if (wp_script_is('mapfusion-api-key-management-js', 'registered')) {
                $nonce = wp_create_nonce('mapfusion_settings_nonce');
                wp_localize_script('mapfusion-api-key-management-js', 'mapfusionApiKeySettings', [
                    'ajaxUrl' => admin_url('admin-ajax.php'),
                                   'nonce' => $nonce,
                                   'debug' => get_option('mapfusion_debug_logging', false),
                                   'apiKey' => get_option('mapfusion_api_key', ''),
                ]);
                $this->log_debug("Generated nonce for API Key Management: {$nonce}");
            } else {
                $this->log_debug('Failed to register mapfusion-api-key-management-js.');
            }
        }

        // Debug Settings Page
        if ($hook === 'mapfusion_page_settings') {
            wp_register_script(
                'debug-settings-js',
                plugin_dir_url(__FILE__) . 'js/debug-settings.js',
                               ['jquery'], // Dependencies
                               MAPFUSION_VERSION,
                               true // Load in footer
            );

            if (wp_script_is('debug-settings-js', 'registered')) {
                $nonce = wp_create_nonce('mapfusion_debug_nonce');
                wp_localize_script('debug-settings-js', 'mapfusionDebugSettings', [
                    'ajaxUrl' => admin_url('admin-ajax.php'),
                                   'nonce' => $nonce,
                                   'debug' => get_option('mapfusion_debug_logging', false),
                ]);
                $this->log_debug("Generated nonce for Debug Settings: {$nonce}");
            } else {
                $this->log_debug('Failed to register debug-settings-js.');
            }
        }

        // Enqueue shared scripts and styles
        if ($this->is_mapfusion_page($hook)) {
            $this->log_debug('Enqueueing scripts and styles for page: ' . $hook);

            if ($hook === 'mapfusion_page_api-key-management' && wp_script_is('mapfusion-api-key-management-js', 'registered')) {
                wp_enqueue_script('mapfusion-api-key-management-js');
            }

            if ($hook === 'mapfusion_page_settings' && wp_script_is('debug-settings-js', 'registered')) {
                wp_enqueue_script('debug-settings-js');
            }

            wp_enqueue_style(
                'mapfusion-button-css',
                plugin_dir_url(__FILE__) . 'css/button.css',
                             [],
                             MAPFUSION_VERSION
            );

            wp_enqueue_style(
                'mapfusion-settings-css',
                plugin_dir_url(__FILE__) . 'css/settings.css',
                             [],
                             MAPFUSION_VERSION
            );
        }
    }

    /**
     * Check if the current page belongs to MapFusion.
     *
     * @param string $hook The current admin page hook.
     * @return bool
     */
    private function is_mapfusion_page($hook) {
        $this->log_debug('Checking if hook matches MapFusion pages: ' . $hook);
        return strpos($hook, 'mapfusion') === 0;
    }

    /**
     * Logs debug information if debug mode is enabled.
     *
     * @param string $message The debug message.
     */
    private function log_debug($message) {
        if (get_option('mapfusion_debug_logging', false)) {
            $request_id = $_SERVER['UNIQUE_ID'] ?? uniqid();
            error_log("[MapFusion DEBUG][Request ID: {$request_id}] {$message}");
        }
    }
}

// Generate API key on plugin activation
register_activation_hook(__FILE__, function () {
    error_log('[MapFusion] Plugin activation: Generating API key.');
    try {
        if (!get_option('mapfusion_api_key')) {
            update_option('mapfusion_api_key', wp_generate_password(40, false, false));
            error_log('[MapFusion] API key generated successfully.');
        } else {
            error_log('[MapFusion] API key already exists.');
        }
    } catch (Exception $e) {
        error_log('[MapFusion] Error during activation: ' . $e->getMessage());
    }
});

// Initialize the plugin
error_log('[MapFusion] Initializing plugin.');
new MapFusion();
