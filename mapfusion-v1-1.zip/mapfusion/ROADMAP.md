# Roadmap

MapFusion is committed to expanding its capabilities. Here are some planned features:

## Version 1.2.0
- Bugfixes and performance improvements.
- Enhanced debug tools for easier troubleshooting.
- Internationalization support for broader accessibility.

## Version 2.0.0 (In Development)
### PRO Features
- **Layer Management:** Add, edit, and organize layers for maps.
- **Category Management:** Comprehensive tools for managing categories.
- **Batch Marker Updates:** Simultaneously update multiple markers for streamlined workflows.

## Future Plans
- Improved integration with third-party mapping APIs.
- Multi-site compatibility for enterprise users.
- Advanced analytics for map and marker performance.
- User role-based access control for PRO features.
