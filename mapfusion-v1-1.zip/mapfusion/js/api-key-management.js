// api-key-management.js

document.addEventListener('DOMContentLoaded', function () {
    console.log("[MapFusion] api-key-management.js has loaded.");

    if (typeof mapfusionApiKeySettings === 'undefined') {
        console.error("[MapFusion] mapfusionApiKeySettings is not defined. Check wp_localize_script in PHP.");
        return;
    }

    console.log("[MapFusion] mapfusionApiKeySettings:", mapfusionApiKeySettings);

    const apiKeyInput = document.getElementById('api-key');
    const statusSpan = document.getElementById('make-status');
    const resultDiv = document.getElementById('connection-result');
    const resetButton = document.getElementById('reset-api-key');
    const testButton = document.getElementById('test-connection');

    // Test connection functionality
    if (testButton) {
        testButton.addEventListener('click', async function () {
            console.log("[MapFusion] Testing connection...");

            try {
                const response = await fetch(mapfusionApiKeySettings.ajaxUrl, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: new URLSearchParams({
                        action: 'test_connection',
                        nonce: mapfusionApiKeySettings.nonce,
                    }),
                });

                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }

                const data = await response.json();

                if (data.success) {
                    statusSpan.textContent = 'Make: Active';
                    statusSpan.style.color = 'green';
                    console.log("[MapFusion] Connection successful:", data.message);
                    resultDiv.textContent = `Connection successful: ${data.message}`;
                } else {
                    throw new Error(data.message || 'Unknown error');
                }
            } catch (error) {
                console.error("[MapFusion] Error during connection test:", error);
                statusSpan.textContent = 'Make: Not active';
                statusSpan.style.color = 'red';
                resultDiv.textContent = `Connection failed: ${error.message}`;
            }
        });
    }

    // Reset API key functionality
    if (resetButton) {
        resetButton.addEventListener('click', async function () {
            if (!confirm('Are you sure you want to reset the API key? This action cannot be undone.')) {
                return;
            }

            console.log("[MapFusion] Resetting API key...");

            try {
                const response = await fetch(mapfusionApiKeySettings.ajaxUrl, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: new URLSearchParams({
                        action: 'reset_api_key',
                        nonce: mapfusionApiKeySettings.nonce,
                    }),
                });

                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }

                const data = await response.json();

                if (data.success) {
                    apiKeyInput.value = data.api_key; // Update the input field with the new key
                    alert('API key has been successfully reset.');
                    console.log("[MapFusion] API key reset successful:", data.api_key);
                } else {
                    throw new Error(data.message || 'Unknown error');
                }
            } catch (error) {
                alert(`Error resetting API key: ${error.message}`);
                console.error("[MapFusion] Error during API key reset:", error);
            }
        });
    }
});
