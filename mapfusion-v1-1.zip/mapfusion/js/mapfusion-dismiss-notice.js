jQuery(document).ready(function ($) {
    $(document).on('click', '.notice.is-dismissible[data-notice="mapfusion-privacy-notice"] .notice-dismiss', function () {
        $.post(mapfusionDismiss.ajax_url, {
            action: 'mapfusion_dismiss_notice',
            nonce: mapfusionDismiss.nonce
        })
        .done(function (response) {
            console.log('[MapFusion DEBUG]: Privacy notice dismissed successfully.', response);
        })
        .fail(function (error) {
            console.error('[MapFusion DEBUG]: Failed to dismiss privacy notice.', error);
        });
    });
});
