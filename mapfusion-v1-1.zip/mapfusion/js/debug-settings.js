// debug-settings.js

document.addEventListener('DOMContentLoaded', () => {
    const debugStatusSpan = document.getElementById('mapfusion-debug-status');
    const debugToggle = document.getElementById('debug-toggle');
    const saveDebugButton = document.getElementById('save-debug');
    const errorMessageDiv = document.getElementById('error-message');
    const loadingIndicator = document.getElementById('loading-indicator');
    let isProcessing = false; // Flag to prevent duplicate AJAX calls

    // Debug logging function
    const debugLog = (message, data = null) => {
        console.log('[MapFusion DEBUG]:', message, data || '');
    };

    const showError = (message) => {
        errorMessageDiv.textContent = message;
        errorMessageDiv.style.display = 'block';
        debugLog(`Error displayed: ${message}`);
    };

    const clearError = () => {
        errorMessageDiv.textContent = '';
        errorMessageDiv.style.display = 'none';
    };

    const showLoading = () => {
        loadingIndicator.style.display = 'block';
    };

    const hideLoading = () => {
        loadingIndicator.style.display = 'none';
    };

    // Function to update debug logging status
    const updateDebugStatus = async (isDebugOn) => {
        if (isProcessing) {
            debugLog('Update already in progress. Skipping...');
            return;
        }

        isProcessing = true; // Set flag to prevent duplicate calls

        try {
            showLoading();
            debugLog('Updating debug status...');
            debugLog('[MapFusion] Debug nonce:', mapfusionDebugSettings.nonce);

            const response = await fetch(mapfusionDebugSettings.ajaxUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    action: 'update_debug_logging',
                    nonce: mapfusionDebugSettings.nonce,
                    debug_logging: isDebugOn ? '1' : '0',
                }),
            });

            debugLog('Server response object:', response);

            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            const data = await response.json();
            debugLog('Parsed response data:', data);

            if (data.success) {
                debugStatusSpan.textContent = isDebugOn ? 'On' : 'Off';
                debugStatusSpan.style.color = isDebugOn ? 'green' : 'red';
                clearError();
                debugLog('Debug status updated successfully on the server.');
            } else {
                showError(`Failed to update debug status. Server response: ${data.message || 'Unknown error'}`);
            }
        } catch (error) {
            showError(`Error updating debug status: ${error.message}`);
            debugLog(`Error updating debug status: ${error.message}`);
        } finally {
            hideLoading();
            isProcessing = false; // Reset flag after call completes
        }
    };

    // Event listener for debug toggle
    if (debugToggle) {
        debugToggle.removeEventListener('change', () => {}); // Clear previous handler
        debugToggle.addEventListener('change', (event) => {
            debugLog(`Debug toggle changed: ${event.target.checked}`);
        });
    }

    // Event listener for saving debug settings
    if (saveDebugButton) {
        saveDebugButton.removeEventListener('click', () => {}); // Clear previous handler
        saveDebugButton.addEventListener('click', () => {
            const isDebugOn = debugToggle.checked;
            debugLog(`Save Debug button clicked. Debug is now: ${isDebugOn}`);
            updateDebugStatus(isDebugOn);
        });
    }

    // Initialize debug status update on page load
    debugLog('Initializing debug settings page...');
});
